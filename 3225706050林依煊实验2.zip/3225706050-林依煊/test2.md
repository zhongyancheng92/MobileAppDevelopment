# 鸿蒙 harmony OS
## 实验二 自定义组件以及传参
在本次实验中，我新引入了五个组件：TextClock、TextInput、Select、CheckboxGroup和Search。同时，我还掌握了pushUrl传参的方法，成功将第一个页面的信息传递到了下一个页面。在目标页面中，我设置了参数的存储机制，并将传递过来的参数清晰地显示出来。另外，我还在第一个页面账号输入的环节设置了输入不应该为空的提示，要求当用户输入账号和密码之后才可以跳转到下一个页面，否则会提示账号/密码不能为空。

### 思路
1. 传参逻辑
  + 页面跳转
    + 使用 router.pushUrl 方法跳转到 Second 页面，并将当前输入的用户名作为参数传递。
  + 定义参数类
    + 首先，定义了一个名为 routerParams 的类，用于封装要传递的参数。在这个类中，声明了一个 username 属性，用于保存用户名。
  + 初始化参数
    + 在创建 routerParams 类的实例时，通过 constructor 构造函数将传入的 username 参数赋值给类的 username 属性。 
  + 传递参数
    + Index 组件中，当需要跳转到另一个页面 ，Index 组件使用 router.pushUrl 方法，Second 组件并将 routerParams 类的实例作为参数传递。这个实例中包含了 username 的值。
  + 接收参数
    + Second 组件中，通过 router.getParams() 方法获取传递过来的参数。这个方法返回一个包含所有传递参数的对象。
    + 为了安全地访问这些参数，代码使用了类型断言 (router.getParams() as routerParams)，将返回的对象视为 routerParams 类型。这样，就可以安全地访问 username 属性了。
  + 使用参数
    + 在 Second 组件中，将获取到的 username 值赋值给组件的响应式变量 username。
    + 在组件的 build 方法中使用，最后通过 Text 组件动态显示欢迎消息。
  2. 实现在用户名和密码为空时显示错误信息
  + 新增状态变量
    + @State usernameError: string = ''
      @State passwordError: string = ''，用于存储对应的错误提示信息。
  + 输入时清除错误
    + 在TextInput的onChange事件中添加this.usernameError = '';确保用户在输入内容时错误提示会自动消失。
  + 错误提示显示
    + 在每个输入框下方添加了错误提示Text组件。
  + 验证信息
    + 在按钮的onClick事件中进行验证，并清空 usernameError 以及passwordError ，若验证成功则跳转到下一页并将用户名传过去。
  
### Index.ets
```typescript {.line-numbers}
// 导入ArkUI的路由模块
import { router } from '@kit.ArkUI';
// 导入基础服务错误处理模块
import { BusinessError } from '@kit.BasicServicesKit';

// @Entry 装饰器表示当前组件是应用入口组件
@Entry
// @Component 表示这是一个自定义组件
@Component

// 定义名为 Index 的结构体组件
struct Index {
  // @State 装饰器声明响应式变量message，用于维护组件状态
  @State message: string = '登录';// 初始化页面标题为“登录”
  @State username: string = '';//声明一个变量 username，用于保存用户输入的用户名，初始值为空字符串
  @State password: string = '';//声明一个变量 password，用于保存用户输入的用户名，初始值为空字符串
  @State usernameError: string = ''; // 新增用户名错误提示
  @State passwordError: string = ''; // 新增密码错误提示
  build() {// build 方法用于描述UI布局
    Row(){// Row 方法进行横向布局
      Column(){// Column 纵向布局
        TextClock().margin(20).fontSize(20)// 创建实时时钟组件（自动更新显示系统时间），设置字体大小为20
          .format('yyyyMMdd hh:mm:ss')//定义时间显示格式为：年月日 时分秒（24小时制）
        Text(this.message)// 文本组件显示message变量内容“登录”
          .fontSize(28).fontWeight(FontWeight.Bold)// 设置字体大小为28,并对字体进行加粗
        // 用户名输入框
        TextInput({placeholder:'请输入用户名'})// 设置占位提示文本
          .placeholderColor(Color.Blue).placeholderFont({size:14,weight:400})// 占位符文字颜色设置为蓝色,字体大小14,字体粗细400
          .caretColor(Color.Grey).width(300).height(40)// 输入光标颜色设置为灰色,输入框宽度300,高度为40
          .margin(20).fontSize(24).fontColor(Color.Black)// 设置外边距20，文本大小为24，颜色为黑色
          .onChange((value: string) => {// 为TextInput组件的输入变化事件绑定处理函数
            this.username = value; // 将输入的用户名保存到响应式变量中
            this.usernameError = ''; // 输入时清除错误提示
          })//onChange函数的反括号
        Text(this.usernameError)// 创建一个文本组件，显示用户名输入的错误信息
          .fontSize(15).fontColor(Color.Red).margin(5)// 设置文本字体大小为15，颜色为红色，外边距为5
        // 密码输入框
        TextInput({placeholder:'请输入密码...'})// 设置占位提示文本
          .width(300).height(40).margin(20).fontSize(24)// 输入框宽度300,高度为40，外边距20
          .type(InputType.Password).maxLength(12).showPasswordIcon(true)// 输入类型设置为密码，输入长度限制为12个字符，显示密码可见性切换图标（允许用户切换明文显示）
          .onChange((value) => {// 为TextInput组件的输入变化事件绑定处理函数
            this.password = value;// 将输入的密码保存到响应式变量中
            this.passwordError = ''; // 输入时清除错误提示
          })
        Text(this.passwordError)// 创建一个文本组件，显示密码输入的错误信息
          .fontSize(15).fontColor(Color.Red).margin(5)// 设置文本字体大小为15，颜色为红色，外边距为5
        // 设置按钮组件
          Button(){
            Text('Sign in ->')// 设置按钮内文本
              .fontSize(22).fontWeight(FontWeight.Bold)// 设置文本字体大小为22，按钮文本加粗
          }// Button按钮方法的反括号，结束按钮内的文本设置
          .type(ButtonType.Capsule)// 设置按钮样式为胶囊形状
          .margin({// 设置按钮外边距
            // 顶部间距设置为30
            top:30
        })// .margin属性赋值的反括号
          // 设置按钮背景颜色，'#fff9cffa'为粉色
        .backgroundColor('#fff9cffa')
          // 设置按钮宽度为父容器的60%
        .width('40%')
          // 设置按钮高度为父容器的5%
        .height('5%')
          // 设置按钮点击事件
        .onClick(()=>{
          this.usernameError = '';// 清空旧错误信息，准备进行新的验证
          this.passwordError = '';// 清空旧错误信息，准备进行新的验证

          // 验证逻辑
          if (!this.username.trim()) {// 检查用户名是否为空
            this.usernameError = '用户名不能为空';// 设置用户名错误提示信息
            return;// 中止后续代码执行，避免继续验证
          }// if方法的反括号

          if (!this.password.trim()) {// 检查密码是否为空
            this.passwordError = '密码不能为空';// 设置密码错误提示信息
            return;// 中止后续代码执行，避免继续验证
          }// if方法的反括号
          // 控制台打印点击成功信息
          console.info(`Succeeded in clicking the 'Next_Page'button.`)
          // 根据URL路径跳转到Second页面，并将用户名传入下一页
          router.pushUrl({url:'pages/Second',params: { username: this.username}}).then(()=>{
            // 控制台打印跳转成功信息
            console.info(`Succeeded in jumping to the second page.`)
          }).catch((err:BusinessError)=>{// 捕获跳转过程中的错误
            // 打印错误信息
            console.error(`Failed to jump to the second page.Code is ${err.code},message is ${err.message}`)
          })//为catch()方法捕获错误的反括号
        })// onClick按钮点击事件的反括号
      }// column纵向布局的反括号
      // 设置纵向布局宽度为父容器的100%
      .width('100%')
    }// Row横向布局的反括号
    // 设置横向布局高度为父容器的100%
    .height('100%')
  }// build()方法的反括号
}// Index结构体组件的反括号
```
### Second.ets
```typescript {.line-numbers}
// 导入ArkUI的路由模块
import { router } from '@kit.ArkUI';
// 导入基础服务错误处理模块
import { BusinessError } from '@kit.BasicServicesKit';
// 用于修改符号图标的样式
import { SymbolGlyphModifier } from '@kit.ArkUI'
class routerParams{// 定义一个类 routerParams，用于封装要传递的参数
  username:string// 声明一个属性 username，类型为字符串，用于保存用户名
  constructor(username:string) {// 构造函数，用于初始化类的实例
    this.username =username// 将传入的 username 参数赋值给类的属性 username
  }// constructor函数的反括号
}// 自定义类routerParams的反括号
// @Entry 装饰器表示当前组件是应用入口组件
@Entry
  // @Component 表示这是一个自定义组件
@Component

  // 定义名为 Second 的结构体组件
  struct Second {
  @State username:string=(router.getParams() as routerParams).username// 声明一个响应式变量 username，初始值通过 router.getParams() 获取路由参数中的 username 值，并通过类型断言将其视为 routerParams 类型，从而安全地访问 username 属性
  @State message: string = '选择你喜欢的板块';// 声明一个状态变量message
  @State text: string = "设置"// 声明一个状态变量text，存储Select组件的显示文本
  @State index: number = 2 // 声明一个状态变量index，用于记录Select组件当前选中的索引
  @State space: number = 8 // 声明一个状态变量space，用于设置Select组件选项之间的间距
  @State arrowPosition: ArrowPosition = ArrowPosition.END // 声明一个状态变量arrowPosition，用于设置Select组件箭头位置
  @State symbolModifier2: SymbolGlyphModifier =
    new SymbolGlyphModifier($r('sys.symbol.ohos_star')).fontColor([Color.Red]); // 声明并初始化一个状态变量symbolModifier2，用于设置收藏图标的样式
  @State symbolModifier3: SymbolGlyphModifier = 
    new SymbolGlyphModifier($r('sys.symbol.ohos_trash')).fontColor([Color.Gray]); // 声明并初始化一个状态变量symbolModifier3，用于设置收藏图标的样式
  // build 方法用于描述UI布局
  build() {
    // Row 方法进行横向布局
    Row(){
      // Column 方法进行纵向布局
      Column(){
        Text(`用户 ${this.username} 您好！`)// 创建一个文本组件，显示欢迎消息，其中 this.username 是一个变量，会动态插入到文本中
          .fontSize(20).margin({ bottom: 30 })// 设置文本字体大小为20，文本组件的外边距，底部间距为30
        Select([// 创建一个Select组件，包含收藏和删除两个选项
          { value: '收藏', symbolIcon: this.symbolModifier2 },// 设置收藏选项及其图标样式
          { value: '删除', symbolIcon: this.symbolModifier3 },])// 设置删除选项及其图标样式
          .selected(this.index).value(this.text).font({ size: 20, weight: 500 })// 设置当前选中的索引,以及文本，字体的大小为20，粗细为500
          .fontColor('#182431').selectedOptionFont({ size: 20, weight: 400 })// 设置字体颜色，以及选中项的字体样式
          .optionFont({ size: 20, weight: 400 }).space(this.space)// 设置选项的字体样式，以及选项之间的间距
          .arrowPosition(this.arrowPosition).menuAlign(MenuAlignType.START, { dx: 0, dy: 0 })// 设置箭头位置、菜单的对齐方式
          .onSelect((index: number, text?: string | undefined) => {// 当选项改变时触发的事件
            console.info('Select:' + index)// 将'Select:'和索引值拼接起来，然后输出到控制台
            this.index = index;// 将当前选择的索引值赋值给类的属性this.index
            if (text) {// 如果text存在
              this.text = text;// 将其值赋给类的属性this.text
            }// if的反括号
          })// .onSelect方法的反括号
          .margin({bottom:30})// 设置外边距为30
        Search({placeholder:'输入内容...'})// 创建一个Search组件，用于输入搜索内容
          .searchButton('搜索').width(300).height(40)// 设置搜索按钮的文本，以及组件的宽度与高度
          .placeholderColor(Color.Blue)// 设置占位符颜色为蓝色
          .placeholderFont({size:20,weight:300})// 设置占位符字体样式大小20，粗细为300
          .textFont({size:20,weight:300})// 设置输入文本的字体样式大小为20，粗细为300
        // 文本组件显示message变量内容“选择你喜欢的版块”
        Text(this.message)
          // 设置字体大小为25,并对字体进行加粗
          .fontSize(25).fontWeight(FontWeight.Bold)
        //全选框设置
        Flex({ justifyContent: FlexAlign.Start, alignItems: ItemAlign.Center }) {// 使用Flex布局容器，设置子元素在主轴上从起点开始排列，交叉轴上居中对齐
          CheckboxGroup({ group: 'checkboxGroup' })// 创建一个复选框组，命名为'checkboxGroup'
            .checkboxShape(CheckBoxShape.ROUNDED_SQUARE).selectedColor('#007DFF')// 设置复选框的形状为圆角正方形，选中时的颜色为#007DFF
            .onChange((itemName: CheckboxGroupResult) => {// 当复选框组的内容发生变化时触发的事件处理函数（数据框符号变化）
              console.info("checkbox group content" + JSON.stringify(itemName))// 打印出复选框组的内容，itemName是选中项的名称或值的数组
            })// .onChange方法的反括号
          Text('全选').fontSize(20).lineHeight(25).fontColor('#182431').fontWeight(500)// 添加一个文本标签，显示'全选'，并设置字体大小、行高、字体颜色和字体粗细
        }// Flex()方法的反括号

        // 选项1框设置
        Flex({ justifyContent: FlexAlign.Start, alignItems: ItemAlign.Center }) {// 使用Flex布局容器，设置子元素在主轴上从起点开始排列，交叉轴上居中对齐
          Checkbox({ name: 'checkbox1', group: 'checkboxGroup' })// 创建一个复选框，命名为'checkbox1'，属于'checkboxGroup'组
            .selectedColor('#007DFF').shape(CheckBoxShape.ROUNDED_SQUARE)// 设置选中时的颜色为#007DFF，形状为圆角正方形
            .onChange((value: boolean) => {// 当复选框组的内容发生变化时触发的事件处理函数（数据框符号变化）
              console.info('Checkbox1 change is' + value)// 打印出复选框组的内容，itemName是选中项的名称或值的数组
            })// .onChange方法的反括号
          Text('美食').fontSize(17).lineHeight(23).fontColor('#182431').fontWeight(500)// 添加一个文本标签，显示'美食'，并设置字体大小、行高、字体颜色和字体粗细
        }.margin({ left: 40 })// 为Flex容器设置左边距为40

        // 选项2框设置
        Flex({ justifyContent: FlexAlign.Start, alignItems: ItemAlign.Center }) {// 使用Flex布局容器，设置子元素在主轴上从起点开始排列，交叉轴上居中对齐
          Checkbox({ name: 'checkbox2', group: 'checkboxGroup' })// 创建一个复选框，命名为'checkbox2'，属于'checkboxGroup'组
            .selectedColor('#007DFF').shape(CheckBoxShape.ROUNDED_SQUARE)// 设置选中时的颜色为#007DFF，形状为圆角正方形
            .onChange((value: boolean) => {// 当复选框组的内容发生变化时触发的事件处理函数（数据框符号变化）
              console.info('Checkbox1 change is' + value)// 打印出复选框组的内容，itemName是选中项的名称或值的数组
            })// .onChange方法的反括号
          Text('穿搭').fontSize(17).lineHeight(23).fontColor('#182431').fontWeight(500)// 添加一个文本标签，显示'穿搭'，并设置字体大小、行高、字体颜色和字体粗细
        }.margin({ left: 40 })// 为Flex容器设置左边距为40

        // 选项3框设置
        Flex({ justifyContent: FlexAlign.Start, alignItems: ItemAlign.Center }) {// 使用Flex布局容器，设置子元素在主轴上从起点开始排列，交叉轴上居中对齐
          Checkbox({ name: 'checkbox3', group: 'checkboxGroup' })// 创建一个复选框，命名为'checkbox3'，属于'checkboxGroup'组
            .selectedColor('#007DFF').shape(CheckBoxShape.ROUNDED_SQUARE)// 设置选中时的颜色为#007DFF，形状为圆角正方形
            .onChange((value: boolean) => {// 当复选框组的内容发生变化时触发的事件处理函数（数据框符号变化）
              console.info('Checkbox1 change is' + value)// 打印出复选框组的内容，itemName是选中项的名称或值的数组
            })// .onChange方法的反括号
          Text('学习').fontSize(17).lineHeight(23).fontColor('#182431').fontWeight(500)// 添加一个文本标签，显示'学习'，并设置字体大小、行高、字体颜色和字体粗细
        }.margin({ left: 40 })// 为Flex容器设置左边距为40

        // 设置按钮组件
        Button(){
          // 按钮内文本为“Back”
          Text('Back')
            // 设置文本字体大小为22
            .fontSize(22)
              // 设置按钮文本加粗
            .fontWeight(FontWeight.Bold)
        }// 与95行括号对应的按钮方法的反括号，结束按钮内的文本设置
        // 设置按钮样式为胶囊形状
        .type(ButtonType.Capsule)
        // 设置按钮外边距
          .margin({
            // 顶部间距设置为30
            top:30
          })//为106行.margin属性赋值的反括号
        //设置按钮背景颜色，'#0D9FFB'为蓝色
          .backgroundColor('#0D9FFB')
        // 设置按钮宽度为父容器的40%
          .width('40%')
        // 设置按钮高度为父容器的5%
          .height('5%')
        // 设置按钮点击事件
        .onClick(()=>{
          // 控制台打印点击成功信息
          console.info(`Succeeded in clicking the 'Back'button.`)
          //使用try()方法
          try {
            // 尝试通过路由返回上一页
            router.back()
            // 如果成功返回上一页，在控制台打印成功信息
            console.info(`Succeeded in returning to the first page.`)
          }catch (err){//如果在尝试返回上一页时发生错误，进入catch块
            // 获取错误的代码
            let code = (err as BusinessError).code;
            // 获取错误的消息
            let message = (err as BusinessError).message;
            // 在控制台打印错误信息，包括错误代码和消息
            console.error(`Failed to return to the first page.Code is ${code}, message is ${message}`)
          }// catch(err)的括号对应的反括号
        })// onClick按钮点击事件的反括号
      }// Column纵向布局的反括号
      // 设置纵向布局宽度为父容器的100%
      .width('100%')
    }// Row横向布局的反括号
    // 设置横向布局高度为父容器的100%
    .height('100%')
  }//build()方法的反括号
}// Second的结构体组件的反括号
```

### 预览视图
页面1
![页面1](./页面1.png)
账号密码为空
![用户名为空](./用户名为空.png)
![密码为空](./密码为空.png)
传用户名到下一个页面
![传参演示](./传参.jpg)
一些组件
![基本组件](./基本组件展示.png)
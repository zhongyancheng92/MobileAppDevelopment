## 一、实验代码
#### 1
```typescript{.line-numbers}
// 导入页面路由模块
import { router } from '@kit.ArkUI';
// 从基础服务工具包中导入BusinessError类
import { BusinessError } from '@kit.BasicServicesKit';
// 导入UI组件（包括Marquee和DataPanel）


@Entry // 标记这个组件为应用的入口组件
@Component // 声明这是一个组件
struct Index {
  @State message: string = 'Hello Movie'; // 声明状态变量
  @State inputValue: string = ''; // 输入框状态
  private dataPanelValues: number[] = [11, 3, 10, 2, 36, 4, 7, 22, 5];

  build() {
    Row() { // 根容器Row
      Column() { // 主内容Column
        // 新增的跑马灯组件 ↓↓↓
        Marquee({
          start: true,          // 启动滚动
          step: 12,             // 滚动步长（vp单位）
          loop: -1,             // 无限循环（-1表示无限）
          fromStart: true,      // 从头开始滚动
          src: "欢迎来到电影的世界！" // 滚动文本
        })
          .fontSize(40)         // 设置字体大小
          .fontColor('#800080');
        // ↑↑↑ 跑马灯组件结束
        // 标题文本
        Text(this.message)
          .fontSize(50)
          .fontWeight(FontWeight.Bold);

        // 跳转按钮
        Button() {
          Text('Next')
            .fontSize(30)
            .fontWeight(FontWeight.Bold);
        }
        .type(ButtonType.Capsule)
        .margin({ top: 20 })
        .backgroundColor('#E6E6FA')
        .width('40%')
        .height('5%')
        .onClick(() => {
          console.info('Succeeded in clicking the ‘Next’ button.');
          router.pushUrl({
            url: 'pages/Second',
            params: { inputValue: this.inputValue } // 添加参数传递
          })
            .then(() => {
              console.info('Succeeded in jumping to the second page.');
            })
            .catch((err: BusinessError) => {
              console.error(`Failed to jump. Code: ${err.code}, Message: ${err.message}`);
            });
        });

        // 环形数据面板
        DataPanel({
          values: this.dataPanelValues,
          max: 100,
          type: DataPanelType.Circle
        })
          .width(350)
          .height(350);
        // 新增输入框 ↓↓↓
        TextInput({ placeholder: '留下你的观影感受...' })
          .width('90%')
          .height(80)
          .fontSize(35)  // 适当缩小字体以适应高度
          .padding(15)
          .margin({ bottom: 60 })
          .backgroundColor('#F0F0F0') // 添加背景色提升可读性
          .borderRadius(25) // 添加圆角
          .onChange((value) => {
            this.inputValue = value;
          });
        // ↑↑↑ 输入框结束

      }
      .width('100%') // Column占满父容器宽度
      .margin({ top: 20 });     // 添加顶部间距避免拥挤
    }
    .height('100%') // Row占满屏幕高度
    .backgroundColor('#FFFFFF'); // 可选：设置背景色
  }
}
```
### 2
```typescript{.line-numbers}
//Second.etc
//导入页面路由模块
import{router} from '@kit.ArkUI';// 从ArkUI工具包中导入路由模块，用于页面导航
import{BusinessError} from '@kit.BasicServicesKit';// 从基础服务工具包中导入BusinessError类，用于处理业务错误

// 定义路由参数接口
interface GeneratedTypeLiteralInterface_1 {
  inputValue: string;
}
@Entry// 标记这个组件为应用的入口组件
@Component// 声明这是一个ArkUI组件
struct Second {
  @State message: string = 'Hello World';// 声明一个状态变量message，并初始化为'Hello World'，用于在界面上显示
  @State animationStatus: AnimationStatus = AnimationStatus.Paused;
  @State inputValue: string = '';
  // 新增生命周期方法获取路由参数
  aboutToAppear() {
    const params = router.getParams() as GeneratedTypeLiteralInterface_1;
    if (params) {
      this.inputValue = params.inputValue;
    }
  }

  build() {// 组件的构建函数，用于定义组件的UI结构
    Row() {// 创建一个Row容器，用于水平布局
      Column() {// 创建一个Column容器，用于垂直布局
        Search({ placeholder: '请输入搜索内容' })
          .searchButton('搜索') // 搜索按钮文字
          .width(300)
          .height(80)
          .placeholderColor(Color.Grey) // 提示文本样式
          .placeholderFont({ size: 24, weight: FontWeight.Normal }) // 提示文本字体
          .textFont({ size: 24, weight: FontWeight.Normal }) // 输入框文字字体
          .onChange((value) => { // 绑定输入变化事件
            this.inputValue = value;
          })
          .margin({ bottom: 20 }) // 与下方内容保持间距

        Text(this.message)// 显示message状态变量的内容
          .fontSize(50)// 设置字体大小为50
          .fontWeight(FontWeight.Bold)// 设置字体加粗



        Button() {// 创建一个按钮
          Text('Back')// 按钮上的文本为'Back'
            .fontSize(30)// 设置字体大小为30
            .fontWeight(FontWeight.Bold)// 设置字体加粗
        }
        .type(ButtonType.Capsule)// 设置按钮类型为胶囊形
        .margin({// 设置按钮的外边距
          top: 20// 上边距为20
        })
        .backgroundColor('#E6E6FA')// 设置按钮的背景颜色
        .width('40%')// 设置按钮的宽度为父容器的40%
        .height('5%')// 设置按钮的高度为父容器的5%
        //返回按钮绑定onClick事件，点击按钮时返回到第一页
        .onClick(() => {// 设置按钮的点击事件处理函数
          console.info('Succeeded in clicking the ‘Back’ button.')// 在控制台打印点击成功的信息
          try {
            //返回第一页
            //此函数完成页面跳转
            router.back()// 执行页面返回操作
            console.info('Succeeded in returning to the first page.')// 在控制台打印返回成功的信息
          } catch (err) {// 捕获可能发生的错误
            let code = (err as BusinessError).code;//尝试将错误对象转换为BusinessError类型，并获取错误码
            let message = (err as BusinessError).message;// 获取错误信息
            console.error(`Failed to return to the first page.Code is ${code},message is ${message}`)// 在控制台打印错误信息和错误码
          }
        })// 结束.onClick方法的括号，即Button的onClick属性设置

        Text(this.inputValue)
          .fontSize(45)  // 适当缩小字体
          .fontWeight(FontWeight.Bold)
          .margin({ top: 40 })  // 增加与按钮的间距
          .opacity(0.8)  // 添加透明度提升可读性

        // 图片动画组件
        Button(' 播放 '). width(100). padding(5). onClick(() => {this. animationStatus = AnimationStatus. Running}). margin(5)
        Button('暂停 '). width(100). padding(5). onClick(() => {this. animationStatus = AnimationStatus. Paused}). margin(5)

        //images设置图片帧信息集合
        //每一帧的帧信息 (ImageFrameInfo) 包含图片路径、图片大小、图片位置和图片播放时长信息
        ImageAnimator()
          .images([
            {
              src: $r('app.media.book01'),
              duration: 500,
              width: 220,
              height: 250,
              top: 0,
              left: 0
            },
            {
              src: $r('app.media.book02'),
              duration: 500,
              width: 220,
              height: 250,
              top: 0,
              left: 0
            },
            {
              src: $r('app.media.book03'),
              duration: 500,
              width: 220,
              height: 250,
              top: 0,
              left: 0
            },
            {
              src: $r('app.media.book04'),
              duration: 500,
              width: 220,
              height: 250,
              top: 0,
              left: 0
            }
          ])
          .state(this.animationStatus)
          .reverse(false)
          .fixedSize(false)
          .preDecode(2)
          .iterations(-1)
          .width(220)
          .height(250)
          .margin({ top: 10 }); // 与控制按钮保持间距
        // 动画组件结束
      }// 结束Column容器的构建
      .width('100%')// 设置Column容器的宽度为父容器的100%
    }// 结束Row容器的构建
    .height('100%')// 设置Row容器的高度为父容器的100%
  }// 结束build函数的构建
}// 结束Second组件的声明，是struct Second的括号
```
## 二、实验截图
![tupian](jietu1.png)
![tupian](jietu2.png)

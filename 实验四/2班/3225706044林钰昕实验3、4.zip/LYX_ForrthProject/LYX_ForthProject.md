# 实验三、四报告

> 学号：3225706044
> 
> 姓名：林钰昕
> 
> 指导老师：张凯斌
> 
> 实验日期：2025-03-27

## 一、实验目的

- 复习软件工程的基本概念和方法论；
  - 软件生命周期与开发方法论；
    - 结构化分析与设计（SAD）
    - 面向对象分析与设计（OOAD）
- 掌握OOAD与UML图的对应关系；
  - 注意：UML图只是OOAD中的一部分（代码相关的部分），并不是OOAD的全部。例如：
    - 需求分析除了UML图外，还有文档说明；
    - 总体设计除了UML图外，还有UI设计、数据库设计等；
    - 详细设计除了UML图外，还有算法实现（流程图、N-S图、伪代码）、UI的具体实现、数据库的具体实现等；
- 完成教科书中关系数据库实例的UML建模练习；

## 二、实验内容

- 阅读教科书的第9章“数据管理”的第9.4节“关系数据库的开发”；
- 根据理论课所讲内容和软件工程的相关概念，完成教科书上关系数据库实例的UML建模练习；

## 三、实验要求

- 需求分析：完成用例图和用例规约；
- 总体设计：完成类图（静态视图）和活动图（动态视图）；
- 详细设计：完成详细类图和包图；
- 撰写并提交实验报告；

## 四、实验步骤

### 1. 需求分析

#### 1.1 用例图

**Visual Paradigm制作如下：**
<div align=center><img src="用例图.png" alt="img"width="300"></div>


**PlantUML制作如下：**
<div align=center><img src="yongli.png" alt="img"width="200"></div>

#### 1.2 用例规约
**1.增加账目**
| 字段 | 内容 |
| ---- | ------ |
| 用例名 | 增加账目| 
| 执行者 | 用户  | 
| 前置条件 |系统已成功启动，数据库连接正常且已完成初始化操作 |
| 触发事件 |用户在界面上点击 “增加” 按钮 | 
| 主成功场景 | 1. 用户点击 “增加” 按钮<br>2. 系统根据预设生成待插入的账目数据行<br>3. 系统调用数据库插入接口将数据插入到账目表中<br>4. 插入成功后，系统更新界面显示操作结果 | 
| 扩展场景 |无  | 
| 最小保证 |若插入操作失败，系统将错误信息记录到日志文件中 | 
| 后置条件 |账目数据成功插入到数据库中，界面显示操作成功信息 | 
| 优先级 | 高 | 
| 频度 | 不定，根据用户需求 | 
| 输入 | 预设的账目数据（id:0, accountType:0, typeText: ' 苹果 ', amount:0） | 
| 输出 | 操作结果信息（成功或失败）| 
| 异常 | 1. 数据库连接异常，导致无法插入数据<br>2. 数据格式错误，无法插入到数据库中 | 
| 附加信息 |插入的数据 id 为 0 时，数据库会自动生成主键 | 

**2.删除账目**
| 字段 | 内容 |
| ---- | ------ |
| 用例名 | 删除账目| 
| 执行者 | 用户  | 
| 前置条件 |系统已成功启动，数据库连接正常且已完成初始化操作，数据库中存在待删除的账目数据 |
| 触发事件 |用户在界面上点击 “删除” 按钮  | 
| 主成功场景 | 1. 用户点击 “删除” 按钮<br>2. 系统根据预设的条件（id）生成删除操作的谓词<br>3. 系统调用数据库删除接口删除指定的账目数据<br>4. 删除成功后，系统更新界面显示操作结果 | 
| 扩展场景 |无| 
| 最小保证 |若删除操作失败，系统将错误信息记录到日志文件中 | 
| 后置条件 |指定的账目数据从数据库中删除，界面显示操作成功信息 | 
| 优先级 | 高 | 
| 频度 | 不定，根据用户需求 | 
| 输入 | 预设的账目数据（id:2, accountType:1, typeText: ' 栗子 ', amount:1）用于确定删除条件 | 
| 输出 |操作结果信息（成功或失败） | 
| 异常 |1. 数据库连接异常，导致无法删除数据<br>2. 未找到符合条件的数据，删除操作失败  | 
| 附加信息 |以 id 作为删除的唯一标识 | 

**3.修改账目**
| 字段 | 内容 |
| ---- | ------ |
| 用例名 | 修改账目| 
| 执行者 | 用户  | 
| 前置条件 |系统已成功启动，数据库连接正常且已完成初始化操作，数据库中存在待修改的账目数据 |
| 触发事件 |用户在界面上点击 “修改” 按钮  | 
| 主成功场景 |1. 用户点击 “修改” 按钮 <br>2.系统根据预设的新账目数据生成更新的数据行和更新操作的谓词（id）<br>3. 系统调用数据库更新接口更新指定的账目数据<br>4. 更新成功后，系统更新界面显示操作结果  | 
| 扩展场景 |无  | 
| 最小保证 |若修改操作失败，系统将错误信息记录到日志文件中 | 
| 后置条件 |指定的账目数据在数据库中更新，界面显示操作成功信息  | 
| 优先级 |高  | 
| 频度 |不定，根据用户需求  | 
| 输入 |预设的新账目数据（id:1, accountType:1, typeText: ' 栗子 ', amount:1）  | 
| 输出 |操作结果信息（成功或失败） | 
| 异常 |	1. 数据库连接异常，导致无法更新数据<br>2. 未找到符合条件的数据，更新操作失败  | 
| 附加信息 |以 id 作为更新的唯一标识 |

**4.查询账目**
| 字段 | 内容 |
| ---- | ------ |
| 用例名 | 查询账目| 
| 执行者 |用户  | 
| 前置条件 |系统已成功启动，数据库连接正常且已完成初始化操作 |
| 触发事件 |用户在界面上点击 “查询” 按钮  | 
| 主成功场景 |	1. 用户点击 “查询” 按钮 <br>2. 系统根据预设的查询条件（是否查询全部或根据金额查询）生成查询操作的谓词   <br>3. 系统调用数据库查询接口查询账目数据   <br>4. 若查询到结果，系统将结果以 JSON 格式显示在界面上；若未查询到结果，系统提示 “Query no results!”  | 
| 扩展场景 |无  | 
| 最小保证 |若查询操作失败，系统将错误信息记录到日志文件中 | 
| 后置条件 |界面显示查询结果（账目数据或无结果提示）  | 
| 优先级 |高  | 
| 频度 |不定，根据用户需求  | 
| 输入 |查询条件（是否查询全部，若不是则提供金额）  | 
| 输出 |查询结果（账目数据的 JSON 字符串或无结果提示信息） | 
| 异常 | 1. 数据库连接异常，导致无法查询数据<br>2. 查询条件格式错误，无法执行查询操作 | 
| 附加信息 |无 |


### 2. 总体设计

#### 2.1 类图（静态视图）

**Visual Paradigm制作如下：**
<div align=center><img src="总设类图.png" alt="img"></div>


**PlantUML制作如下：**
<div align=center><img src="zonglei.png" alt="img"></div>

#### 2.2 活动图（动态视图）

**Visual Paradigm制作如下：**
<div align=center><img src="活动图.png" alt="img"></div>


**PlantUML制作如下：**
<div align=center><img src="Activity.png" alt="img"></div>


### 3. 详细设计

#### 3.1 详细类图

**Visual Paradigm制作如下：**
<div align=center><img src="详设类图.png" alt="img"></div>


**PlantUML制作如下：**
<div align=center><img src="xianglei.png" alt="img"></div>



#### 3.2 包图


**PlantUML制作如下：**
<div align=center><img src="bao.png" alt="img"></div>

### 4. 编码

#### 4.1 代码实现

**CommonConstants.ets**

```typescript {.line-numbers}
import{ relationalStore } from '@kit.ArkData'
import {AccountTable } from '../database/table/AccountInterface'
export default class CommonConstants{//数据库配置常量
// class CommonConstants{ 默认不允许别的界面使用,现在是允许其他页面使用的状态
  static readonly STONE_CONFIG : relationalStore.StoreConfig={//静态常量，只允许读取，不能更改（字母全大写）
    name:'database.db',//命名数据库
    securityLevel: relationalStore.SecurityLevel.S1//键值对形式,应用第三方定义的安全等级
  }

  static readonly ACCOUNT_TABLE : AccountTable = {//创表且赋上初值
    tableName:'accountTable',
    sqlCreate:'CREATE TABLE IF NOT EXISTS accountTable(id INTEGER PRIMARY KEY AUTOINCREMENT,accountType INTEGER,typeText TEXT,amount INTEGER)',
    columns:['id','accountType','typeText','amount']
  }
}
```

**AccountInterface.ets**

```typescript {.line-numbers}
export interface AccountData{
  //interface接口，声明表中有的东西，后续不再变动，不要进行赋初值。
  // 但有时不知道后续是否进行改动，所以使用class，对Table类的定义（一个Table项）,要进行赋初值
  id:number,
  accountType:number,
  typeText:string,
  amount:number
}//初始化暂时赋值对属性来说不可能有意义的值-1
//即在SQL的表中有字段id、accountType、typeText、amount
export interface AccountTable{
  tableName:string,
  sqlCreate:string,
  columns:Array<string>
}

```

**AccountUsers.ets**

```typescript {.line-numbers}
import { relationalStore } from '@kit.ArkData';
import RdbUtil from './RdbUtil';
import RdbFunctions from './RdbFunctions';
import {AccountData} from './table/AccountInterface';
import {AccountTable} from './table/AccountInterface';
import CommonConstants from '../Constants/CommonConstants'

export default class AccountUsers{
  //实例化RdbFunctions类
  private accountUsers =new RdbFunctions(CommonConstants.ACCOUNT_TABLE.tableName,CommonConstants.ACCOUNT_TABLE.sqlCreate,CommonConstants.ACCOUNT_TABLE.columns);
  //constructor方法
  constructor(callback: Function = () => {}){
    this.accountUsers.getRdbStore(callback);
  }
  //getRdbStore方法
  getRdbStore(callback: Function=()=>{}){
  this.accountUsers.getRdbStore(callback);
}


//插入数据
  insertData(account:AccountData,callback: Function){
    const valueBucket = generateBucket(account);
    this.accountUsers.insertData(valueBucket, callback);
  }

//删除数据
  deleteData(account:AccountData,callback: Function){
    let predicates = new relationalStore.RdbPredicates(CommonConstants.ACCOUNT_TABLE.tableName);
    predicates.equalTo('id',account.id);
      this.accountUsers.deleteData(predicates, callback);
  }

//更新数据
  updateData(account:AccountData,callback: Function){
    const valueBucket = generateBucket(account);
    let predicates = new relationalStore.RdbPredicates(CommonConstants.ACCOUNT_TABLE.tableName);
    predicates.equalTo('id',account.id);
    this.accountUsers.updateDate(predicates,valueBucket,callback);
  }

//查询数据
  query(amount:number,callback:Function,isAll:boolean = true){
    let predicates = new relationalStore.RdbPredicates(CommonConstants.ACCOUNT_TABLE.tableName);
  if(!isAll){
    predicates.equalTo('amount',amount);
  }

  this.accountUsers.query(predicates,(resultSet:relationalStore.ResultSet)=>{
    let count = resultSet.rowCount;

    if(count===0 || typeof count ==='string'){
      console.log('Query no result!');
      callback();
    }
    else{
      resultSet.goToFirstRow();
      const result:AccountData[] = [];
      for(let i = 0;i<count;i++){
        let tmp:AccountData = {id:0,accountType:0,typeText:'',amount:0};
        tmp.id = resultSet.getDouble(resultSet.getColumnIndex('id'));
        tmp.accountType = resultSet.getDouble(resultSet.getColumnIndex('accountType'));
        tmp.typeText = resultSet.getString(resultSet.getColumnIndex('typeText'));
        tmp.amount = resultSet.getDouble(resultSet.getColumnIndex('amount'));

        result[i]=tmp;
        resultSet.goToNextRow();
      }
        callback(result);
    }

  })
 }
}
//generateBucket
function generateBucket(account:AccountData){
  //创建一个空对象 obj，其类型为 relationalStore.ValuesBucket。
  // 这个对象将用于存放从 account 对象中提取的相关信息。
let obj: relationalStore.ValuesBucket = {};
obj.accountType = account.accountType;
obj.typeText = account.typeText;
obj.amount = account.amount;
return obj;
}
```

**RdbFunctions.ets**

```typescript {.line-numbers}
import { relationalStore } from '@kit.ArkData';
import CommonConstants  from "../Constants/CommonConstants";
import RdbUtil from './RdbUtil'

export default class RdbFunctions extends RdbUtil{
//插入
  insertData(data:relationalStore.ValuesBucket,callback:Function=()=>{}){
    let resFlag: boolean = false;//记录操作是否成功
    const valueBucket = data;//将数据预处理，常量化
    if(this.rdbStore){//如果rdbStore存在
      this.rdbStore.insert(this.tableName,valueBucket,(err,ret)=>{//调用insert函数
        if (err){//如果插入发生错误
          console.error('Rdb',`insertData() failed,err${err}`);//控制台日志
          callback(resFlag);//返回false
          return;//返回
        }console.info(`deleteData() finished:${ret}}`);//控制台日志
        callback(!resFlag);//返回true
      });//结束函数的调用
    }
  }//插入操作结束
//删除
  deleteData(predicates:relationalStore.RdbPredicates,callback:Function =()=>{}){
    let resFlag: boolean = false;//记录操作是否成功
    if(this.rdbStore){//如果rdbStore存在
      this.rdbStore.delete(predicates,(err,ret)=>{//调用delete函数
        if (err){//如果删除发生错误
          console.error('Rdb',`deleteData() failed,err${err}`);//控制台日志
          callback(resFlag);//返回false
          return;//返回
        }console.info(`deleteData() finished:${ret}}`);//控制台日志
        callback(!resFlag);//返回true
      });//结束delete的调用
    }
  }//删除操作结束
//更新
  updateDate(predicates:relationalStore.RdbPredicates,data:relationalStore.ValuesBucket,callback:Function =()=>{}){
    let resFlag:boolean = false;
    const valueBucket = data;
    if(this.rdbStore){
      this.rdbStore.update(valueBucket,predicates,(err,ret)=>{
        if(err){
          console.error('Rdb',`updateData() failed,err${err}`);
          callback(resFlag);
          return;
        }console.info(`update() finished:${ret}`);
        callback(!resFlag);
      })
    }
  }
//查询
  query(predicates:relationalStore.RdbPredicates,callback:Function=()=>{}){
    if(this.rdbStore){
      this.rdbStore.query(predicates,(err,ret)=>{
        if(err){
          console.error('Rdb',`query() failed${err}`);
          return;
        }console.info('Rdb',`query() finished:${ret}`);
        callback(ret);
      })
    }

  }

}

```

**RdbUtil.ets**

```typescript {.line-numbers}
import { relationalStore } from '@kit.ArkData';

import CommonConstants  from "../Constants/CommonConstants";

//定义数据库工具类RdbUtil
export default class RdbUtil{
//静态属性
  rdbStore:relationalStore.RdbStore|null=null;//数据库连接实例，指定类型RdbStore和一个null类型并赋值为空
  tableName:string='';//表名
  sqlCreateTable:string='';//对表进行操作的语句
  columns:Array<string>=[];//列名数组（字段的数组？）
//动态方法
  constructor(tableName:string,sqlCreateTable:string,columns:Array<string>){//构造函数，在RdbUtil创建类的实例时，构造器自动进行初始化
    this.tableName=tableName;//tableName属性的值会等于传入的参数tableName的值
    this.sqlCreateTable=sqlCreateTable;//自动赋值
    this.columns=columns//自动赋值
  }

  getRdbStore(callback:Function = () =>{}){//通过RdbStore调用相关接口可以执行相关的数据操作
    //通过这个方法完成数据库连接的初始化，并在初始化完成后通过callback()通知调用者
    if (!callback||typeof callback==='undefined'||callback===undefined){//callBack的存在性检查（实体->=类型->值）
      console.info('getRdbStore() has no callback.');//控制台信息
      return;//返回
    }
    if (this.rdbStore != null){//判断rdbStore是否为空
      console.info('The rdbStore exists.');//控制台信息
      callback();//执行回调函数
      return;//返回
    }
    let context:Context = getContext(this) as Context;
    relationalStore.getRdbStore(context,CommonConstants.STONE_CONFIG,(err,rdb)=>{
      if(err){
        console.error(`getRdbStore() failed,err:${err}`);
        return;
      }
      this.rdbStore = rdb;
      this.rdbStore.executeSql(this.sqlCreateTable);
      console.info("getRdbStore() finished");
    })
  }
}

```

**EntryAbility.ets**

```typescript {.line-numbers}
import { AbilityConstant, ConfigurationConstant, UIAbility, Want } from '@kit.AbilityKit';
import { hilog } from '@kit.PerformanceAnalysisKit';
import { window } from '@kit.ArkUI';

const DOMAIN = 0x0000;

export default class EntryAbility extends UIAbility {
  onCreate(want: Want, launchParam: AbilityConstant.LaunchParam): void {
    this.context.getApplicationContext().setColorMode(ConfigurationConstant.ColorMode.COLOR_MODE_NOT_SET);
    hilog.info(DOMAIN, 'testTag', '%{public}s', 'Ability onCreate');
  }

  onDestroy(): void {
    hilog.info(DOMAIN, 'testTag', '%{public}s', 'Ability onDestroy');
  }

  onWindowStageCreate(windowStage: window.WindowStage): void {
    // Main window is created, set main page for this ability
    hilog.info(DOMAIN, 'testTag', '%{public}s', 'Ability onWindowStageCreate');

    windowStage.loadContent('pages/Index', (err) => {
      if (err.code) {
        hilog.error(DOMAIN, 'testTag', 'Failed to load the content. Cause: %{public}s', JSON.stringify(err));
        return;
      }
      hilog.info(DOMAIN, 'testTag', 'Succeeded in loading the content.');
    });
  }

  onWindowStageDestroy(): void {
    // Main window is destroyed, release UI related resources
    hilog.info(DOMAIN, 'testTag', '%{public}s', 'Ability onWindowStageDestroy');
  }

  onForeground(): void {
    // Ability has brought to foreground
    hilog.info(DOMAIN, 'testTag', '%{public}s', 'Ability onForeground');
  }

  onBackground(): void {
    // Ability has back to background
    hilog.info(DOMAIN, 'testTag', '%{public}s', 'Ability onBackground');
  }
}
```

**EntryBackupAbility.ets**

```typescript {.line-numbers}
import { hilog } from '@kit.PerformanceAnalysisKit';
import { BackupExtensionAbility, BundleVersion } from '@kit.CoreFileKit';

const DOMAIN = 0x0000;

export default class EntryBackupAbility extends BackupExtensionAbility {
  async onBackup() {
    hilog.info(DOMAIN, 'testTag', 'onBackup ok');
    await Promise.resolve();
  }

  async onRestore(bundleVersion: BundleVersion) {
    hilog.info(DOMAIN, 'testTag', 'onRestore ok %{public}s', JSON.stringify(bundleVersion));
    await Promise.resolve();
  }
}
```

**Index.ets**

```typescript {.line-numbers}
import { AccountData } from '../Common/database/table/AccountInterface';
import { AccountTable } from '../Common/database/table/AccountInterface';
import AccountUsers from '../Common/database/AccountUsers';
import { relationalStore } from '@kit.ArkData';


@Entry
@Component
struct Index {
  @State message: string = '欢迎来到福建农林大学！';
  private initialMessage: string = '欢迎来到福建农林大学！'; // 记录初始的message
  private accountUsers = new AccountUsers(() => {
    console.info("Database initialized successfully");
  });
  // 滚动条控制器
  private scroller: Scroller = new Scroller();

  build() {
    Column() {
      // 跑马灯组件，放在最顶端
      Marquee({
        start: true,
        step: 7,
        loop: -1,
        fromStart: true,
        src: "FAFUers，欢迎来到福建农林大学！"
      })
        .fontSize(25)
        .fontColor('#6f210d')
        .width('100%');
      // 使用 Scroll 组件包裹需要滚动的内容
      Scroll(this.scroller) {
        Column() // 将 Row 改为 Column 并设置固定高度

        {
          Stack({ alignContent: Alignment.TopStart }) {
            // 创建一个垂直布局容器，子元素间距为 10
            Column({ space: 10 }) {
              // 添加返回按钮，放在图片上方
              Button() {
                Text('\u2190') // 使用 Unicode 字符表示左箭头
                  .fontSize(20)
                  .fontWeight(FontWeight.Bold)
                  .fontColor('black');
              }
              .width(40)
              .height(40)
              .backgroundColor('#F0F0F0')
              .borderRadius(20)
              .onClick(() => {
                this.message = this.initialMessage; // 恢复初始的message
              });
              // 创建一个图片组件，图片资源为 'app.media.FAFU'
              Image($r('app.media.FAFU'))
                .width(100)
                .height(100);
              Text(this.message)
                .fontSize(35)
                .fontColor('#6f210d')
                .fontWeight(FontWeight.Bold);
              // 按钮布局调整为两行两列
              Column() {
                Row() {
                  //增加
                  Button(('增加'), { type: ButtonType.Capsule })
                    .width(140).fontSize(40).fontWeight(FontWeight.Medium).backgroundColor('#ffc0cb').margin({ top: 20, bottom: 20 })
                    .onClick(() => {
                      let newAccount: AccountData = { id: 0, accountType: 0, typeText: 'apple', amount: 0 };
                      this.accountUsers.insertData(newAccount, () => {
                        console.info("insert succeed");
                      });
                    });
                  //查询
                  Button(('查询'), { type: ButtonType.Capsule })
                    .width(140).fontSize(40).fontWeight(FontWeight.Medium).backgroundColor('#c3e3ef').margin({ top: 20, bottom: 20 })
                    .onClick(() => {
                      this.accountUsers.query(0, (result: AccountData[]) => {
                        this.message = JSON.stringify(result);
                        console.info("query succeed"); // 修改查询回调的日志
                      }, true);
                    });
                }
                Row() {
                  //修改
                  Button(('修改'), { type: ButtonType.Capsule })
                    .width(140).fontSize(40).fontWeight(FontWeight.Medium).backgroundColor('#e6d6e9').margin({ top: 20, bottom: 20 })
                    .onClick(() => {
                      let newAccount: AccountData = { id: 1, accountType: 1, typeText: 'banana', amount: 1 };
                      this.accountUsers.updateData(newAccount, () => {
                        console.info("update succeed"); // 修改更新回调的日志
                      });
                    });
                  //删除
                  Button(('删除'), { type: ButtonType.Capsule })
                    .width(140).fontSize(40).fontWeight(FontWeight.Medium).backgroundColor('#fcedbe').margin({ top: 20, bottom: 20 })
                    .onClick(() => {
                      let newAccount: AccountData = { id: 2, accountType: 1, typeText: 'banana', amount: 1 };
                      this.accountUsers.deleteData(newAccount, () => {
                        console.info("delete succeed"); // 修改删除回调的日志
                      });
                    });
                }
              }
              Column() {
                DatePicker({
                  // 设置日期选择器的起始日期为 '1970-1-1'
                  start: new Date('1970-1-1'),
                  // 设置日期选择器的结束日期为 '2100-1-1'
                  end: new Date('2100-1-1'),
                  // 设置日期选择器的默认选中日期为 '2023-02-15'
                  selected: new Date('2023-02-15'),
                })
                  // 不显示农历
                  .lunar(false)
                    // 当选择日期时，触发该事件，打印选择的日期信息
                  .onChange((value: DatePickerResult) => {
                    console.info('select current date is:' + JSON.stringify(value))
                  })
                TextClock()
                  .margin(20)
                  .fontSize(30)
                  .format('yyyy/MM/dd    HH:mm:ss');
              }
            }.width('100%')
          }
        }
      }
      .scrollBar(BarState.Off) // 关闭默认滚动条
      .scrollable(ScrollDirection.Vertical); // 设置为垂直滚动

      // 添加 ScrollBar 组件
      ScrollBar({ scroller: this.scroller, direction: ScrollBarDirection.Vertical, state: BarState.Auto }) {
        Text()
          .width(10)
          .height(80)
          .backgroundColor('gray') // 将滚动条颜色设置为灰色
          .borderRadius(5);
      }.width(10).backgroundColor('#ededed');
    }
  }
}
```



#### 4.2 结果验证

##### 4.2.1 初始页面：
<div align=center><img src="Fengmian.png" alt="img"width="300"></div>

##### 4.2.2 增加以下组件：

1、组件一：Marquee跑马灯

2、组件二：Image图片

3、组件三：DatePicker选择日期

4、组件四：TextClock系统时间

5、组件五：Botton返回按钮

6、组件六：Scroll和ScrollBar滚动条


##### 4.2.3 点击增、删、改、查
1、先点击删除，再点击查询，则为空：

<div align=center><img src="shanchu.png" alt="img"width="300"></div>

2、点击增加，再点击查询，有新事件出现：

<div align=center><img src="zengjia.png" alt="img"width="300"></div>

3、点击修改，再点击查询，修改成功：
<div align=center><img src="xiugai.png" alt="img"width="300"></div>

4、点击上方返回按钮，可返回初始界面：
<div align=center><img src="fanhui.png" alt="img"width="300"></div>

5、若增加过多，拉动页面，可往下拉动：
<div align=center><img src="gundong.png" alt="img"width="300"></div>


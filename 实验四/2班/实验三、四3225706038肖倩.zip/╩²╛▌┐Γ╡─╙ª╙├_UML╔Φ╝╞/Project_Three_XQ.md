# 实验三报告

> 学号：3225706038
> 
> 姓名：肖倩
> 
> 指导老师：张凯斌
> 
> 实验日期：2025-03-22

## 一、实验目的

- 复习软件工程的基本概念和方法论；
  - 软件生命周期与开发方法论；
    - 结构化分析与设计（SAD）
    - 面向对象分析与设计（OOAD）
- 掌握OOAD与UML图的对应关系；
    - 需求分析除了UML图外，还有文档说明；
    - 总体设计除了UML图外，还有UI设计、数据库设计等；
    - 详细设计除了UML图外，还有算法实现（流程图、N-S图、伪代码）、UI的具体实现、数据库的具体实现等；
- 完成教科书中关系数据库实例的UML建模练习

## 二、实验内容

- 阅读教科书的第9章“数据管理”的第9.4节“关系数据库的开发”；
- 根据理论课所讲内容和软件工程的相关概念，完成教科书上关系数据库实例的UML建模练习；

## 三、实验要求

- 需求分析：完成用例图和用例规约；
- 总体设计：完成类图（静态视图）和活动图（动态视图）；
- 详细设计：完成详细类图和包图；
- 撰写并提交实验报告；

## 四、实验步骤

### 1. 需求分析

#### 1.1 用例图
![alt text](image-12.png)
#### 1.2 用例规约

| 用例名 | 点击添加 | 点击删除 | 点击查询 | 点击修改 |
| :------: | :------: | :------: | :------: | :------: |
| 执行者 | Uers | Uers | Uers | Uers |
| 前置条件 | 数据库连接正常 | 数据库连接正常 | 数据库连接正常 | 数据库连接正常 |
| 触发事件 | 点击“添加”按钮 | 点击“删除”按钮 | 点击“查询”按钮 | 点击“修改”按钮 |
| 主成功场景 | 数据库成功添加新用户 |  数据库成功删除指定用户 | UI界面显示所有记录 |  数据库成功修改用户信息 |
| 后置条件 | 记录已保存到数据库 | 记录已被从数据库中移除 | 查询结果显示在界面上 | 记录已更新到数据库 |


### 2. 总体设计

#### 2.1 类图（静态视图）
![alt text](image-14.png)
#### 2.2 活动图（动态视图）
![alt text](image-3.png)
### 3. 详细设计

#### 3.1 详细类图
![alt text](image-13.png)
#### 3.2 包图
![alt text](image-11.png)
### 4.1 代码实现
#### index页面
****
```typescript
//index页面
import { router } from '@kit.ArkUI';//导入跳转模块中的router对象
import { BusinessError } from '@kit.BasicServicesKit';//导入模块中的Business


@Entry//定义入口点
@Component//定义这是一个组件
struct Index {//定义名为Index的结构体
  @State name:string = 'xiaoqian';//定义名为name的类字段，并附上初值
  @State number_id:string ='3225706038';//定义名为number_id的类字段，并附上初值



  build() {//定义界面背景
    Row() {//定义一行
      Column() {//定义一列

//插入图片
        Row(){Image($r('app.media.digit_fafu')).height('十').width(350)}.position({x:0,y:-190})
        //将图片放在行容器里，并设置位置

//输入框
        TextInput({placeholder:'姓名'}).placeholderColor(Color.Gray).placeholderFont({size:14,weight:400}).caretColor(Color.Blue).width(200).height(47).fontSize(24).fontColor(Color.Black)//设置姓名输入框及输入框的各参数
            .onChange((value) => {this.name = value;})//及时更新name的具体值
        TextInput({placeholder:'学号'}).placeholderColor(Color.Gray).placeholderFont({size:14,weight:400}).caretColor(Color.Blue).width(200).height(47).fontSize(24).fontColor(Color.Black).margin(5)//设置学号输入框及输入框的各参数
        TextInput({placeholder:'设置密码'}).placeholderColor(Color.Gray).placeholderFont({size:14,weight:400}).caretColor(Color.Blue).width(200).height(47).fontSize(12).fontColor(Color.Black).margin(1)//设置密码输入框及输入框的各参数
            .type(InputType.Password).maxLength(12).showPasswordIcon(true)//设置为密码的文本输入框类型


//添加提交按钮
        Button() {Text('注册').fontSize(20).fontWeight(FontWeight.Bold)}//定义按钮里的文本
        .type(ButtonType.Capsule).margin({ top: 20 }).backgroundColor('#0D9FFB').height("6%").width("28%")//定义按钮的样式
//按钮绑定onclick事件，点击时跳转
        .onClick(() => {console.info(`Succeeded in clicking the 'Next' button.`)//控制台记录按钮被点击
//跳转到第二页
          router.pushUrl({ url: 'pages/Second', params:{name:this.name,number_id:this.number_id} })//跳转到Second页面的同时将用户输入的姓名、学号的具体值一起传过去
            .then(() => {console.info('Succeeded in jumping to the second page')})//控制台记录成功跳转
            .catch((err: BusinessError) => {console.error(`Failed to jump to the secong page.Code is ${err.code},message is ${err.message}`) }) //跳转失败时捕获错误，控制台记录跳转失败，输出错误日志
        })//结束onClick方法


//小组件及滚动条

        Row(){//定义一行
          //希望LoadingProgress组件不要太大，并且和滚动条在同一行
          Column(){LoadingProgress().color(Color.Blue)}.width('9%')//分出一列给LoadingProgress组件
          Column(){Marquee({ start:true, step:5, loop:-1, fromStart:true, src:"福建农林大学坐落于福建省会福州，是一所以农林科学、生命科学为优势和特色，理、工、经、管、文、法、艺等多学科协调发展的省属重点大学，是农业农村部与福建省人民政府共建高校、国家林业和草原局与福建省人民政府共建高校，是福建省高水平大学建设高校、福建省一流大学建设高校、福建省“双一流”建设A类高校。" }).fontSize(20)
            //滚动条组件的相关设置
          }.width('95%')}.height('10%').position({x:0,y:420})//结束此行的定义
      }.width("100%").padding(0) //结束列的内部定义并清除默认内边距

    }.height("100%")//结束行的内部定义
  }//结束屏幕的定义
}//结束结构体的定义
```
#### Second页面
****
```typescript

import { router } from '@kit.ArkUI';//导入跳转模块中的router对象
import { BusinessError } from '@kit.BasicServicesKit';//导入模块中的Business

class RouterParams {//规范路由参数的格式
  name: string;//传递的参数名name，文字类型
  constructor(name: string) {this.name = name;}}//强制检查传入的name的类型，如果不是string类型，就报错


@Styles
function itemStyle() {
  .width(336).height(621).margin({ top: 48, left: 2,right:2 }).borderRadius(24)/*圆角24vp*/ .backgroundColor('#D3D3D3')}
//使用@Styles先设置好Stepper里每个StepperItem页面的公共样式

@Entry//定义组件入口
@Component//声明这是一个自定义组件


struct Second {//定义名为Second的结构体

  @State Name: string = (router.getParams() as RouterParams).name;//从路由参数中获取name并将名字定义为Name（用类型断言保证name的类型）

  build() {//屏幕界面
    Row(){//一行
      Column(){//一列
        Text(`Hello!   ${this.Name}`).fontSize(34)//输出文本，文本中使用${}引用Name


        //步骤导航组件
        Stepper({index:0}){//设置Stepper当前StepperItem的索引值

          StepperItem() {//第一页
            Column(){//一列
              Row(){Text('请选择你的性别').fontSize(30)}.height(70)//利用Row划分界面，输出文本


              //选择性别
              Row() {Checkbox({ name: 'checkbox1', group: 'checkboxGroup' })//复选框
                .select(true).selectedColor(0xed6f21).shape(CheckBoxShape.CIRCLE)//复选框样式设置
                .onChange((value: boolean) => {console.info('Checkbox1 change is' + value)})//及时更新和控制台信息
                Text(`女`).fontSize(20)}.height(70)//第一个复选框后跟着的文本
              Row() {Checkbox({ name: 'checkbox2', group: 'checkboxGroup' })//复选框
                .select(false).selectedColor(0x39a2db).shape(CheckBoxShape.ROUNDED_SQUARE)//复选框样式设置
                .onChange((value: boolean) => {console.info('Checkbox2 change is' + value)})//及时更新和控制台信息
                Text('男').fontSize(20)}//第二个复选框后跟着的文本


              //选择出生日期
              Row(){Text('请选择你的出生日期').fontSize(30)}.height(70).margin({top:30})//输出文本
              Row(){DatePicker({ start:new Date('1940-1-1'), end:new Date('2020-1-1') })}.height(190)//选择日期的滑动选择器组件


              //添加图片
              Row(){//一行
                Image($r('app.media.QR')).height(80).width(80)//图片
                Text('欢迎关注福建农林大学微信公众号').margin({top:10})//文字
              }.height(30).margin({top:90})//尺寸和位置
            }.itemStyle()//第一页的样式

          }.nextLabel('下一页')//下一页按钮

          StepperItem(){//第二页
            Row(){//一行
              Column(){//一列

                Row(){Text('请选择你的专业').fontSize(30)}//输出文本
                .alignItems(VerticalAlign.Top).margin({top:-60})//位置的设置


                //选择专业
                Row(){TextPicker({ range:['环境科学与工程','空间信息与数字技术','农业资源与环境'],selected:1 })//滑动选择文本内容的组件
                  .defaultPickerItemHeight(30).margin({top:30}).width(300)//位置的设置
                }.height(200).alignItems(VerticalAlign.Center)//位置的设置
              }.width("100%")//列的宽度
            }.height("100%")//行的大小
            .itemStyle()//页面的样式
          }.nextLabel('完成').prevLabel('上一页')//下方按钮的设置


          StepperItem() {//第三页
            Column() {//一列

              Text('注册成功').fontSize(50).fontColor(Color.Green)//输出文本
              TextClock().margin(20).fontSize(25).format('yyyy年MM月dd日 HH:mm')

            }//结束列的定义
          }//结束第三页的定义


        }
        .onFinish(() => {
          // 此处可处理点击最后一页的Finish时的逻辑，例如路由跳转等
          router.pushUrl({ url: 'pages/Third'})//跳转到Second页面的同时将用户输入的姓名、学号的具体值一起传过去
            .then(() => {console.info('Succeeded in jumping to the second page')})//控制台记录成功跳转
            .catch((err: BusinessError) => {console.error(`Failed to jump to the secong page.Code is ${err.code},message is ${err.message}`) }) //跳转失败时捕获错误，控制台记录跳转失败，输出错误日志
          console.info('onFinish')}//结束onClick方法
          )
        }//结束Stepper的定义
      }//结束列的定义
    }//结束行的定义
  }//结束屏幕的定义
//结束结构体的定义
```
#### Third
****
```typescript

import {AccountData} from '../Common/database/table/AccountInterface';
import {AccountTable} from '../Common/database/table/AccountInterface';
import AccountUsers from '../Common/database/AccountUsers';
import { relationalStore } from '@kit.ArkData';
@Entry
@Component
struct Index {
  @State message: string = 'Hello World';
  //实例化数据库
  private accountUsers = new AccountUsers(() => {
    console.info("Database initialized successfully");
  });
  build() {
    Row(){
      Column(){
        Text(this.message).fontSize(50).fontWeight(FontWeight.Bold)
        //增加
        Button(('增加'),{ type:ButtonType.Capsule})
          .width(140).fontSize(40).fontWeight(FontWeight.Medium).margin({top:20,bottom:20})
          .onClick(()=>{
            let newAccount:AccountData={id:0,accountType:0,typeText:'apple',amount:0};
            this.accountUsers.insertData(newAccount,()=>{
              console.info("insert succeed")
            })
          })
        //查询
        Button(('查询'),{ type:ButtonType.Capsule})
          .width(140).fontSize(40).fontWeight(FontWeight.Medium).margin({top:20,bottom:20})
          .onClick(()=>{

            this.accountUsers.query(0,(result:AccountData[])=>{
              this.message = JSON.stringify(result);
              console.info("insert succeed")
            },true)
          })
        //修改
        Button(('修改'),{ type:ButtonType.Capsule})
          .width(140).fontSize(40).fontWeight(FontWeight.Medium).margin({top:20,bottom:20})
          .onClick(()=>{
            let newAccount:AccountData={id:1,accountType:1,typeText:'banana',amount:1};
            this.accountUsers.updateData(newAccount,()=>{
              console.info("insert succeed")
            })
          })
        //删除
        Button(('删除'),{ type:ButtonType.Capsule})
          .width(140).fontSize(40).fontWeight(FontWeight.Medium).margin({top:20,bottom:20})
          .onClick(()=>{
            let newAccount:AccountData={id:2,accountType:1,typeText:'banana',amount:1};
            this.accountUsers.deleteData(newAccount,()=>{
              console.info("insert succeed")
            })
          })
      }.width('100%')
    }.height('100%')
  }
}
```
#### CommonConstants
****
```typescript
import{ relationalStore } from '@kit.ArkData'
import {AccountTable } from '../database/table/AccountInterface'
export default class CommonConstants{//数据库配置常量
// class CommonConstants{ 默认不允许别的界面使用,现在是允许其他页面使用的状态
  static readonly STONE_CONFIG : relationalStore.StoreConfig={//静态常量，只允许读取，不能更改（字母全大写）
    name:'database.db',//命名数据库
    securityLevel: relationalStore.SecurityLevel.S1//键值对形式,应用第三方定义的安全等级
  }

  static readonly ACCOUNT_TABLE : AccountTable = {//创表且赋上初值
    tableName:'accountTable',
    sqlCreate:'CREATE TABLE IF NOT EXISTS accountTable(id INTEGER PRIMARY KEY AUTOINCREMENT,accountType INTEGER,typeText TEXT,amount INTEGER)',
    columns:['id','accountType','typeText','amount']
  }
}
```
#### AccountInterface
****
```typescript

export interface AccountData{
  //interface接口，声明表中有的东西，后续不再变动，不要进行赋初值。
  // 但有时不知道后续是否进行改动，所以使用class，对Table类的定义（一个Table项）,要进行赋初值
  id:number,
  accountType:number,
  typeText:string,
  amount:number
}//初始化暂时赋值对属性来说不可能有意义的值-1
//即在SQL的表中有字段id、accountType、typeText、amount
export interface AccountTable{
  tableName:string,
  sqlCreate:string,
  columns:Array<string>
}
```
#### AccountUsers
****
```typescript
import { relationalStore } from '@kit.ArkData';
import RdbUtil from './RdbUtil';
import RdbFunctions from './RdbFunctions';
import {AccountData} from './table/AccountInterface';
import {AccountTable} from './table/AccountInterface';
import CommonConstants from '../Constants/CommonConstants'

export default class AccountUsers{
  //实例化RdbFunctions类
  private accountUsers =new RdbFunctions(CommonConstants.ACCOUNT_TABLE.tableName,CommonConstants.ACCOUNT_TABLE.sqlCreate,CommonConstants.ACCOUNT_TABLE.columns);
  //constructor方法
  constructor(callback: Function = () => {}){
    this.accountUsers.getRdbStore(callback);
  }
  //getRdbStore方法调用位置
  getRdbStore(callback: Function=()=>{}){
  this.accountUsers.getRdbStore(callback);
}


//插入数据
  insertData(account:AccountData,callback: Function){
    const valueBucket = generateBucket(account);//调用generation函数，转换account的格式
    this.accountUsers.insertData(valueBucket, callback);
  }

//删除数据
  deleteData(account:AccountData,callback: Function){
    let predicates = new relationalStore.RdbPredicates(CommonConstants.ACCOUNT_TABLE.tableName);//创建predicates对象，以确定删除的条件
    predicates.equalTo('id',account.id);//删除条件：id相同
      this.accountUsers.deleteData(predicates, callback);//调用方法删除
  }

//更新数据
  updateData(account:AccountData,callback: Function){
    const valueBucket = generateBucket(account);
    let predicates = new relationalStore.RdbPredicates(CommonConstants.ACCOUNT_TABLE.tableName);
    predicates.equalTo('id',account.id);
    this.accountUsers.updateDate(predicates,valueBucket,callback);
  }

//查询数据
  query(amount:number,callback:Function,isAll:boolean = true){
    let predicates = new relationalStore.RdbPredicates(CommonConstants.ACCOUNT_TABLE.tableName);
    //isAll,控制查询的范围，当其值为true时，查询所有记录
    //其值为false时（即！isAll为true，进入if语句），照以下的条件查询
    if(!isAll){
    predicates.equalTo('amount',amount);
  }

    this.accountUsers.query(predicates, (resultSet: relationalStore.ResultSet) => {//调用查询方法查询
      let count = resultSet.rowCount;//获取满足条件的总行数

      if (count === 0 || typeof count === 'string') {//如果没有查找到符合条件的记录
        console.log('Query no result!');//控制台日志
        callback();//回调函数
      }
        else {//有符合条件
        resultSet.goToFirstRow();//将结果集定位到第一行
        const result: AccountData[] = [];//定义参数result以接收查询结果

        for (let i = 0; i < count; i++) {//利用for循环遍历满足条件的记录
          //建立临时数组以存储符合条件的记录
          let tmp: AccountData = { id: 0, accountType: 0, typeText: '',amount : 0 };
          //使用getColumnIndex（‘’）获取相关信息

        tmp.id = resultSet.getDouble(resultSet.getColumnIndex('id'));
        tmp.accountType = resultSet.getDouble(resultSet.getColumnIndex('accountType'));
        tmp.typeText = resultSet.getString(resultSet.getColumnIndex('typeText'));
        tmp.amount = resultSet.getDouble(resultSet.getColumnIndex('amount'));

        result[i]=tmp;
        resultSet.goToNextRow();
      }
        callback(result);
    }

  })
 }
}
//generateBucket
function generateBucket(account:AccountData){
  //创建一个空对象 obj，其类型为 relationalStore.ValuesBucket。
  // 这个对象将用于存放从 account 对象中提取的相关信息。
let obj: relationalStore.ValuesBucket = {};
obj.accountType = account.accountType;
obj.typeText = account.typeText;
obj.amount = account.amount;
return obj;
}

```
#### RdbFunctions
****
```typescript
import { relationalStore } from '@kit.ArkData';
import CommonConstants  from "../Constants/CommonConstants";
import RdbUtil from './RdbUtil'

export default class RdbFunctions extends RdbUtil{
//插入
  insertData(data:relationalStore.ValuesBucket,callback:Function=()=>{}){
    let resFlag: boolean = false;//记录操作是否成功
    const valueBucket = data;//将数据预处理，常量化
    if(this.rdbStore){//如果rdbStore存在
      this.rdbStore.insert(this.tableName,valueBucket,(err,ret)=>{//调用insert函数
        if (err){//如果插入发生错误
          console.error('Rdb',`insertData() failed,err${err}`);//控制台日志
          callback(resFlag);//返回false
          return;//返回
        }console.info(`deleteData() finished:${ret}}`);//控制台日志
        callback(!resFlag);//返回true
      });//结束函数的调用
    }
  }//插入操作结束
//删除
  deleteData(predicates:relationalStore.RdbPredicates,callback:Function =()=>{}){
    let resFlag: boolean = false;
    if(this.rdbStore){
      this.rdbStore.delete(predicates,(err,ret)=>{
        if (err){
          console.error('Rdb',`deleteData() failed,err${err}`);
          callback(resFlag);
          return;
        }console.info(`deleteData() finished:${ret}}`);
        callback(!resFlag);
      });
    }
  }
//更新
  updateDate(predicates:relationalStore.RdbPredicates,data:relationalStore.ValuesBucket,callback:Function =()=>{}){
    let resFlag:boolean = false;
    const valueBucket = data;
    if(this.rdbStore){
      this.rdbStore.update(valueBucket,predicates,(err,ret)=>{
        if(err){
          console.error('Rdb',`updateData() failed,err${err}`);
          callback(resFlag);
          return;
        }console.info(`update() finished:${ret}`);
        callback(!resFlag);
      })
    }
  }
//查询
  query(predicates:relationalStore.RdbPredicates,callback:Function=()=>{}){
    if(this.rdbStore){
      this.rdbStore.query(predicates,(err,ret)=>{//查询操作
        if(err){
          console.error('Rdb',`query() failed${err}`);
          return;
        }console.info('Rdb',`query() finished:${ret}`);
        callback(ret);
      })
    }

  }

}

```
#### RdbUtil
****
```typescript
import { relationalStore } from '@kit.ArkData';

import CommonConstants  from "../Constants/CommonConstants";

//定义数据库工具类RdbUtil
export default class RdbUtil{

//静态属性
  rdbStore:relationalStore.RdbStore|null=null;//数据库连接实例，指定类型RdbStore和一个null类型并赋值为空
  tableName:string='';//表名
  sqlCreateTable:string='';//对表进行操作的语句
  columns:Array<string>=[];//列名数组
//动态方法
  constructor(tableName:string,sqlCreateTable:string,columns:Array<string>){//构造函数，在RdbUtil创建类的实例时，构造器自动进行初始化
    //自动赋值
    this.tableName=tableName;//tableName属性的值会等于传入的参数tableName的值
    this.sqlCreateTable=sqlCreateTable;
    this.columns=columns
  }
//定义位置
  getRdbStore(callback:Function = () =>{}){//通过RdbStore调用相关接口可以执行相关的数据操作
    //通过这个方法完成数据库连接的初始化，并在初始化完成后通过callback()通知调用者
    if (!callback||typeof callback==='undefined'||callback===undefined){//callBack的存在性检查（实体->=类型->值）
      console.info('getRdbStore() has no callback.');
      return;
    }
    if (this.rdbStore != null){//判断rdbStore是否为空
      console.info('The rdbStore exists.');
      callback();//执行回调函数
      return;
    }
    let context:Context = getContext(this) as Context;//获取当前应用程序上下文
    relationalStore.getRdbStore(context,CommonConstants.STONE_CONFIG,(err,rdb)=>{//连接数据库
      if(err){//如果错误
        console.error(`getRdbStore() failed,err:${err}`);
        return;
      }
      this.rdbStore = rdb;////将getRdbStore返回的数据库连接对象（即rdb）保存到当前类实例的 rdbStore 属性中
      this.rdbStore.executeSql(this.sqlCreateTable);//初始化表结构
      console.info("getRdbStore() finished");
    })
  }
}
```
#### 4.2 结果验证
![alt text](image-15.png)||![alt text](image-16.png)
添加数据并查询         ||      修改数据并查询
![alt text](image-17.png)
删除id为2的记录
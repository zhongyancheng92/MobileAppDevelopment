# 实验二报告

> 学号：3225706044
> 
> 姓名：林钰昕
> 
> 指导老师：张凯斌
> 
> 实验日期：2025-03-13

## 一、整体代码展示

### 1、页面一

**Index.ets**

```typescript {.line-numbers}
// 从 '@kit.ArkUI' 模块导入 router 对象，用于页面跳转
import { router } from '@kit.ArkUI';
// 从 '@kit.BasicServicesKit' 模块导入 BusinessError 类，用于处理业务错误
import { BusinessError } from '@kit.BasicServicesKit';

// 使用 @Entry 装饰器标记该组件为入口组件
// 使用 @Component 装饰器将该类标记为 ArkTS 组件
@Entry
@Component
struct Index {
  // 使用 @State 装饰器定义响应式状态变量 message，初始值为欢迎信息和创建账号提示
  @State
  message: string = '欢迎来到福建农林大学！\n请为您创建一个账号。';
  // 使用 @State 装饰器定义响应式状态变量 name，初始值为空字符串
  @State
  name: string = '';
  // 使用 @State 装饰器定义响应式状态变量 studentId，初始值为空字符串
  @State
  studentId: string = '';
  // 使用 @State 装饰器定义响应式状态变量 gender，初始值为 '男'
  @State
  gender: string = '男';
  // 使用 @State 装饰器定义响应式状态变量 campus，初始值为 '金山校区'
  @State
  campus: string = '金山校区';

  // 组件的构建方法，用于定义组件的 UI 结构
  build() {
    // 创建一个水平布局容器
    Row() {
      // 创建一个堆叠布局容器，内容顶部左对齐
      Stack({ alignContent: Alignment.TopStart }) {
        // 创建一个跑马灯组件
        Marquee({
          // 跑马灯开始滚动
          start: true,
          // 滚动步长为 7
          step: 7,
          // 无限循环滚动
          loop: -1,
          // 从起始位置开始滚动
          fromStart: true,
          // 跑马灯显示的文本内容
          src: "FAFUers，欢迎来到福建农林大学！"
        })
          // 设置跑马灯文本的字体大小为 25
          .fontSize(25)
            // 设置跑马灯文本的颜色为 '#6f210d'
          .fontColor('#6f210d')
            // 设置跑马灯的宽度为父容器的 100%
          .width('100%');

        // 创建一个垂直布局容器，子元素间距为 10
        Column({ space: 10 }) {
          // 创建一个图片组件，图片资源为 'app.media.FAFU'
          Image($r('app.media.FAFU'))
            // 设置图片的宽度为 100
            .width(100)
              // 设置图片的高度为 100
            .height(100);

          // 创建一个文本组件，显示 message 状态变量的值
          Text(this.message)
            // 设置文本的字体大小为 25
            .fontSize(25)
              // 设置文本的字体加粗
            .fontWeight(FontWeight.Bold)
              // 设置文本的颜色为 '#6f210d'
            .fontColor('#6f210d');

          // 创建一个水平布局容器，子元素间距为 10
          Row({ space: 10 }) {
            // 创建一个文本组件，显示 '姓名：'
            Text('姓名：')
              // 设置文本的字体大小为 20
              .fontSize(20)
                // 设置文本的颜色为 '#6f210d'
              .fontColor('#6f210d');
            // 创建一个文本输入框组件，占位符为 '请输入姓名……'
            TextInput({ placeholder: '请输入姓名……' })
              // 设置占位符文本的颜色为灰色
              .placeholderColor(Color.Grey)
                // 设置占位符文本的字体大小为 16，字体粗细为 400
              .placeholderFont({ size: 16, weight: 400 })
                // 设置输入框光标颜色为蓝色
              .caretColor(Color.Blue)
                // 设置输入框的宽度为 200
              .width(200)
                // 设置输入框的高度为 40
              .height(40)
                // 设置输入框的外边距为 20
              .margin(20)
                // 设置输入框文本的字体大小为 24
              .fontSize(24)
                // 设置输入框文本的颜色为黑色
              .fontColor(Color.Black)
                // 当输入框内容改变时，更新 name 状态变量的值
              .onChange((value: string) => {
                this.name = value;
              });
          }

          // 创建一个水平布局容器，子元素间距为 10
          Row({ space: 10 }) {
            // 创建一个文本组件，显示 '学号：'
            Text('学号：')
              // 设置文本的字体大小为 20
              .fontSize(20)
                // 设置文本的颜色为 '#6f210d'
              .fontColor('#6f210d');
            // 创建一个文本输入框组件，占位符为 '请输入学号……'
            TextInput({ placeholder: '请输入学号……' })
              // 设置占位符文本的颜色为灰色
              .placeholderColor(Color.Grey)
                // 设置占位符文本的字体大小为 16，字体粗细为 400
              .placeholderFont({ size: 16, weight: 400 })
                // 设置输入框光标颜色为蓝色
              .caretColor(Color.Blue)
                // 设置输入框的宽度为 200
              .width(200)
                // 设置输入框的高度为 40
              .height(40)
                // 设置输入框的外边距为 20
              .margin(20)
                // 设置输入框文本的字体大小为 24
              .fontSize(24)
                // 设置输入框文本的颜色为黑色
              .fontColor(Color.Black)
                // 当输入框内容改变时，更新 studentId 状态变量的值
              .onChange((value: string) => {
                this.studentId = value;
              });
          }

          // 创建一个水平布局容器，子元素间距为 10
          Row({ space: 10 }) {
            // 创建一个文本组件，显示 '密码：'
            Text('密码：')
              // 设置文本的字体大小为 20
              .fontSize(20)
                // 设置文本的颜色为 '#6f210d'
              .fontColor('#6f210d');
            // 创建一个文本输入框组件，占位符为 '请输入密码……'
            TextInput({ placeholder: '请输入密码……' })
              // 设置输入框的宽度为 200
              .width(200)
                // 设置输入框的高度为 40
              .height(40)
                // 设置输入框的外边距为 20
              .margin(20)
                // 设置输入框文本的字体大小为 24
              .fontSize(24)
                // 设置输入框类型为密码输入框
              .type(InputType.Password)
                // 设置输入框最大输入长度为 9
              .maxLength(9)
                // 显示密码可见切换图标
              .showPasswordIcon(true);
          }

          // 创建一个水平布局容器，子元素间距为 10
          Row({ space: 10 }) {
            // 创建一个文本组件，显示 '性别：'
            Text('性别：')
              // 设置文本的字体大小为 20
              .fontSize(20)
                // 设置文本的颜色为 '#6f210d'
              .fontColor('#6f210d');

            // 创建一个单选框组件，值为 '男'，所属单选框组为 'genderGroup'
            Radio({ value: '男', group: 'genderGroup' })
              // 根据 gender 状态变量的值设置单选框是否选中
              .checked(this.gender === '男')
                // 设置单选框的高度为 25
              .height(25)
                // 设置单选框的宽度为 25
              .width(25);
            // 创建一个文本组件，显示 '男'
            Text('男')
              // 设置文本的字体大小为 20
              .fontSize(20)
                // 设置文本的颜色为 '#6f210d'
              .fontColor('#6f210d');

            // 创建一个单选框组件，值为 '女'，所属单选框组为 'genderGroup'
            Radio({ value: '女', group: 'genderGroup' })
              // 根据 gender 状态变量的值设置单选框是否选中
              .checked(this.gender === '女')
                // 设置单选框的高度为 25
              .height(25)
                // 设置单选框的宽度为 25
              .width(25);
            // 创建一个文本组件，显示 '女'
            Text('女')
              // 设置文本的字体大小为 20
              .fontSize(20)
                // 设置文本的颜色为 '#6f210d'
              .fontColor('#6f210d');
          }

          // 创建一个水平布局容器，子元素间距为 15
          Row({ space: 15 }) {
            // 创建一个文本组件，显示 '校区：'
            Text('校区：')
              // 设置文本的字体大小为 20，字体粗细为 500
              .font({ size: 20, weight: 500 })
                // 设置文本的颜色为 '#6f210d'
              .fontColor('#6f210d');

            // 创建一个下拉选择框组件，选项为金山校区、旗山校区、安溪校区
            Select([
              { value: '金山校区' },
              { value: '旗山校区' },
              { value: '安溪校区' }
            ])
              // 根据 campus 状态变量的值设置选中的选项索引
              .selected(this.campus === '金山校区'? 0 : this.campus === '旗山校区'? 1 : 2)
                // 设置选择框文本的字体大小为 20，字体粗细为 500
              .font({ size: 20, weight: 500 })
                // 设置选择框文本的颜色为 '#6f210d'
              .fontColor('#6f210d')
                // 设置选中选项的字体大小为 20，字体粗细为 400
              .selectedOptionFont({ size: 20, weight: 400 })
                // 设置选项的字体大小为 20，字体粗细为 700
              .optionFont({ size: 20, weight: 700 });
          }

          // 创建一个按钮组件
          Button() {
            // 按钮内的文本组件，显示 '提交'
            Text('提交')
              // 设置文本的字体大小为 20
              .fontSize(20)
                // 设置文本的字体加粗
              .fontWeight(FontWeight.Bold)
                // 设置文本的颜色为 '#6f210d'
              .fontColor('#6f210d');
          }
          // 设置按钮的类型为胶囊形状
          .type(ButtonType.Capsule)
          // 设置按钮的上边距为 20
          .margin({ top: 20 })
          // 设置按钮的背景颜色为 '#ffc0cb'
          .backgroundColor('#ffc0cb')
          // 设置按钮的宽度为父容器的 25%
          .width('25%')
          // 设置按钮的高度为父容器的 8%
          .height('8%')
          // 当按钮被点击时，执行以下操作
          .onClick(() => {
            // 打印点击按钮成功的信息
            console.info('Succeeded in clicking the ‘Next’ button.');
            // 使用 router 进行页面跳转，跳转到 'pages/Second' 页面，并传递 name 和 studentId 参数
            router.pushUrl({
              url: 'pages/Second',
              params: {
                name: this.name,
                studentId: this.studentId
              }
            })
              // 跳转成功后，打印跳转成功的信息
              .then(() => {
                console.info('Succeeded in jumping to the second page.');
              })
                // 跳转失败时，打印失败信息，包含错误码和错误信息
              .catch((err: BusinessError) => {
                console.info(`Failed to jump to the second page.Code is ${err.code},message is ${err.message}`);
              });
          });

        }
        // 设置垂直布局容器的上边距为 30
        .margin({ top: 30 })
        // 设置垂直布局容器的宽度为父容器的 100%
        .width('100%');
      }
      // 设置堆叠布局容器的高度为父容器的 100%
      .height('100%');
    }
  }

  // 处理校区选择改变的方法
  handleCampusChange(newValue: string, oldValue: string) {
    // 更新 campus 状态变量的值为新选择的值
    this.campus = newValue;
  }
}

```

### 2、页面二

**Index.ets**

```typescript {.line-numbers}
// 从 '@kit.ArkUI' 模块导入 router 对象，用于页面跳转
import { router } from '@kit.ArkUI';
// 从 '@kit.BasicServicesKit' 模块导入 BusinessError 类，用于处理业务错误
import { BusinessError } from '@kit.BasicServicesKit';

// 定义一个接口 PageParams，用于表示从第一页传递过来的参数类型
interface PageParams {
  // 可选的姓名参数
  name?: string;
  // 可选的学号参数
  studentId?: string;
}

// 使用 @Entry 装饰器标记该组件为入口组件
// 使用 @Component 装饰器将该类标记为 ArkTS 组件
@Entry
@Component
struct Index {
  // 使用 @State 装饰器定义响应式状态变量 message，初始值为确认个人信息提示
  @State
  message: string = '请确认您的个人信息';
  // 使用 @State 装饰器定义响应式状态变量 name，从路由参数中获取，若没有则为空字符串
  @State
  name: string = (router.getParams() as PageParams)?.name || '';
  // 使用 @State 装饰器定义响应式状态变量 studentId，从路由参数中获取，若没有则为空字符串
  @State
  studentId: string = (router.getParams() as PageParams)?.studentId || '';
  // 使用 @State 装饰器定义响应式状态变量 selectedDate，初始值为 '2022-09-10'
  @State
  selectedDate: Date = new Date('2022-09-10');

  // 组件的构建方法，用于定义组件的 UI 结构
  build() {
    // 创建一个水平布局容器
    Row() {
      // 创建一个垂直布局容器，子元素间距为 20
      Column({ space: 20 }) {
        // 创建一个文本组件，显示 message 状态变量的值
        Text(this.message)
          // 设置文本的字体大小为 25
          .fontSize(25)
            // 设置文本的字体加粗
          .fontWeight(FontWeight.Bold)
            // 设置文本的颜色为 '#6f210d'
          .fontColor('#6f210d');

        // 创建一个文本组件，显示姓名信息
        Text(`姓名：${this.name}`)
          // 设置文本的字体大小为 25
          .fontSize(25)
            // 设置文本的字体正常粗细
          .fontWeight(FontWeight.Normal)
            // 设置文本的颜色为 '#6f210d'
          .fontColor('#6f210d');

        // 创建一个文本组件，显示学号信息
        Text(`学号：${this.studentId}`)
          // 设置文本的字体大小为 25
          .fontSize(25)
            // 设置文本的字体正常粗细
          .fontWeight(FontWeight.Normal)
            // 设置文本的颜色为 '#6f210d'
          .fontColor('#6f210d');

        // 创建一个文本组件，显示选择入学日期的提示
        Text(`请选择您的入学日期：`)
          // 设置文本的字体大小为 25
          .fontSize(25)
            // 设置文本的字体加粗
          .fontWeight(FontWeight.Bold)
            // 设置文本的颜色为 '#6f210d'
          .fontColor('#6f210d');

        // 创建一个日期选择器组件
        DatePicker({
          // 设置日期选择器的起始日期为 '1970-1-1'
          start:new Date('1970-1-1'),
          // 设置日期选择器的结束日期为 '2100-1-1'
          end:new Date('2100-1-1'),
          // 设置日期选择器的默认选中日期为 '2023-02-15'
          selected:new Date('2023-02-15'),
        })
          // 不显示农历
          .lunar(false)
            // 当选择日期时，触发该事件，打印选择的日期信息
          .onChange((value:DatePickerResult)=>{
            console.info('select current date is:'+JSON.stringify(value))
          })

        // 创建一个按钮组件
        Button() {
          // 按钮内的文本组件，显示 '返回'
          Text('返回')
            // 设置文本的字体大小为 20
            .fontSize(20)
              // 设置文本的字体加粗
            .fontWeight(FontWeight.Bold)
              // 设置文本的颜色为 '#6f210d'
            .fontColor('#6f210d');
        }
        // 设置按钮的类型为胶囊形状
        .type(ButtonType.Capsule)
        // 设置按钮的上边距为 20
        .margin({ top: 20 })
        // 设置按钮的背景颜色为 '#ffc0cb'
        .backgroundColor('#ffc0cb')
        // 设置按钮的宽度为父容器的 20%
        .width('25%')
        // 设置按钮的高度为父容器的 10%
        .height('8%')
        // 当按钮被点击时，执行以下操作
        .onClick(() => {
          // 打印点击按钮成功的信息
          console.info('Succeeded in clicking the ‘Back’ button.');
          try {
            // 使用 router 进行页面返回操作
            router.back();
            // 打印返回成功的信息
            console.info('Succeeded in returning to the first page.');
          } catch (err) {
            // 获取错误码
            const code = (err as BusinessError).code;
            // 获取错误信息
            const message = (err as BusinessError).message;
            // 打印返回失败的信息，包含错误码和错误信息
            console.error(`Failed to return to the first page.Code is ${code},message is ${message}`);
          }
        });

        // 创建一个文本时钟组件
        TextClock()
          // 设置文本时钟的外边距为 20
          .margin(20)
            // 设置文本时钟的字体大小为 30
          .fontSize(30)
            // 设置文本时钟的显示格式为 'yyyy/MM/dd    HH:mm:ss'
          .format('yyyy/MM/dd    HH:mm:ss');
      }
      // 设置垂直布局容器的宽度为父容器的 100%
      .width('100%');
    }
    // 设置水平布局容器的高度为父容器的 100%
    .height('100%');
  }
}
```
## 二、整体展示结果
### 1、页面一

<div align=center><img src="Index.png" alt="img"width="250"></div>

### 2、页面二

<div align=center><img src="Second.png" alt="img"width="250"></div>




## 三、所添加的组件：
### 1、组件一：Marquee
<font size=4> Marquee是跑马灯组件，用于滚动展示一段单行文本， 仅当文本内容宽度超过跑马灯组件宽度时滚动。</font>

**Index.ets中代码如下：**
```typescript {.line-numbers}
Marquee({
          // 跑马灯开始滚动
          start: true,
          // 滚动步长为 7
          step: 7,
          // 无限循环滚动
          loop: -1,
          // 从起始位置开始滚动
          fromStart: true,
          // 跑马灯显示的文本内容
          src: "FAFUers，欢迎来到福建农林大学！"
        })
          // 设置跑马灯文本的字体大小为 25
          .fontSize(25)
            // 设置跑马灯文本的颜色为 '#6f210d'
          .fontColor('#6f210d')
            // 设置跑马灯的宽度为父容器的 100%
          .width('100%');
```
**显示效果如下：**

<div align=center><img src="Marquee01.png" alt="img"width="300"></div>

<div align=center><img src="Marquee02.png" alt="img"width="300"></div>


### 2、组件二：Image
<font size=4> Image 是图片组件，支持本地图片和网络图片的渲染展示。</font>

**Index.ets中代码如下：**
```typescript {.line-numbers}
Image($r('app.media.FAFU'))
            // 设置图片的宽度为 100
            .width(100)
              // 设置图片的高度为 100
            .height(100);
```

**显示效果如下：**


<div align=center><img src="Image.png" alt="img"width="350"></div>

### 3、组件三：TextInput
<font size=4> TextInput 是单行文本输入框组件。</font>

**Index.ets中代码如下：**
```typescript {.line-numbers}
Row({ space: 10 }) {
            // 创建一个文本组件，显示 '姓名：'
            Text('姓名：')
              // 设置文本的字体大小为 20
              .fontSize(20)
                // 设置文本的颜色为 '#6f210d'
              .fontColor('#6f210d');
            // 创建一个文本输入框组件，占位符为 '请输入姓名……'
            TextInput({ placeholder: '请输入姓名……' })
              // 设置占位符文本的颜色为灰色
              .placeholderColor(Color.Grey)
                // 设置占位符文本的字体大小为 16，字体粗细为 400
              .placeholderFont({ size: 16, weight: 400 })
                // 设置输入框光标颜色为蓝色
              .caretColor(Color.Blue)
                // 设置输入框的宽度为 200
              .width(200)
                // 设置输入框的高度为 40
              .height(40)
                // 设置输入框的外边距为 20
              .margin(20)
                // 设置输入框文本的字体大小为 24
              .fontSize(24)
                // 设置输入框文本的颜色为黑色
              .fontColor(Color.Black)
                // 当输入框内容改变时，更新 name 状态变量的值
              .onChange((value: string) => {
                this.name = value;
              });
          }

          // 创建一个水平布局容器，子元素间距为 10
          Row({ space: 10 }) {
            // 创建一个文本组件，显示 '学号：'
            Text('学号：')
              // 设置文本的字体大小为 20
              .fontSize(20)
                // 设置文本的颜色为 '#6f210d'
              .fontColor('#6f210d');
            // 创建一个文本输入框组件，占位符为 '请输入学号……'
            TextInput({ placeholder: '请输入学号……' })
              // 设置占位符文本的颜色为灰色
              .placeholderColor(Color.Grey)
                // 设置占位符文本的字体大小为 16，字体粗细为 400
              .placeholderFont({ size: 16, weight: 400 })
                // 设置输入框光标颜色为蓝色
              .caretColor(Color.Blue)
                // 设置输入框的宽度为 200
              .width(200)
                // 设置输入框的高度为 40
              .height(40)
                // 设置输入框的外边距为 20
              .margin(20)
                // 设置输入框文本的字体大小为 24
              .fontSize(24)
                // 设置输入框文本的颜色为黑色
              .fontColor(Color.Black)
                // 当输入框内容改变时，更新 studentId 状态变量的值
              .onChange((value: string) => {
                this.studentId = value;
              });
          }

          // 创建一个水平布局容器，子元素间距为 10
          Row({ space: 10 }) {
            // 创建一个文本组件，显示 '密码：'
            Text('密码：')
              // 设置文本的字体大小为 20
              .fontSize(20)
                // 设置文本的颜色为 '#6f210d'
              .fontColor('#6f210d');
            // 创建一个文本输入框组件，占位符为 '请输入密码……'
            TextInput({ placeholder: '请输入密码……' })
              // 设置输入框的宽度为 200
              .width(200)
                // 设置输入框的高度为 40
              .height(40)
                // 设置输入框的外边距为 20
              .margin(20)
                // 设置输入框文本的字体大小为 24
              .fontSize(24)
                // 设置输入框类型为密码输入框
              .type(InputType.Password)
                // 设置输入框最大输入长度为 9
              .maxLength(9)
                // 显示密码可见切换图标
              .showPasswordIcon(true);
          }
```

**显示效果如下：**

<div align=center><img src="TextInput.png" alt="img"width="300"></div>

### 4、组件四：Radio
<font size=4> Radio 是单选框，提供相应的用户交互选择项。当前单选框 所属的群组名称，相同group 的 Radio 只能有一个被选中。</font>

**Index.ets中代码如下：**

```typescript {.line-numbers}
Row({ space: 10 }) {
            // 创建一个文本组件，显示 '性别：'
            Text('性别：')
              // 设置文本的字体大小为 20
              .fontSize(20)
                // 设置文本的颜色为 '#6f210d'
              .fontColor('#6f210d');

            // 创建一个单选框组件，值为 '男'，所属单选框组为 'genderGroup'
            Radio({ value: '男', group: 'genderGroup' })
              // 根据 gender 状态变量的值设置单选框是否选中
              .checked(this.gender === '男')
                // 设置单选框的高度为 25
              .height(25)
                // 设置单选框的宽度为 25
              .width(25);
            // 创建一个文本组件，显示 '男'
            Text('男')
              // 设置文本的字体大小为 20
              .fontSize(20)
                // 设置文本的颜色为 '#6f210d'
              .fontColor('#6f210d');

            // 创建一个单选框组件，值为 '女'，所属单选框组为 'genderGroup'
            Radio({ value: '女', group: 'genderGroup' })
              // 根据 gender 状态变量的值设置单选框是否选中
              .checked(this.gender === '女')
                // 设置单选框的高度为 25
              .height(25)
                // 设置单选框的宽度为 25
              .width(25);
            // 创建一个文本组件，显示 '女'
            Text('女')
              // 设置文本的字体大小为 20
              .fontSize(20)
                // 设置文本的颜色为 '#6f210d'
              .fontColor('#6f210d');
          }
```

**显示效果如下：**

<div align=center><img src="Radio.png" alt="img"width="300"></div>

### 5、组件五：Select
<font size=4>Select 提供下拉选择菜单，可以让用户在多个选项之间选择。</font>

**Index.ets中代码如下：**

```typescript {.line-numbers}
Row({ space: 15 }) {
            // 创建一个文本组件，显示 '校区：'
            Text('校区：')
              // 设置文本的字体大小为 20，字体粗细为 500
              .font({ size: 20, weight: 500 })
                // 设置文本的颜色为 '#6f210d'
              .fontColor('#6f210d');

            // 创建一个下拉选择框组件，选项为金山校区、旗山校区、安溪校区
            Select([
              { value: '金山校区' },
              { value: '旗山校区' },
              { value: '安溪校区' }
            ])
              // 根据 campus 状态变量的值设置选中的选项索引
              .selected(this.campus === '金山校区'? 0 : this.campus === '旗山校区'? 1 : 2)
                // 设置选择框文本的字体大小为 20，字体粗细为 500
              .font({ size: 20, weight: 500 })
                // 设置选择框文本的颜色为 '#6f210d'
              .fontColor('#6f210d')
                // 设置选中选项的字体大小为 20，字体粗细为 400
              .selectedOptionFont({ size: 20, weight: 400 })
                // 设置选项的字体大小为 20，字体粗细为 700
              .optionFont({ size: 20, weight: 700 });
          }
```

**显示效果如下：**

<div align=center><img src="Select.png" alt="img"width="300"></div>

### 6、组件六：DatePicker
<font size=4> DatePicker 是选择日期的滑动选择器组件。</font>

**Second.ets中代码如下：**

```typescript {.line-numbers}
Text(`请选择您的入学日期：`)
          // 设置文本的字体大小为 25
          .fontSize(25)
            // 设置文本的字体加粗
          .fontWeight(FontWeight.Bold)
            // 设置文本的颜色为 '#6f210d'
          .fontColor('#6f210d');

        // 创建一个日期选择器组件
        DatePicker({
          // 设置日期选择器的起始日期为 '1970-1-1'
          start:new Date('1970-1-1'),
          // 设置日期选择器的结束日期为 '2100-1-1'
          end:new Date('2100-1-1'),
          // 设置日期选择器的默认选中日期为 '2023-02-15'
          selected:new Date('2023-02-15'),
        })
          // 不显示农历
          .lunar(false)
            // 当选择日期时，触发该事件，打印选择的日期信息
          .onChange((value:DatePickerResult)=>{
            console.info('select current date is:'+JSON.stringify(value))
          })
```

**显示效果如下：**

<div align=center><img src="DataPicker.png" alt="img"width="300"></div>


### 7、组件七：TextClock
<font size=4> TextClock 组件通过文本将当前系统时间显示在设备上，支持 不同时区的时间显示，最高精确到秒级。</font>

**Second.ets中代码如下：**

```typescript {.line-numbers}
TextClock()
          // 设置文本时钟的外边距为 20
          .margin(20)
            // 设置文本时钟的字体大小为 30
          .fontSize(30)
            // 设置文本时钟的显示格式为 'yyyy/MM/dd    HH:mm:ss'
          .format('yyyy/MM/dd    HH:mm:ss');
```

**显示效果如下：**

<div align=center><img src="TextClock.png" alt="img"width="300"></div>

## 四、信息传递

### 1、主要代码

**Index.ets中代码如下：**

**1）装饰器定义相关状态变量**

```typescript {.line-numbers}
  // 使用 @State 装饰器定义响应式状态变量 message，初始值为欢迎信息和创建账号提示
  @State
  message: string = '欢迎来到福建农林大学！\n请为您创建一个账号。';
  // 使用 @State 装饰器定义响应式状态变量 name，初始值为空字符串
  @State
  name: string = '';
  // 使用 @State 装饰器定义响应式状态变量 studentId，初始值为空字符串
  @State
  studentId: string = '';
  // 使用 @State 装饰器定义响应式状态变量 gender，初始值为 '男'
  @State
  gender: string = '男';
  // 使用 @State 装饰器定义响应式状态变量 campus，初始值为 '金山校区'
  @State
  campus: string = '金山校区';
```

**2）更新“姓名”变量**

```javascript{.line-numbers}
   // 当输入框内容改变时，更新 name 状态变量的值
              .onChange((value: string) => {
                this.name = value;
              });
```

**3）更新“学号”变量**

```javascript{.line-numbers}
   .onChange((value: string) => {
                this.studentId = value;
              });
```

**Second.ets中代码如下：**

**1）定义PageParams接口**

```javascript{.line-numbers}
   // 定义一个接口 PageParams，用于表示从第一页传递过来的参数类型
interface PageParams {
  // 可选的姓名参数
  name?: string;
  // 可选的学号参数
  studentId?: string;
}
```

**2）装饰器定义状态变量**

```javascript{.line-numbers}
// 使用 @State 装饰器定义响应式状态变量 message，初始值为确认个人信息提示
  @State
  message: string = '请确认您的个人信息';
  // 使用 @State 装饰器定义响应式状态变量 name，从路由参数中获取，若没有则为空字符串
  @State
  name: string = (router.getParams() as PageParams)?.name || '';
  // 使用 @State 装饰器定义响应式状态变量 studentId，从路由参数中获取，若没有则为空字符串
  @State
  studentId: string = (router.getParams() as PageParams)?.studentId || '';
  // 使用 @State 装饰器定义响应式状态变量 selectedDate，初始值为 '2022-09-10'
  @State
  selectedDate: Date = new Date('2022-09-10');
```

**3）创建显示“姓名”、“学号”信息的文本组件**

```javascript{.line-numbers}
// 创建一个文本组件，显示姓名信息
        Text(`姓名：${this.name}`)
          // 设置文本的字体大小为 25
          .fontSize(25)
            // 设置文本的字体正常粗细
          .fontWeight(FontWeight.Normal)
            // 设置文本的颜色为 '#6f210d'
          .fontColor('#6f210d');

        // 创建一个文本组件，显示学号信息
        Text(`学号：${this.studentId}`)
          // 设置文本的字体大小为 25
          .fontSize(25)
            // 设置文本的字体正常粗细
          .fontWeight(FontWeight.Normal)
            // 设置文本的颜色为 '#6f210d'
          .fontColor('#6f210d');
```

### 2、显示效果

**1）在页面一中输入相关的信息**

<div align=center><img src="Message01.png" alt="img"width="250"></div>


**2）在页面二中即会显示相应的姓名及学号**

<div align=center><img src="Message02.png" alt="img"width="250"></div>

# 实验二

## 代码

### index.ets

```typescript{.line-numbers}
import { BusinessError } from '@kit.BasicServicesKit';// 从 '@kit.BasicServicesKit' 模块中导入 BusinessError 类，用于处理业务错误
import { promptAction, router } from '@kit.ArkUI';// 从 '@kit.ArkUI' 模块中导入 router 对象，用于页面路由跳转


@Entry// 使用 @Entry 装饰器，表明该组件是应用的入口组件
@Component// 使用 @Component 装饰器，将 Index 定义为一个组件
struct Index {// 使用 @State 装饰器定义一个响应式状态变量 message
  @State message: string = '新建智能任务';//定义了一个message的字符串变量，初始值为账号登陆，用于在界面上显示相应的文本
  @State user: string='';//定义一个user的字符串变量
  @State describe: string='';//定义一个describe的字符串变量
  @State priority: string='非常重要';//定义一个priority的字符串变量
  @State showError: boolean = false;//定义一个showError的布尔类型变量


  build() {//调用build方法来创建和布局界面元素
    Row(){//创建一个row组件，在水平方向上排列子组件
      Column() { //在垂直方向上排列子组件
        TextClock()//时间组件
          .margin(20)//外边距为20
          .fontSize(30)//字体大小设为30
          .format('yyyy/MM/dd hh:mm:ss')//日期格式化

        Divider()//设置水平分割
          .color(0x2788D9)//设置颜色
          .strokeWidth(5)//设置线条宽度
          .lineCap(LineCapStyle.Round)//设置线条类型

        Text(this.message)//创建一个test组件，内容是message的值
          .fontSize(50)//将文本大小设置为50
          .fontWeight(FontWeight.Bold) //将文本字体加粗
          .margin({//设置外边距
            top:20//顶上间隔20
          })


        //任务名称输入框
        TextInput({placeholder:'任务名称' })//设置无输入时的提示文本
          .placeholderColor(Color.Gray)//设置文本颜色
          .placeholderFont({size:14,weight:400})//设置文本样式
          .caretColor(Color.Blue)//设置输入框光标颜色
          .width(300)//设置宽度
          .height(40)//设置高度
          .margin(20)//设置外边距
          .fontSize(22)//设置字体大小
          .fontColor(Color.Black)//设置字体颜色
          .maxLength(20)//添加最大长度限制
          .border({//设置边框样式
            width: this.showError ? 2 : 1, // 动态边框，如果为true则宽度为2，否则为1
            color: this.showError ? Color.Red : Color.Gray//ture则为红色，否则为灰色
          })
          //输入框的值发生变化时触发回调函数
          .onChange((value:string)=>{
          this.user=value;//将输入框的值赋给this.user属性
          if (value.length >=20){//设置长度限制
            promptAction.showToast({ message: '最大输入20各字符'})//超过20个字符跳出提示
          }
          if (value){//如果输入框有值
            this.showError = false;//false表示没有错误
          }
        })

        // 错误提示文本
        if (this.showError) {//当this.showError的值为true时进行
          Text('任务名称不能为空')//提示信息
            .fontSize(14)//设置文字大小
            .fontColor(Color.Red)//设置文本颜色
            .margin({ left: 20 })//设置文本的左边距
            .align(Alignment.Start)//文本对其方式为左对齐
        }

        //任务描述输入
        TextInput({ placeholder: '输入任务描述'})//设置输入框以及输入框默认的显示内容
          .width('90%')//设置宽度
          .height(100)//设置高度
          .margin(10)//设置边框
          .fontSize(25)//设置字体大小
          .borderRadius(8)//设置圆角半径
          .padding(10)//设置内边距
          .onChange((value:string)=> {//进行回调
            this.describe = value;//将输入框的值赋给describe
          })

        //选择重要程度
        Row() {//横向排布
          Text('非常重要')//设置文本组件内容
            .fontSize(28)//设置字号
          Radio({ value: '高优先级', group: 'radioGroup' })//设置值和归属名
            .checked(true)//默认选中状态
            .radioStyle({//自定义单选按钮样式
              checkedBackgroundColor: Color.Red//选中时背景色为红色
            })
            .height(40)//设置按钮高度
            .width(40)//设置按钮宽度
            .onChange((isChecked: boolean) => {//监听单选按钮选中状态
              console.log('Radio1 status is ' + isChecked)//打印按钮的选中状态到控制台
              if (isChecked)this.priority = '高优先级'//被选中将优先级设置为高优先级
            })
        }
        Row() {//横向排布
          Text('一般重要')//设置文本组件内容
            .fontSize(28)//设置字号
          Radio({ value: '中优先级', group: 'radioGroup' })//设置值和归属名
            .checked(false)//默认未选中状态
            .radioStyle({//自定义单选按钮样式
              checkedBackgroundColor: Color.Orange//选中时为橙色
            })
            .height(40)//设置按钮高度
            .width(40)//设置按钮宽度
            .onChange((isChecked: boolean) => {//监听单选按钮选中状态
              console.log('Radio2 status is ' + isChecked)//打印按钮的选中状态到控制台
              if (isChecked)this.priority = '中优先级'//被选中将优先级设置为中优先级
            })
        }
        Row() {//横向排布
          Text('不重要')//设置文本组件内容
            .fontSize(28)//设置字号
          Radio({ value: '低优先级', group: 'radioGroup' })//设置值和归属名
            .checked(false)//默认未选中状态
            .radioStyle({//自定义单选按钮样式
              checkedBackgroundColor: Color.Green//选中时为绿色
            })
            .height(40)//设置按钮高度
            .width(40)//设置按钮宽度
            .onChange((isChecked: boolean) => {//监听单选按钮选中状态
              console.log('Radio3 status is ' + isChecked)//打印按钮的选中状态到控制台
              if (isChecked)this.priority = '低优先级'//被选中将优先级设置为低优先级
            })
        }


        Button() {//添加按钮，以响应用户点击
          Text('添加')//在按钮上显示Next
            .fontSize(30)//设置字号大小为30
            .fontWeight(FontWeight.Bold) //字体加粗
        }//button组件的右括号
        .type(ButtonType.Capsule) //按钮形状类型为胶囊型
        .margin({// 设置按钮的外边距
          top: 20//这里设置了顶部外边距为 20
        })//margin方法的右括号
        .backgroundColor('#0D9FFB') //设置颜色
        .width('40%') //宽度为40%
        .height('5%') //高度为5%
        .onClick(() => {//跳转按钮绑定onClick事件，点击时跳转到第二页
          console.info(`Succeeded in clicking the 'next' button.`)//向控制台输出这句话

          if (!this.user.trim()) {// 检查用户输入的任务名称是否为空或仅包含空格
            this.showError = true; // 显示错误状态
            AlertDialog.show({//显示一个对话框，提示用户未填写任务名称
              title: '输入错误',//对话框标题
              message: '请填写任务名称',//对话框消息内容
            });
            return;//中断后续逻辑
          }

          //跳转到第二页
          router.pushUrl({url:'pages/Second',//使用pushUrl方法跳转到含有目标页面url的对象
            params:{user:this.user,describe:this.describe,priority:this.priority }})//跳转成功时的回调函数，在控制台输出信息表示成功跳转到第二页
            .then(()=>{//处理后面的东西
            console.info(`Succeeded in jumping to the second page.`)//向控制台输出这句话
        }).catch((err: BusinessError) => { // 跳转失败时的回调函数，捕获错误信息
          console.error(`Failed to jump to the second page.Code is${err.code},message is ${err.message}`)//在控制台输出错误信息
        })//catch方法的右括号
      })//onClick方法的右括号
        Column({ space: 15 }) {//一个进度条组件
          Text('Loading Effect')
            .fontSize(9)//设置大小
            .fontColor(0xCCCCCC)//设置颜色
            .width('90%')//设置宽度
          Progress({ value: 0, total: 100, type: ProgressType.Ring })//类型设置为环状
            .width(100)//设置宽度
            .color(Color.Blue)//设置颜色
            .style({ strokeWidth: 20, status: ProgressStatus.LOADING })//设置类型
        }


      }//Column组件的右括号
      .width('100%')//设置column组件的宽度是总宽度的100%
    }//row组件的右括号
    .height('100%')//设置row组件的高度是总宽度的100%
  }//build方法的右括号
}//struct的右括号
```

### Second.ets
```typescript{.line-numbers}
import { BusinessError } from '@kit.BasicServicesKit';// 从 '@kit.BasicServicesKit' 模块中导入 BusinessError 类，用于处理业务错误
import { router } from '@kit.ArkUI';// 从 '@kit.ArkUI' 模块中导入 router 对象，用于页面路由跳转

class routerParams {//自定义一个名为routerParams的类
  user: string//定义一个user的字符串
  describe:string//定义一个describe的字符串
  priority:string//定义一个priority的字符串
  constructor(user:string, describe:string, priority:string) {//构造函数，用于初始化routerParams对象的属性
    this.user = user//将传入的user的参数值赋给对象user属性
    this.describe = describe//将传入的describe的参数值赋给对象describe属性
    this.priority = priority//将传入的priority的参数值赋给对象priority属性
  }
}

@Entry// 使用 @Entry 装饰器，表明该组件是应用的入口组件
@Component// 使用 @Component 装饰器，将 Index 定义为一个组件
struct Second {// 使用 @State 装饰器定义一个响应式状态变量 message
  @State message: string = '任务列表';//定义了一个message的字符串变量，设置初始值，用于在界面上显示相应的文本
  @State user: string = (router.getParams() as routerParams).user//定义一个user的字符串变量，含绘制显示指定为routerParams类型
  @State describe: string = (router.getParams() as routerParams).describe//定义一个describe的字符串变量，含绘制显示指定为routerParams类型
  @State priority: string = (router.getParams() as routerParams).priority//定义一个priority的字符串变量，含绘制显示指定为routerParams类型

  build() {//调用build方法来创建和布局界面元素
    Row(){//创建一个row组件，在水平方向上排列子组件
      Column(){//在垂直方向上排列子组件

      Text(this.message)//创建一个test组件，内容是message的值
        .fontSize(50)//将文本大小设置为50
        .fontWeight(FontWeight.Bold)//将字号加粗

        Column() {//设置横向排列
          // 三个参数显示内容
          Text(`${this.user}`)//显示this.user的值
            .fontSize(28)//设置字体大小
            .fontColor('#AAC1B1')//设置字体颜色
            .margin({ bottom: 15 })//设置下边距

          Text(`${this.describe}`)//显示this.describe的值
            .fontSize(28)//设置字体大小
            .fontColor('#AAC1B1')//设置字体颜色
            .margin({ bottom: 15 })//设置下边距

          Text(`${this.priority}`)//显示this.priority的值
            .fontSize(28)//设置字体大小
            .fontColor('#AAC1B1')//设置字体颜色
            .margin({ bottom: 15 })//设置下边距
        }
        .padding(20) // 内边距
        .backgroundColor(0xFFDDCA) // 背景
        .borderRadius(15) // 圆角
        .shadow({ radius: 8, color: 0x1A000000 }) // 添加阴影
        .width('90%') // 宽度比例
        .margin({ bottom: 20,top: 20 }) // 底部间距

        Button(){//添加按钮
          Text('Back')//在按钮上显示back
            .fontSize(30)//字号为30
            .fontWeight(FontWeight.Bold)//字号加粗
        }//button函数的右括号
        .type(ButtonType.Capsule)//按钮为胶囊型
        .margin({//margin函数设置外边距
          top:20//按钮外边距上边为20像素
        })//margin函数的右括号
        .backgroundColor('#0D9FFB')//设置颜色
        .width('40%')//宽度为40%
        .height('5%')//高度为5%
        .onClick(()=>{//返回按钮绑定onClick事件，点击按钮时返回第一页
          console.info(`Succeeded in clicking the 'back' button.`)//向控制台输出这句话
          try{//此函数完成页面跳转，用于返回第一页
            router.back()//调用router.back()函数，返回上一页
            console.info(`Succeeded in returning to the first page.`)//向控制台输出这句话
          }catch(err){//如果页面跳转异常则会进入catch块
            let code =(err as BusinessError).code;//将捕获到的错误对象err强制转化为BusinessError类型，然后获取错误代码
            let message=(err as BusinessError).message;//将捕获到的错误对象err强制转化为BusinessError类型，然后获取错误消息
            console.error(`Failed to return to the first page.Code is ${code},message is ${message}`)//向控制台发出信息，信息包含错误代码和错误信息，表示返回上一页失败
          }//catch块的右括号
        })//onClick组件的右括号
      }//column函数的右括号
      .width('100%')//宽度设为父容器的100%
    }//row组件的右括号
    .height('100%')//长度设为父容器的100%
  }//build方法的右括号
}//struct的右括号
```

## 演示
初始界面
![alt text](初始界面-2.png){width=50%}

如果未填写任务名称则会提示
![alt text](未填写-1.png){width=50%}

可以选择任务的重要等级
![alt text](一般重要-1.png){width=50%}![alt text](不重要-1.png){width=50%}

点击添加跳转到页面二
![alt text](页面二-1.png){width=50%}

点击Back返回页面一
![alt text](返回页面一-1.png){width=50%}
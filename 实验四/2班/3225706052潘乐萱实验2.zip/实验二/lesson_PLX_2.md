# 实验二 实现页面传参
## 1详细代码
### 1.1 Index.ets
显示第一个页面，用户可点击搜索最新的专辑信息(点击Search跳转到Info页面)，或输入文本添加专辑信息(点击Add跳转到Second页面)
```typescript {.line-numbers}
import { EditableLeftIconType, Font, router} from '@kit.ArkUI';// 导入ArkUI框架中的路由模块，用于页面间的跳转
import {BusinessError} from '@kit.BasicServicesKit';// 导入业务错误处理类，用于捕获和处理业务逻辑中的错误

class routerParams {// 定义路由参数类
  singer: string;         // 歌手名称参数，字符串类型
  name: string;           // 专辑名称参数，字符串类型
  date: Date = new Date(); // 日期参数，日期类型，默认当前日期
  style: string = 'default-style'; // 风格参数，字符串类型，默认样式
  isMini: boolean = true; // 是否迷你专辑标识，布尔类型，默认为true

  constructor(singer: string ,name:string,date:Date,style:string,isMini:boolean) {// 构造函数，初始化所有参数
    this.singer = singer// 初始化singer参数为空
    this.name = name// 初始化name参数为空
    this.date =date// 初始化date参数为当前日期
    this.style =style// 初始化style参数为空
    this.isMini=isMini// 初始化isMini参数为true(真)
  }// 此处补全第11行花括弧
}// 此处补全第4行花括弧

@Entry// 使用@Entry注解，标识这个组件是应用的入口页面
@Component// 使用@Component注解定义一个组件结构
struct Index {// 组件结构名为Index
  @State message: string = 'The Album List';// 声明状态变量message，类型为string，内容表示页面主标题
  @State text: string = "专辑风格";// 声明状态变量text，表示下拉选择框的显示文本
  @State index: number = 2;// 声明状态变量index，表示选择框选中索引顺序为2
  @State space: number = 8;// 声明状态变量space，表示选择框选项间距为8
  @State arrowPosition: ArrowPosition = ArrowPosition.END;// 声明状态变量，表示选择框箭头位置
  // 以下为传值类绑定状态变量
  @State singer:string='';// 定义状态变量:歌手名，默认为空
  @State name:string='';// 定义状态变量:专辑名，默认为空
  @State date:Date=new Date();// 定义状态变量:发行日期，默认为当前日期
  @State style:string='';// 定义状态变量:专辑风格，默认为空
  @State isMini:boolean=true;// 定义状态变量:是否为迷你专辑，默认为真

  async routePage() {// 构造页面跳转方法
    let options: router.RouterOptions = { // 创建路由选项对象
      url: 'pages/Second',// 设置跳转目标页面路径
      params: new routerParams(//创建路由参数对象
        this.singer.valueOf(),     // 获取歌手输入值
        this.name.valueOf(),       // 获取专辑输入值
        this.date,                 // 获取日期选择值
        this.style.valueOf(),      // 获取风格选择值
        this.isMini.valueOf()      // 获取复选框状态值
      )// 此处补全第38行括弧
    }// 此处补全第36行大括弧
    try {// try方法执行页面跳转
      await router.pushUrl(options)//等待页面跳转
    } catch (err) {//catch方法获取错误
      console.info(` fail callback, code: ${(err as BusinessError).code}, msg: ${(err as BusinessError).message}`)// 错误处理：打印业务错误代码和消息
    }// 此处补全第48行花括弧
  }// 此处补全第35行花括弧

  build() {// build方法是组件的构建函数，用于定义组件的UI结构
    Row() {// 使用Row布局容器，用于水平排列子组件
      Column() {// 使用Column布局容器，用于垂直排列子组件，这里得到一个一行一列的组件
        Text(this.message)// 使用Text组件显示message状态变量的值
          .fontSize(25)// 设置显示字体大小为25
          .fontWeight(FontWeight.Bold)// 设置字体加粗
          .textAlign(TextAlign.Center)// 设置文本居中对齐
          .margin({ top: -10})// 设置上边距-10

        Search({ placeholder: 'The newest album'})// 添加Search组件,显示占位符文本'The newest album'
          .searchButton('Search')// 设置搜索按钮文本
          .width(350)                // 宽度350px
          .height(50)                // 高度50px
          .placeholderColor(Color.Red) // 占位符颜色为红色
          .placeholderFont({ size: 20, weight: 300 }) // 占位符字体样式
          .margin({ top: 40 })       // 设置上边距40
          .onClick(() => {// 跳转按钮绑定onClick事件，点击时跳转到info页面
            console.info("Succeeded in clicking the 'Next' button.")// 在控制台打印点击按钮的成功信息
            router.pushUrl({ url:'pages/Info',// 使用router.pushUrl方法尝试跳转到pages/info的页面
              params: new routerParams('Ten' ,'STUNNER',new Date('2025-3-24'),'dance-pop',(true))}).then(()=>{// 创建路由参数对象，输入需要传递到info页面的参数信息
              console.info('Succeeded in jumping to the second page.')// 跳转成功时，在控制台打印跳转成功的信息
            }).catch((err: BusinessError) => {// 跳转失败时，捕获BusinessError错误
              console.error(`Failed to jump to the second page.Code is ${err.code}, message is ${err.message}`)// 跳转失败时，在控制台打印错误代码和消息
            })// 补全第75行第二个大括号、第二个小括号
          })// 补全第70行大括号和第一个小括号

        TextInput({ placeholder: 'Please enter singer name...' })// 添加TextInput组件，显示提示文本'请输入歌手名'
          .onChange((value: string) => {// 输入变化监听
            this.singer=value// 更新绑定值singer
            console.info(value);// 控制台显示value值
          }).margin({top: 30 })// 设置上边距30

        TextInput({ placeholder: 'Please enter album name...' })// 添加TextInput组件，显示提示文本'请输入专辑名'
          .onChange((value: string) => {// 输入变化监听
            this.name=value// 更新绑定值name
            console.info(value);// 控制台显示value值
          })// 补全第87行括弧
          .margin({ top: 20 })// 设置上边距为20

        DatePicker({//添加DatePicker组件
          start: new Date('1970-1-1'),  // 起始日期
          end: new Date('2030-1-1'),    // 结束日期
          selected: new Date('2025-3-24') // 默认选中日期
        })// 此处补全第93行括弧
          .disappearTextStyle({color: Color.Brown, font: {size: '14fp', weight: FontWeight.Bold}})// 设置非选中日期样式
          .textStyle({color: '#ff3e1010', font: {size: '15fp', weight: FontWeight.Normal}})// 设置日期文本样式
          .selectedTextStyle({color: '#ff8800ff', font: {size: '20fp', weight: FontWeight.Regular, family: "HarmonyOS Sans", style: FontStyle.Normal}})// 设置选中日期样式
          .lunar(false)// 不使用农历日历
          .margin({// 设置组件边距
            top: 40// 设置上边距为40
          })// 补全第102行括号
          .onDateChange((value: Date) => {// 添加日期选择回调，将值保存在value中
            this.date = value// 更新绑定值date
            console.info('select current date is: ' + value.toString())// 控制台显示当前选择的日期信息
          })// 此处补全第105行括弧

        Select(//添加Select组件
          [{ value: 'dance-pop' }, { value: 'lyric' }, { value: 'r&b' }, { value: 'rap' }])// 设置选项值
          .selected(this.index)// 初始选中索引
          .value(this.text)// 显示选中的文本
          .font({ size: 20, weight: 500 })// 设置字体样式
          .selectedOptionFont({ size: 20, weight: 400 })// 设置选中的选项字体样式
          .optionFont({ size: 20, weight: 400 })// 设置选项字体样式
          .space(this.space)// 设置选项间距为定义的2
          .arrowPosition(this.arrowPosition)// 设置箭头位置
          .menuAlign(MenuAlignType.START, { dx: 0, dy: 0 })// 设置选项对齐
          .optionWidth(400)// 设置选项宽度400
          .optionHeight(250)// 设置选项高度250
          .margin({ top: 40 })// 设置上边距为40
          .onSelect((index: number, text?: string | undefined) => {// 选择回调选择的选项文本
            console.info('Select:' + index)// 控制台输出选择的选项信息
            this.index = index;// 将选中项的索引值保存到组件实例的index属性
            if (text) {this.text = text;}// 如果存在选中项的文本内容，将文本内容保存到组件实例的text属性
            this.index = index;// 再次将索引值赋给index属性
            this.style = text || '';// 使用逻辑或运算符 || 确保style始终为字符串类型
          })// 此处补全第123行括弧

        RowSplit(){// 添加水平分割布局
          Checkbox({ name: 'Mini Album', group: 'checkboxGroup' })// 添加复选框组件
            .select(true)// 默认勾选复选框
            .selectedColor(0xed6f21)// 设置选中颜色
            .shape(CheckBoxShape.ROUNDED_SQUARE)// 设置复选框形状
            .margin({top: 20 })// 设置按钮上边距为20
            .onChange((value: boolean) => {// 添加状态变化回调，将值保存为value
              this.isMini = value;// 更新绑定值isMini
              console.info('Checkbox1 change is' + value)// 控制台输出复选框变化信息
            })// 此处补全第137行括弧
          Text('Mini Album')// 在复选框旁添加文本用于解释
            .margin({ top: 20 })// 设置上边距为20
        }// 此处补全第131行括弧
        .margin({top:10})// 设置布局上边距为10

        Button() {// 使用Button组件创建一个按钮，响应用户点击
          Text('Add')// 使用Text组件在按钮中显示文本‘添加’
            .fontSize(25)// 设置文本字体大小为25
            .fontWeight(FontWeight.Bold)// 设置字体加粗
        }// 补全第146行Button方法括号
        .type(ButtonType.Capsule)// 设置按钮的类型为胶囊型
        .margin({ top: 20,bottom:20 })// 设置上边距为20，下边距为20
        .backgroundColor('#ff8800ff')// 设置按钮背景色为紫色，颜色代码为'FF8800FF'
        .width('40%')// 设置按钮的宽度为父容器宽度的40%
        .height('5%')// 设置按钮的高度为父容器高度的5%

        .onClick(() => {// 跳转按钮绑定onClick事件，点击时跳转到Second页面
          this.routePage()// 执行先前写好的跳转方法
          console.info("Succeeded in clicking the 'Next' button.")// 在控制台打印点击按钮的成功信息
        })// 此处补全第157行括弧
      }// 此处补全第55行括弧
      .width('100%')// 设置Column容器的宽度为父容器宽度的100%
    }// 此处补全第54行括弧
    .height('100%')// 设置Row容器的高度为父容器高度的100%
  }// 此处补全第53行括弧
}// 此处补全第22行括弧
```
### 1.2 Second.ets
显示第二个页面，展示添加的专辑信息，接收Index页面输入框等组件传递来的参数，点击Back返回Index页面
```typescript {.line-numbers}
import {router} from '@kit.ArkUI';// 导入ArkUI框架中的路由模块，用于页面间的跳转功能
import {BusinessError} from  '@kit.BasicServicesKit';// 导入业务错误处理类，用于捕获和处理可能发生的业务逻辑错误

class routerParams {// 定义路由参数类
  singer: string;         // 歌手名称参数，字符串类型
  name: string;           // 专辑名称参数，字符串类型
  date: Date = new Date(); // 日期参数，日期类型，默认当前日期
  style: string = 'default-style'; // 风格参数，字符串类型，默认样式
  isMini: boolean = true; // 是否迷你专辑标识，布尔类型，默认为true

  constructor(singer: string ,name:string,date:Date,style:string,isMini:boolean) {// 构造函数，初始化所有参数
    this.singer = singer// 初始化singer参数为空
    this.name = name// 初始化name参数为空
    this.date =date// 初始化date参数为当前日期
    this.style =style// 初始化style参数为空
    this.isMini=isMini// 初始化isMini参数为true(真)
  }// 此处补全第11行花括弧
}// 此处补全第4行花括弧

@Entry// 使用@Entry注解，标识这个组件是应用的入口页面
@Component// 使用@Component注解定义一个组件结构
struct Second { // 组件结构名为Second
  private content: string = "Album Information"// 声明私有变量content，用于展示页面标题
  @State singer: string = (router.getParams() as routerParams).singer// 从路由参数中获取歌手名称（类型断言为routerParams）
  @State name: string = (router.getParams() as routerParams).name// 从路由参数中获取专辑名称
  @State date: Date = ((router.getParams()) as routerParams).date// 从路由参数中获取发布日期
  @State style: string = (router.getParams() as routerParams).style// 从路由参数中获取专辑风格
  @State isMini: boolean = (router.getParams() as routerParams).isMini// 从路由参数中获取迷你专辑标识

  build() { // build方法是组件的构建函数，用于定义组件的UI结构
    Row() { // 使用Row布局容器，用于水平排列子组件
      Column() {// 使用Column布局容器，用于垂直排列子组件
        Flex({ direction: FlexDirection.Column }) {// 使用Flex布局容器，设置为列方向
          Text(`${this.content}`)// 添加Text组件，设置文本内容为变量content的值
            .fontSize(30)// 设置字体大小30
            .fontWeight(FontWeight.Bold)// 设置字体加粗
            .margin({ left: 40 })// 设置左边距40
            .textAlign(TextAlign.Center)// 设置居中对齐

          Text(`Singer: ${this.singer}`)// 添加Text组件，显示传参得到的歌手信息文本
            .fontSize(20)// 设置字体大小20
            .margin({ top: 50, left: 45 })// 设置上边距50，左边距45
            .textAlign(TextAlign.Start)// 设置左对齐

          Text(`Album: ${this.name}`)// 添加Text组件，显示传参得到的专辑信息文本
            .fontSize(20)// 设置字体大小20
            .margin({ top: 10, left: 45 })// 设置上边距50，左边距45
            .textAlign(TextAlign.Start)// 设置左对齐

          Text(`Release Date: ${this.date}`)// 添加Text组件，显示传参得到的发行日期信息文本
            .fontSize(20)// 设置字体大小20
            .margin({ top: 10, left: 45 })// 设置上边距50，左边距45
            .textAlign(TextAlign.Start)// 设置左对齐

          Text(`Style: ${this.style}`)// 添加Text组件，显示传参得到的风格信息文本
            .fontSize(20)// 设置字体大小20
            .margin({ top: 10, left: 45 })// 设置上边距50，左边距45
            .textAlign(TextAlign.Start)// 设置左对齐

          Text(`is Mini Album: ${this.isMini}`)// 添加Text组件，显示传参得到的是否为迷你专辑信息文本
            .fontSize(20)// 设置字体大小20
            .margin({ top: 10, left: 45 })// 设置上边距50，左边距45
            .textAlign(TextAlign.Start) // 设置左对齐

          Text('more information:').fontSize(13).fontColor(0xCCCCCC).width('100%')// 添加Text组件，显示更多信息提示文本
            .margin({left: 50,top: 70})// 设置左边距50，上边距70
          Progress({ value: 0, total: 100, type: ProgressType.Ring })// 添加Progress组件，显示环形进度条
            .width(170)// 设置宽度170
            .color(Color.Blue)// 设置颜色为蓝色
            .style({ strokeWidth: 20, status: ProgressStatus.LOADING })// 设置组件风格
            .margin({left: 90,top: 30})// 设置上边距30，左边距90

          Button() { // 使用Button组件创建一个按钮，响应用户点击
            Text('Back')// 使用Text组件在按钮中显示文本‘Back’
              .fontSize(30)// 设置文本字体大小为30
              .fontWeight(FontWeight.Bold) // 设置字体加粗
          } // 补全第16行Button方法大括号
          .type(ButtonType.Capsule) // 设置按钮的类型为胶囊型
          .margin({ top: 90,left:100 }) // 设置上边距90，左边距100
          .backgroundColor('#ffa80dfb') // 修改按钮背景色为紫色，颜色代码为'#ffa8fb0d'
          .width('40%') // 设置按钮的宽度为父容器宽度的40%
          .height('5%') // 设置按钮的高度为父容器高度的5%

          .onClick(() => { // 跳转按钮绑定onClick事件，点击时跳转回Index页面
            console.info("Succeeded in clicking the 'Back' button. ") // 在控制台打印点击按钮的成功信息
            try { // 尝试执行页面返回操作，返回到上一页
              router.back() // 此函数为ArkUI提供的用于页面跳转的API之一
              console.info(`Succeeded in returning to the first page.Name is ${this.name}`) // 如果页面返回成功，在控制台打印返回成功的信息
            } catch (err) { // 如果页面返回失败，捕获可能抛出的异常
              let code = (err as BusinessError).code; // 将异常对象转换为BusinessError类型，获取错误代码
              let message = (err as BusinessError).message; // 将异常对象转换为BusinessError类型，获取错误消息
              console.error(`Failed to return to the first page.Code is ${code},message is ${message}`) // 在控制台打印返回失败的错误信息，包括错误代码和消息
            } // 补全第89行catch(err)方法的大括号
          }) // 补全第84行onClick事件的括号
        } // 补全第33行大括号
        .width('100%') // 设置Column容器的宽度为父容器宽度的100%
      } // 补全第32行大括号
      .height('100%') // 设置Row容器的高度为父容器高度的100%
    } // 补全第31行大括号
  }
}
```
### 1.3 Info.ets
显示第三个页面，展示最新的专辑信息，接收点击Search后Index页面传递来的参数，点击Back返回Index页面
```typescript {.line-numbers}
import {router} from '@kit.ArkUI';// 导入ArkUI框架中的路由模块，用于页面间的跳转功能
import {BusinessError} from  '@kit.BasicServicesKit';// 导入业务错误处理类，用于捕获和处理可能发生的业务逻辑错误

class routerParams {// 定义路由参数类
  singer: string;         // 歌手名称参数，字符串类型
  name: string;           // 专辑名称参数，字符串类型
  date: Date = new Date(); // 日期参数，日期类型，默认当前日期
  style: string = 'default-style'; // 风格参数，字符串类型，默认样式
  isMini: boolean = true; // 是否迷你专辑标识，布尔类型，默认为true

  constructor(singer: string ,name:string,date:Date,style:string,isMini:boolean) {// 构造函数，初始化所有参数
    this.singer = singer// 初始化singer参数为空
    this.name = name// 初始化name参数为空
    this.date =date// 初始化date参数为当前日期
    this.style =style// 初始化style参数为空
    this.isMini=isMini// 初始化isMini参数为true(真)
  }// 此处补全第11行花括弧
}// 此处补全第4行花括弧

@Entry// 使用@Entry注解，标识这个组件是应用的入口页面
@Component// 使用@Component注解定义一个组件结构
struct Empty {// 组件结构名为Empty
  private content: string = "The newest album"// 声明私有变量content，用于展示页面标题
  @State singer: string = (router.getParams() as routerParams).singer// 从路由参数中获取歌手名称（类型断言为routerParams）
  @State name: string = (router.getParams() as routerParams).name// 从路由参数中获取专辑名称
  @State date: Date = ((router.getParams()) as routerParams).date// 从路由参数中获取发布日期
  @State style: string = (router.getParams() as routerParams).style// 从路由参数中获取专辑风格
  @State isMini: boolean = (router.getParams() as routerParams).isMini// 从路由参数中获取迷你专辑标识
  private info:string= "TEN将携迷你2辑《STUNNER》于3月24日回归，其中收录曲《BAMBOLA》MV于17日晚8点（北京时间）先行公开。此次MV以拍摄现场幕后为概念，通过生动有趣的氛围展现出TEN顽皮、独特的表演，敬请期待。"
  // 声明私有变量info，用于展示二维码信息

  build() {// build方法是组件的构建函数，用于定义组件的UI结构
    Flex({ direction: FlexDirection.Column }) {// 使用Flex布局容器，设置为列方向
      Text(`${this.content}`)// 添加Text组件，设置文本内容为变量content的值
        .fontSize(30)// 设置字体大小30
        .fontWeight(FontWeight.Bold)// 设置字体加粗
        .margin({left: 45})// 设置左边距为45
        .textAlign(TextAlign.Center)//设置居中对齐

      Text(`Singer: ${this.singer}`)// 添加Text组件，显示传参得到的歌手信息文本
        .fontSize(20)// 设置字体大小20
        .margin({ top: 50, left: 45 })// 设置上边距50，左边距45
        .textAlign(TextAlign.Start)// 设置左对齐

      Text(`Album: ${this.name}`)// 添加Text组件，显示传参得到的专辑信息文本
        .fontSize(20)// 设置字体大小20
        .margin({ top: 10, left: 45 })// 设置上边距50，左边距45
        .textAlign(TextAlign.Start)// 设置左对齐

      Text(`Release Date: ${this.date}`)// 添加Text组件，显示传参得到的发行日期信息文本
        .fontSize(20)// 设置字体大小20
        .margin({ top: 10, left: 45 })// 设置上边距50，左边距45
        .textAlign(TextAlign.Start)// 设置左对齐

      Text(`Style: ${this.style}`)// 添加Text组件，显示传参得到的风格信息文本
        .fontSize(20)// 设置字体大小20
        .margin({ top: 10, left: 45 })// 设置上边距50，左边距45
        .textAlign(TextAlign.Start)// 设置左对齐

      Text(`is Mini Album: ${this.isMini}`)// 添加Text组件，显示传参得到的是否为迷你专辑信息文本
        .fontSize(20)// 设置字体大小20
        .margin({ top: 10, left: 45 })// 设置上边距50，左边距45
        .textAlign(TextAlign.Start) // 设置左对齐

      RowSplit() {// 添加水平分割布局
        Image($r('app.media.STUNNER'))// 添加图像组件
          .width(150).height(150).margin({ left: 25, top: 40 })// 设置图像大小、左边距为25，上边距为40

        QRCode(this.info).color('#ff8800ff').width(150).height(150)// 添加二维码组件，设置颜色、大小
          .margin({ left:10,top: 40 })// 设置左边距为10，上边距为40
      }.resizeable(true)// 设置分割线可以移动
      Text('Ten 2st Mini Album')// 添加文本组件，用以说明图像和二维码
        .margin({ left:100,top: 20 })// 设置左边距为100，上边距为20

      Button() { // 使用Button组件创建一个按钮，响应用户点击
        Text('Back')// 使用Text组件在按钮中显示文本‘Back’
          .fontSize(30)// 设置文本字体大小为30
          .fontWeight(FontWeight.Bold) // 设置字体加粗
      } // 补全第75行Button方法大括号
      .type(ButtonType.Capsule) // 设置按钮的类型为胶囊型
      .margin({ top: 150,left:100 })// 设置上边距为150，左边距为100
      .backgroundColor('#ffa80dfb') // 修改按钮背景色为紫色，颜色代码为'#ffa8fb0d'
      .width('40%') // 设置按钮的宽度为父容器宽度的40%
      .height('5%') // 设置按钮的高度为父容器高度的5%

      .onClick(() => { // 跳转按钮绑定onClick事件，点击时跳转回Index页面
        console.info("Succeeded in clicking the 'Back' button. ") // 在控制台打印点击按钮的成功信息
        try { // 尝试执行页面返回操作，返回到上一页
          router.back() // 此函数为ArkUI提供的用于页面跳转的API之一
          console.info(`Succeeded in returning to the first page.Name is ${this.name}`) // 如果页面返回成功，在控制台打印返回成功的信息
        } catch (err) { // 如果页面返回失败，捕获可能抛出的异常
          let code = (err as BusinessError).code; // 将异常对象转换为BusinessError类型，获取错误代码
          let message = (err as BusinessError).message; // 将异常对象转换为BusinessError类型，获取错误消息
          console.error(`Failed to return to the first page.Code is ${code},message is ${message}`) // 在控制台打印返回失败的错误信息，包括错误代码和消息
        } // 补全第91行catch(err)方法的大括号
      }) // 补全第86行onClick事件的括号
    }// 补全第33行括弧
    .width('100%')// 设置Column容器的宽度为父容器宽度的100%
    .height('100%')// 设置Row容器的高度为父容器高度的100%
  }// 补全第32行括弧
}// 补全第22行括弧
```
## 2演示效果展示
### 2.1事先定义参数实现跳转传参
进入Index页面，点击搜索框旁Search按钮，携带参数跳转到包含最新专辑信息的Info页面，Info页面接收并显示信息:
![](第一个页面(Index)-1.png)    ![](点击Search跳转到Info页面-1.png)
### 2.2绑定事件获取信息实现跳转传参
进入Index页面，在文本框中输入专辑信息，在下拉选择框选择选项，选择日期，勾选复选框，点击下方Add按钮，通过绑定onChange、onSelect事件获取变化值，携带参数跳转到Second页面，Second页面接收并显示信息:
![alt text](第一个页面输入信息-1.png)   ![alt text](<点击Add跳转到第二个页面（Second)-1.png>)


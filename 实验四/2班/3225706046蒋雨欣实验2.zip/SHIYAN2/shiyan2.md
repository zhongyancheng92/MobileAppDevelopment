# 实验二
## 1. 页面一 index 

```javascript{.line-numbers}

import { router } from '@kit.ArkUI';
// 导入 ArkUI 模块中的 router 对象，用于页面路由和导航。
import { BusinessError } from '@kit.BasicServicesKit';
// 导入 BasicServicesKit 模块中的 BusinessError 类型，用于处理业务错误。

@Entry
  // 使用 @Entry 装饰器，表示当前组件是应用的入口页面。
@Component
  // 使用 @Component 装饰器，表示当前是一个自定义组件。

struct Index {
  // 定义名为 Index 的结构体（组件）。
  @State message: string = 'Long Live!!';
  // 使用 @State 装饰器定义一个响应式状态变量 message，初始值为 'Long Live!!'。
  @State inputValue: string = 'NOTHING';
  // 使用 @State 装饰器定义一个响应式状态变量 message，初始值为 'NOTHING'。

  @State isLoading: boolean = true;
  // 加载状态
  build() {
    // 定义 build 方法，用于描述组件的 UI 结构。
    Row() {
      // 创建一个行布局容器。
      Column() {
        // 创建一个列布局容器。
        Text(this.message)
          // 创建一个文本组件，显示 this.message 的内容。
          .fontSize(50)
            // 设置文本字体大小为 50。
          .margin({ bottom: 60 })
          .fontWeight(FontWeight.Bold);
            // 设置文本字体粗细为粗体。
        TextInput({ placeholder: 'Enter your message' })//创建一个文本组件，显示this.inputValue输入框的内容。
          .width('90%') // 设置宽度为父容器的 90%
          .height(80)    // 设置高度为 80
          .fontSize(50)  // 设置字体大小为 50
          .padding(10)   // 设置内边距为 10
          .margin({ bottom: 60 })
          .onChange((value: string) => {
            this.inputValue = value; // 更新输入框内容
          });
        Image($r('app.media.longlive'))//创建一个图像组件，使用资源管理器 $r 加载图片资源 'app.media.longlive'
          .width(180).height(180)//设置宽度和高度
          .objectFit(ImageFit.Cover)//设置图像的填充方式为 "Cover"，即按比例缩放并裁剪以覆盖整个容器

        if (this.isLoading) { // 如果正在加载
          LoadingProgress()// 动效组件
            .color(Color.Blue)// 设置动效颜色
            .width(50)// 设置动效宽度
            .height(50) // 设置动效高度
        }
        // 添加按钮，以响应用户点击。
        Button() {
          // 创建一个按钮组件。
          Text("Next")
            // 在按钮内部创建一个文本组件，显示 "Next"。
            .fontSize(30)
              // 设置按钮文本字体大小为 30。
            .fontColor('#D9CEE4')
            .fontWeight(FontWeight.Bold);
          // 设置按钮文本字体粗细为粗体。
        }
        // 结束 Button 组件的定义。
        .type(ButtonType.Capsule)
        // 设置按钮类型为胶囊形状。
        .margin({
          // 设置按钮的外边距。
          top: 20
          // 设置按钮顶部外边距为 20。
        })
        // 结束 margin 方法的调用。
        .backgroundColor('#BBA1CB')
        // 设置按钮背景颜色为 '#7851A9'。
        .width('40%')
        // 设置按钮宽度为父容器宽度的 40%。
        .height('10%')
        // 设置按钮高度为父容器高度的 10%。
        // 跳转按钮绑定到 onclick 事件，点击时跳转到第二页。
        .onClick(() => {
          // 为按钮绑定点击事件。
          console.info('Succeeded in clicking the ‘Next’ button');
          // 在控制台打印日志，表示按钮点击成功。
          // 跳转到第二页。
          router.pushUrl({ url: 'pages/Page1',params: { inputValue: this.inputValue } })
            // 调用 router.pushUrl 方法，跳转到 'pages/Page1' 页面,传递输入框内容。
            .then(() => {
              // 跳转成功后的回调函数。
              console.info('Succeeded in jumping to the second page.');
              // 在控制台打印日志，表示跳转成功。
            })
              // 结束 then 方法的回调函数。
            .catch((err: BusinessError) => {
              // 跳转失败后的回调函数。
              console.error('failed to jump to the second page. code is ${err.code}, message is ${err.message}');
              // 在控制台打印错误日志，包含错误代码和错误信息。
            });
          // 结束 catch 方法的回调函数。
        });
        // 结束 onClick 事件处理函数。
      }
      // 结束 Column 组件。
      .width('100%')
      // 设置列布局容器的宽度为父容器的 100%。
    }
    // 结束 Row 组件。
    .height('100%')
    // 设置行布局容器的高度为父容器的 100%。
  }
  // 结束 build 方法。
}
// 结束 Index 组件的定义。
```

## 2. 页面二 second

```javascript{.line-numbers}

import { router } from '@kit.ArkUI';
// 导入 ArkUI 模块中的 router 对象，用于页面路由和导航。
interface GeneratedTypeLiteralInterface_1 {
  inputValue: string;
}

@Entry
  // 使用 @Entry 装饰器，表示当前组件是应用的入口页面。
@Component
  // 使用 @Component 装饰器，表示当前是一个自定义组件。

struct Page1 {
  // 定义名为 Page1 的结构体（组件）。
  @State message: string = 'hi babe';
  // 使用 @State 装饰器定义一个响应式状态变量 message，初始值为 'hi babe'。
  @State inputValue: string = 'NOTHING';
  // 使用 @State 装饰器定义一个响应式状态变量 inputValue，初始值为 'NOTHING'。
  @State animationStatus: AnimationStatus = AnimationStatus.Paused;
  // 使用 @State 装饰器定义一个响应式状态变量 animationStatus，初始值为 'AnimationStatus.Paused'

  aboutToAppear() {
    // 在页面显示时获取路由参数
    const params = router.getParams() as GeneratedTypeLiteralInterface_1;
    // 获取传递的参数
    if (params) {
      this.inputValue = params.inputValue;
      // 更新输入框内容
    }
  }

  build() {
    // 定义 build 方法，用于描述组件的 UI 结构。
    Row() {
      // 创建一个行布局容器。
      Column() {
        // 创建一个列布局容器。
        Text(this.message)
          // 创建一个文本组件，显示 this.message 的内容。
          .fontSize(50)
            // 设置文本字体大小为 50。
          .fontWeight(FontWeight.Bold);
        // 设置文本字体粗细为粗体。
        //设置样式
        Divider()//设置分隔线
          . strokeWidth(15) //设置宽度
          . color(0x6E9BC5) //设置颜色
          . lineCap(LineCapStyle. Round)  //端点样式


        // 显示输入框内容
        Text(this.inputValue)
          // 创建一个文本组件，显示 this.inputValue 的内容。
          .fontSize(30)
            // 设置文本字体大小为 30。
          .fontWeight(FontWeight.Bold);
        // 设置文本字体粗细为粗体。

        Button('start') // 创建一个按钮，显示文本 'start'
          .width(100) // 设置按钮宽度为 100
          .fontSize(30)// 设置文本字体大小为 30。
          .fontWeight(FontWeight.Bold)// 设置文本字体粗细为粗体。
          .padding(5) // 设置按钮内边距为 5
          .onClick(() => { // 绑定点击事件
            this.animationStatus = AnimationStatus.Running; // 点击后将动画状态设置为运行中
          })
          .margin(5); // 设置按钮外边距为 5

        Button('stop') // 创建一个按钮，显示文本 'stop'
          .width(100) // 设置按钮宽度为 100
          .fontSize(30)// 设置文本字体大小为 30。
          .fontWeight(FontWeight.Bold)// 设置文本字体粗细为粗体。
          .padding(5) // 设置按钮内边距为 5
          .onClick(() => { // 绑定点击事件
            this.animationStatus = AnimationStatus.Paused; // 点击后将动画状态设置为暂停
          })
          .margin(5); // 设置按钮外边距为 5

        ImageAnimator() // 创建一个图片动画组件
          .images([ // 设置动画图片序列
            {
              src: $r('app.media.book01'), // 图片资源路径
              duration: 500, // 图片显示时长（单位：毫秒）
              width: 240, // 图片宽度
              height: 350, // 图片高度
              top: 0, // 图片在容器中的垂直位置
              left: 0 // 图片在容器中的水平位置
            },
            {
              src: $r('app.media.book02'), // 图片资源路径
              duration: 500, // 图片显示时长（单位：毫秒）
              width: 240, // 图片宽度
              height: 350, // 图片高度
              top: 0, // 图片在容器中的垂直位置
              left: 0 // 图片在容器中的水平位置
            },
            {
              src: $r('app.media.book03'), // 图片资源路径
              duration: 500, // 图片显示时长（单位：毫秒）
              width: 240, // 图片宽度
              height: 350, // 图片高度
              top: 0, // 图片在容器中的垂直位置
              left: 0 // 图片在容器中的水平位置
            },
            {
              src: $r('app.media.book04'), // 图片资源路径
              duration: 500, // 图片显示时长（单位：毫秒）
              width: 240, // 图片宽度
              height: 350, // 图片高度
              top: 0, // 图片在容器中的垂直位置
              left: 0 // 图片在容器中的水平位置
            }
          ])
          .state(this.animationStatus) // 设置动画的当前状态（运行或暂停）
          .reverse(false) // 设置是否逆序播放（false 表示顺序播放）
          .fixedSize(false) // 设置是否固定图片大小（false 表示不固定）
          .preDecode(2) // 设置预解码的图片数量（2 表示预解码 2 张图片）
          .iterations(-1) // 设置动画循环次数（-1 表示无限循环）
          .width(240) // 设置动画容器的宽度
          .height(350) // 设置动画容器的高度
          .margin({ top: 50 }); // 设置动画容器的外边距（顶部外边距为 50）

      // 添加按钮，以响应用户点击。
        Button() {
          // 创建一个按钮组件。
          Text('Back')
            // 在按钮内部创建一个文本组件，显示 'Back'。
            .fontSize(30)
              // 设置按钮文本字体大小为 30。
            .fontWeight(FontWeight.Bold);
          // 设置按钮文本字体粗细为粗体。
        }
        .type(ButtonType.Capsule)
        // 设置按钮类型为胶囊形状。

        .margin({
          // 设置按钮的外边距。
          top: 20
          // 设置按钮顶部外边距为 20。
        })
        .backgroundColor('#D4E5EF')
        // 设置按钮背景颜色为 '#D4E5EF'。

        .width('40%')
        // 设置按钮宽度为父容器宽度的 40%。

        .height('10%')
        // 设置按钮高度为父容器高度的 10%。

        // 返回按钮绑定到 onclick 事件，点击时跳转到第一页。
        .onClick(() => {
          // 为按钮绑定点击事件。

          console.info('Succeeded in clicking the ‘Back’ button');
          // 在控制台打印日志，表示按钮点击成功。

          try {
            // 尝试执行以下代码。

            // 返回第一页。
            router.back();
            // 调用 router.back 方法，返回上一个页面。
            console.info('Succeeded in returning to the first page.');
            // 在控制台打印日志，表示返回成功。
          } catch (err) {
            // 捕获并处理异常。

            console.error('failed to return to the first page. code is ${code}, message is ${message}');
            // 在控制台打印错误日志，包含错误代码和错误信息。
          }
        });
        // 结束 onClick 事件处理函数。
      }
      // 结束 Column 组件。
      .width('100%')
      // 设置列布局容器的宽度为父容器的 100%。
    }
    // 结束 Row 组件。
    .height('100%')
    // 设置行布局容器的高度为父容器的 100%。
  }
  // 结束 build 方法。
}
// 结束 Page1 组件的定义。
```
## 四、运行效果

**页面一**
初始界面
![Index](image1.png)
在输入框中输入“TaylorSwift”
![Index](image3.png)
**页面二**
文本框未输入任何东西，显示“NOTHING”
![Page1](image2.png)
文本输入TaylorSwift后，文本显示在页面2（page1）界面中
![Page1](image4.png)
单击start按钮，图片轮转
![Page1](image5.png)
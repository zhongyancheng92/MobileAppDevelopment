# 实验二
#### 学号 3225706110
#### 姓名 黄嘉明
```typescript{.line-numbers}
// second.ets
import { router } from '@kit.ArkUI'; // 导入路由功能模块
import { BusinessError } from '@kit.BasicServicesKit'; // 导入错误处理功能模块

// 定义一个类 RouTmp，用于描述上一级页面传递的参数类型
class RouTmp {
  message: string = ''; // 定义一个字符串类型的属性 message，用于存储传递的消息
}

// 获取路由传递的参数，并将其转换为 RouTmp 类型
const params: RouTmp = router.getParams() as RouTmp;

@Entry // 标记当前组件为入口组件
@Component // 标记当前结构体为组件
// 创建 Second 页面组件
struct Second {
  @State message: string = 'Hi there'; // 使用 @State 装饰器声明一个响应式变量 message，初始值为 'Hi there'

  // 构建 UI 组件
  build() {
    // 创建一个行布局
    Row() {
      // 创建一个列布局
      Column() {
        // 创建一个文本组件，显示 message 变量的值
        Text(this.message)
          .fontSize(50) // 设置文本字体大小为 50
          .fontWeight(FontWeight.Bold) // 设置文本字体加粗
          .fontColor(Color.Pink); // 设置文本字体颜色为粉色

        // 创建一个文本组件，显示从路由参数中获取的 message
        Text(params.message)
          .fontSize(40) // 设置文本字体大小为 40
          .fontWeight(FontWeight.Bold); // 设置文本字体加粗

        // 创建一个图片组件，显示网络图片
        Image('https://tse4-mm.cn.bing.net/th/id/OIP-C.fnoislW-iIms0SZ-iFHtvQHaHa?w=207&h=207&c=7&r=0&o=5&pid=1.7')
          .width(200) // 设置图片宽度为 200
          .height(200); // 设置图片高度为 200

        // 创建另一个图片组件，显示网络图片

        Image('https://ts1.tc.mm.bing.net/th/id/R-C.f5bba551c5fde389168f0ce9e2201145?rik=XapyqJ%2b6fXYCcw&riu=http%3a%2f%2fwww.kuaipng.com%2fUploads%2fwater%2ftext%2f2017%2f06-07%2fgoods_water_6525_698_698_.png&ehk=%2fQlYmSlVMMarF6BUBbl11xoDiHtfK0PHpSE85FRcP0s%3d&risl=&pid=ImgRaw&r=0')
          .width(200) // 设置图片宽度为 200
          .height(200); // 设置图片高度为 200

        // 创建一个按钮组件
        Button() {
          // 在按钮内部创建一个文本组件，显示 'Back'
          Text('Back')
            .fontSize(30) // 设置按钮文本字体大小为 30
            .fontWeight(FontWeight.Bold); // 设置按钮文本字体加粗
        }
        .type(ButtonType.Capsule) // 设置按钮类型为胶囊/圆形（Circle）
        .margin({
          top: 20 // 设置按钮上边距为 20
        })
        .backgroundColor('#FF7500') // 设置按钮背景颜色为橙色
        .width('40%') // 设置按钮宽度为父容器的 40%
        .height('5%') // 设置按钮高度为父容器的 5%
        // 设置按钮点击事件
        .onClick(() => {
          console.info('Succeeded in clicking the "Back" button.'); // 打印日志，表示按钮点击成功

          // 使用路由跳转回 Index 页面
          router.pushUrl({ url: 'pages/Index' }).then(() => {
            console.info('Succeeded in jumping to the Index page.'); // 打印日志，表示页面跳转成功
          }).catch((err: BusinessError) => {
            // 如果跳转失败，捕获错误并打印错误信息
            console.error(`Failed to jump to the Index page. Code is ${err.code}, message is ${err.message}`);
          });
        });
      }
      .width('100%'); // 设置列布局宽度为父容器的 100%
    }
    .height('100%'); // 设置行布局高度为父容器的 100%
  }
}
```
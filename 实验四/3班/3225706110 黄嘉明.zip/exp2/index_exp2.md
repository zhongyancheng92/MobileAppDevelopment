# 实验二
#### 学号 3225706110
#### 姓名 黄嘉明
```typescript{.line-numbers}
// index.ets
import { router } from '@kit.ArkUI'; // 导入路由功能模块
import { BusinessError } from '@kit.BasicServicesKit'; // 导入错误处理功能模块

@Entry // 标记当前组件为入口组件
@Component // 标记当前结构体为组件
// 创建 Index 页面组件
struct Index {
  @State message: string = 'Hello World'; // 使用 @State 装饰器声明一个响应式变量 message，初始值为 'Hello World'
  @State rating: number = 0; // 新增评分状态（0-5 分）

  // 星级图标资源
  private starFilled: string = 'https://tse4-mm.cn.bing.net/th/id/OIP-C.CqvLfa4yXACMg07rKMfQygHaHL?rs=1&pid=ImgDetMain'; // 实心星图标 URL
  private starEmpty: string = 'https://tse3-mm.cn.bing.net/th/id/OIP-C.y6qGGzFYRlGJaOJISKrzjQHaHL?rs=1&pid=ImgDetMain'; // 空心星图标 URL
  private readonly starIndexes: number[] = [0, 1, 2, 3, 4]; // 星级的索引数组，用于遍历生成星级评分组件

  // 构建 UI 组件
  build() {
    // 创建一个行布局
    Row() {
      // 创建一个列布局
      Column() {
        // 创建一个文本组件，显示 message 变量的值
        Text(this.message)
          .fontSize(50) // 设置文本字体大小为 50
          .fontWeight(FontWeight.Bold); // 设置文本字体加粗

        // 创建一个行布局，用于放置图片
        Row() {
          // 创建一个图片组件，显示网络图片
          Image('https://tse4-mm.cn.bing.net/th/id/OIP-C.fnoislW-iIms0SZ-iFHtvQHaHa?w=207&h=207&c=7&r=0&o=5&pid=1.7')
            .width(150) // 设置图片宽度为 150
            .height(150); // 设置图片高度为 150

          // 创建另一个图片组件，显示网络图片
          Image('https://ts1.tc.mm.bing.net/th/id/R-C.f5bba551c5fde389168f0ce9e2201145?rik=XapyqJ%2b6fXYCcw&riu=http%3a%2f%2fwww.kuaipng.com%2fUploads%2fwater%2ftext%2f2017%2f06-07%2fgoods_water_6525_698_698_.png&ehk=%2fQlYmSlVMMarF6BUBbl11xoDiHtfK0PHpSE85FRcP0s%3d&risl=&pid=ImgRaw&r=0')
            .width(200) // 设置图片宽度为 200
            .height(200) // 设置图片高度为 200
            .margin(0); // 设置图片外边距为 0
        }

        // 创建一个进度条组件
        Progress({
          value: 80, // 当前进度值
          total: 100, // 总进度值
          type: ProgressType.Linear // 进度条类型为线性
        })
          .width('80%') // 设置进度条宽度为父容器的 80%
          .height(30) // 设置进度条高度为 30
          .margin({ top: 20, bottom: 20 }) // 设置进度条上下边距为 20
          .backgroundColor('#eeeeee') // 设置进度条轨道背景色为浅灰色
          .style({ strokeWidth: 20 }); // 设置进度条粗细为 20

        // 创建一个行布局，用于放置星级评分组件
        Row() {
          // 使用 ForEach 遍历 starIndexes 数组，生成星级评分组件
          ForEach(this.starIndexes, (index: number) => {
            Image(this.rating > index ? this.starFilled : this.starEmpty) // 根据评分状态显示实心星或空心星
              .width(40) // 设置星星图标宽度为 40
              .height(40) // 设置星星图标高度为 40
              .margin(5) // 设置星星图标外边距为 5
              .onClick(() => {
                this.rating = index + 1; // 点击星星时更新评分状态
              })
              .transition({
                scale: { x: 0.9, y: 0.9 }, // 添加点击时的缩放动画效果
              });
          });
        }
        .margin({ top: 20 }); // 设置星级评分组件的上边距为 20

        // 创建一个按钮组件
        Button() {
          // 在按钮内部创建一个文本组件，显示 'Next'
          Text('Next')
            .fontSize(30) // 设置按钮文本字体大小为 30
            .fontWeight(FontWeight.Bold); // 设置按钮文本字体加粗
        }
        .type(ButtonType.Capsule) // 设置按钮类型为胶囊形状
        .margin({
          top: 20 // 设置按钮上边距为 20
        })
        .backgroundColor('#41BA41') // 设置按钮背景颜色为绿色
        .width('40%') // 设置按钮宽度为父容器的 40%
        .height('5%') // 设置按钮高度为父容器的 5%
        // 设置按钮点击事件
        .onClick(() => {
          console.info('Succeeded in clicking the "Next" button.'); // 打印日志，表示按钮点击成功

          // 使用路由跳转到第二个页面，并传递参数
          router.pushUrl({
            url: 'pages/second', // 目标页面路径
            params: {
              message: 'Leader' // 传递的参数
            }
          }).then(() => {
            console.info('Succeeded in jumping to the second page.'); // 打印日志，表示页面跳转成功 
          }).catch((err: BusinessError) => {
            // 如果跳转失败，捕获错误并打印错误信息
            console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`);
          });
        });
      }
      .width('100%'); // 设置列布局宽度为父容器的 100%
    }
    .height('100%'); // 设置行布局高度为父容器的 100%
  }
}
```
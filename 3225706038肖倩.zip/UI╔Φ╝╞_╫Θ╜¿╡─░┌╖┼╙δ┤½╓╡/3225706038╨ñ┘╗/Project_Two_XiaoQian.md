# 实验二：组件的摆放与传值

## 一、传值
### 1.getState()
* 先定义出RouterParams接口，用于检查第一页面传来的参数类型。再使用aboutToAppear方法使用router.getState()?.params来获取路由参数，这里用到了TypeScript的类型断言，将params转换为RouteParams接口，确保类型安全。然后将获取到的name参数赋值给@State修饰的Name变量，运用空值合并运算符??，防止params.name为undefined的情况。
```typescript{.line-numbers}
import { router } from '@kit.ArkUI';
//接口
// 定义路由参数接口（类型安全）
     interface RouteParams {// 检查参数是否符合RouteParams的结构，确保name属性存在且类型正确，或者允许它不存在。
       name?: string; //将 name定义为可选参数，则该接口中可以没有name属性，但若果有name属性，该属性的类型一定是string
     }

@Entry
@Component
struct Second {

// @State装饰器将组件的属性标记为响应式状态
        @State private Name: string = 'XiaoQian';
// aboutToAppear方法
       aboutToAppear() {
         const params = router.getState()?.params as RouteParams;
         //router.getState()获取当前路由状态
         //?安全地访问对象的深层属性，避免在访问过程中因中间属性为null/undefined而导致运行时错误。
         //类型断言
         this.Name = params?.name ?? 'XiaoQian';
         //?安全访问name但如果name为null/undefine则输出默认值XiaoQian
            }
```

### 2.getParams()
* 先创建路由参数规范类，定义参数类型，然后在结构体中使用类型断言直接获取参数
```typescript{.line-numbers}
import { router } from '@kit.ArkUI';//导入跳转模块中的router对象

//参数规范类
class RouterParams {//规范路由参数的格式
  name: string;//传递的参数名name，文字类型
  constructor(name: string) {this.name = name;}}//强制检查传入的name的类型，如果不是string类型，就报错

@Entry//定义组件入口
@Component//声明这是一个自定义组件
struct Second {//定义名为Second的结构体

//使用类型断言获取参数
  @State Name: string = (router.getParams() as RouterParams).name;//从路由参数中获取name并将名字定义为Name（用类型断言保证name的类型）
  ```
### 3.UIContext
* 以下是对API参考文档中代码的简单变化，并没有在本次实验中运用到，在此仅作传值方法的一种参考

*第一页*
```typescript{.line-numbers}
import { router } from '@kit.ArkUI';
import { BusinessError } from '@kit.BasicServicesKit'

// 简单参数类
class SimpleParams {
  message: string
  constructor(msg: string) {
    this.message = msg//强制检查传入的name的类型，如果不是string类型，就报错
  }
}

@Entry
@Component
struct SenderPage {
  async ToSecondPage() {//async 表示这是一个异步函数，内部可能包含异步操作（如 API 请求、定时器、文件读写等）

    try {
      // 通过UI上下文获取路由实例
      const routerInstance = this.getUIContext().getRouter();

      // 配置路由参数
      const options: router.RouterOptions = {
        url: 'pages/Second', // 目标页面路径
        params: new SimpleParams('xiaoqian') // 创建参数实例
      }

      // 执行页面跳转
      await routerInstance.pushUrl(options)
    } catch (err) {
      console.info(`Failedcode: ${(err as BusinessError).code}, message: ${(err as BusinessError).message}`)
    }
  }

  build() {
    Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
      Text('Page_One').fontSize(50).fontWeight(FontWeight.Bold)

      Button() {
        Text('Next').fontSize(25).fontWeight(FontWeight.Bold)}
      .type(ButtonType.Capsule).width('30%').height('10%').margin({top:30}).backgroundColor('#4CAF50')
      .onClick(() => {this.ToSecondPage()})
    }.width('100%').height('100%')
  }
}
```



*第二页*
```typescript{.line-numbers}
// 与发送方保持一致的参数类
class SimpleParams {
  message: string
  constructor(msg: string) {
    this.message = msg
  }
}

@Entry
@Component
struct ReceiverPage {
  // 使用State装饰器接收参数
  @State receivedMessage: string = ''

  aboutToAppear() {
    // 通过UI上下文获取路由实例
    const routerInstance = this.getUIContext().getRouter();

    // 获取参数并进行类型断言
    const params = routerInstance.getParams() as SimpleParams;

    // 更新状态显示接收到的消息
    this.receivedMessage = params.message;
  }

  build() {
    Flex({ direction: FlexDirection.Column, alignItems: ItemAlign.Center, justifyContent: FlexAlign.Center }) {
      Text('Page_Two').fontSize(50).fontWeight(FontWeight.Bold)

      Text(this.receivedMessage).fontSize(30).margin({ top: 40 }).backgroundColor('#FFEB3B')
    }.width('100%').height('100%')
  }
}
```
![alt text](image-5.png)||![alt text](image-6.png)

## 二、实验步骤
### 1.界面一插入图片、输入框、跳转按钮、加载组件、滚动条
* * * * 
```typescript{.line-numbers}
import { router } from '@kit.ArkUI';//导入跳转模块中的router对象
import { BusinessError } from '@kit.BasicServicesKit';//导入模块中的Business


@Entry//定义入口点
@Component//定义这是一个组件
struct Index {//定义名为Index的结构体
  @State name:string = 'xiaoqian';//定义名为name的类字段，并附上初值
  @State number_id:string ='3225706038';//定义名为number_id的类字段，并附上初值



  build() {//定义界面背景
    Row() {//定义一行
      Column() {//定义一列

//插入图片
        Row(){Image($r('app.media.digit_fafu')).height('十').width(350)}.position({x:0,y:-190})
        //将图片放在行容器里，并设置位置

//输入框
        TextInput({placeholder:'姓名'}).placeholderColor(Color.Gray).placeholderFont({size:14,weight:400}).caretColor(Color.Blue).width(200).height(47).fontSize(24).fontColor(Color.Black)//设置姓名输入框及输入框的各参数
            .onChange((value) => {this.name = value;})//及时更新name的具体值
        TextInput({placeholder:'学号'}).placeholderColor(Color.Gray).placeholderFont({size:14,weight:400}).caretColor(Color.Blue).width(200).height(47).fontSize(24).fontColor(Color.Black).margin(5)//设置学号输入框及输入框的各参数
        TextInput({placeholder:'设置密码'}).placeholderColor(Color.Gray).placeholderFont({size:14,weight:400}).caretColor(Color.Blue).width(200).height(47).fontSize(12).fontColor(Color.Black).margin(1)//设置密码输入框及输入框的各参数
            .type(InputType.Password).maxLength(12).showPasswordIcon(true)//设置为密码的文本输入框类型


//添加提交按钮
        Button() {Text('注册').fontSize(20).fontWeight(FontWeight.Bold)}//定义按钮里的文本
        .type(ButtonType.Capsule).margin({ top: 20 }).backgroundColor('#0D9FFB').height("6%").width("28%")//定义按钮的样式
//按钮绑定onclick事件，点击时跳转
        .onClick(() => {console.info(`Succeeded in clicking the 'Next' button.`)//控制台记录按钮被点击
//跳转到第二页
          router.pushUrl({ url: 'pages/Second', params:{name:this.name,number_id:this.number_id} })//跳转到Second页面的同时将用户输入的姓名、学号的具体值一起传过去
            .then(() => {console.info('Succeeded in jumping to the second page')})//控制台记录成功跳转
            .catch((err: BusinessError) => {console.error(`Failed to jump to the secong page.Code is ${err.code},message is ${err.message}`) }) //跳转失败时捕获错误，控制台记录跳转失败，输出错误日志
        })//结束onClick方法


//小组件及滚动条

        Row(){//定义一行
          //希望LoadingProgress组件不要太大，并且和滚动条在同一行
          Column(){LoadingProgress().color(Color.Blue)}.width('9%')//分出一列给LoadingProgress组件
          Column(){Marquee({ start:true, step:5, loop:-1, fromStart:true, src:"福建农林大学坐落于福建省会福州，是一所以农林科学、生命科学为优势和特色，理、工、经、管、文、法、艺等多学科协调发展的省属重点大学，是农业农村部与福建省人民政府共建高校、国家林业和草原局与福建省人民政府共建高校，是福建省高水平大学建设高校、福建省一流大学建设高校、福建省“双一流”建设A类高校。" }).fontSize(20)
            //滚动条组件的相关设置
          }.width('95%')}.height('10%').position({x:0,y:420})//结束此行的定义
      }.width("100%").padding(0) //结束列的内部定义并清除默认内边距

    }.height("100%")//结束行的内部定义
  }//结束屏幕的定义
}//结束结构体的定义
```
![alt text](image.png)
### 2.界面二插入步骤导航组件，完成注册所需要的用户性别、出生日期、专业信息
#### *1 getState（）*
* * * * 
```typescript{.line-numbers}
import { router } from '@kit.ArkUI';
//接口
// 定义路由参数接口（类型安全）
     interface RouteParams {// 检查参数是否符合RouteParams的结构，确保name属性存在且类型正确，或者允许它不存在。
       name?: string; //将 name定义为可选参数，则该接口中可以没有name属性，但若果有name属性，该属性的类型一定是string
     }
  @Styles
  function itemStyle() {
  .width(336).height(621).margin({ top: 48, left: 2, right: 2 }).borderRadius(24)
  .backgroundColor('#D3D3D3')
}
@Entry
@Component
struct Second {
// @State装饰器将组件的属性标记为响应式状态
        @State private Name: string = 'XiaoQian';
// aboutToAppear 方法
       aboutToAppear() {
         const params = router.getState()?.params as RouteParams;
         //router.getState()获取当前路由状态
         //?安全地访问对象的深层属性，避免在访问过程中因中间属性为null/undefined而导致运行时错误。
         //类型断言
         this.Name = params?.name ?? 'XiaoQian';
         //?安全访问name但如果name为null/undefine则输出默认值XiaoQian
            }


  build() {//屏幕界面
    Row(){//一行
      Column(){//一列
        Text(`Hello!   ${this.Name}`).fontSize(34)//输出文本，文本中使用${}引用Name


        //步骤导航组件
        Stepper({index:0}){//设置Stepper当前StepperItem的索引值

          StepperItem() {//第一页
            Column(){//一列
              Row(){Text('请选择你的性别').fontSize(30)}.height(70)//利用Row划分界面，输出文本


              //选择性别
              Row() {Checkbox({ name: 'checkbox1', group: 'checkboxGroup' })//复选框
                .select(true).selectedColor(0xed6f21).shape(CheckBoxShape.CIRCLE)//复选框样式设置
                .onChange((value: boolean) => {console.info('Checkbox1 change is' + value)})//及时更新和控制台信息
                Text(`女`).fontSize(20)}.height(70)//第一个复选框后跟着的文本
              Row() {Checkbox({ name: 'checkbox2', group: 'checkboxGroup' })//复选框
                .select(false).selectedColor(0x39a2db).shape(CheckBoxShape.ROUNDED_SQUARE)//复选框样式设置
                .onChange((value: boolean) => {console.info('Checkbox2 change is' + value)})//及时更新和控制台信息
                Text('男').fontSize(20)}//第二个复选框后跟着的文本


              //选择出生日期
              Row(){Text('请选择你的出生日期').fontSize(30)}.height(70).margin({top:30})//输出文本
              Row(){DatePicker({ start:new Date('1940-1-1'), end:new Date('2020-1-1') })}.height(190)//选择日期的滑动选择器组件


              //添加图片
              Row(){//一行
                Image($r('app.media.QR')).height(80).width(80)//图片
                Text('欢迎关注福建农林大学微信公众号').margin({top:10})//文字
              }.height(30).margin({top:90})//尺寸和位置
            }.itemStyle()//第一页的样式

          }.nextLabel('下一页')//下一页按钮

          StepperItem(){//第二页
            Row(){//一行
              Column(){//一列

                Row(){Text('请选择你的专业').fontSize(30)}//输出文本
                .alignItems(VerticalAlign.Top).margin({top:-60})//位置的设置


                //选择专业
                Row(){TextPicker({ range:['环境科学与工程','空间信息与数字技术','农业资源与环境'],selected:1 })//滑动选择文本内容的组件
                  .defaultPickerItemHeight(30).margin({top:30}).width(300)//位置的设置
                }.height(200).alignItems(VerticalAlign.Center)//位置的设置
              }.width("100%")//列的宽度
            }.height("100%")//行的大小
            .itemStyle()//页面的样式
          }.nextLabel('完成').prevLabel('上一页')//下方按钮的设置


          StepperItem() {//第三页
            Column() {//一列

              Text('注册成功').fontSize(50).fontColor(Color.Green)//输出文本
              TextClock().margin(20).fontSize(25).format('yyyy年MM月dd日 HH:mm')

            }//结束列的定义
          }//结束第三页的定义


        }//结束Stepper的定义
      }//结束列的定义
    }//结束行的定义
  }//结束屏幕的定义
}//结束结构体的定义
```
#### *2 getParams（）*
* * * * 
```typescript{.line-numbers}
import { router } from '@kit.ArkUI';//导入跳转模块中的router对象


class RouterParams {//规范路由参数的格式
  name: string;//传递的参数名name，文字类型
  constructor(name: string) {this.name = name;}}//强制检查传入的name的类型，如果不是string类型，就报错


@Styles
function itemStyle() {
  .width(336).height(621).margin({ top: 48, left: 2,right:2 }).borderRadius(24)/*圆角24vp*/ .backgroundColor('#D3D3D3')}
//使用@Styles先设置好Stepper里每个StepperItem页面的公共样式

@Entry//定义组件入口
@Component//声明这是一个自定义组件
struct Second {//定义名为Second的结构体

  @State Name: string = (router.getParams() as RouterParams).name;//从路由参数中获取name并将名字定义为Name（用类型断言保证name的类型）
 
  build() {//屏幕界面
   //内部同上
  }//结束屏幕的定义
}//结束结构体的定义
```
![alt text](image-1.png)||![alt text](image-2.png)
![alt text](image-3.png)



// 导入ArkUI框架的路由模块，用于页面跳转
import { router } from '@kit.ArkUI';

// @Entry装饰器：标记此为应用入口组件
@Entry
// @Component装饰器：声明自定义组件
@Component
// 定义名为Index的组件结构体
struct Index {
  // @State装饰器：创建响应式状态变量message，初始值为'Hello World'
  @State message: string = 'Hello World';

  // build方法：定义UI描述
  build() { // build方法开始
    // 创建垂直布局容器
    Column() { // Column组件开始
      // 创建文本组件显示message变量
      Text(this.message)
        // 设置字体大小为50逻辑像素
        .fontSize(50)
        // 设置字体加粗
        .fontWeight(FontWeight.Bold)
        // 设置下边距为20逻辑像素
        .margin({ bottom: 20 })
          // 点击文本跳转到Second页面（注释位置需调整）

      // 创建提示文本组件
      Text('Go to Second Page')
        // 设置字体大小为20逻辑像素
        .fontSize(20)
        // 设置字体颜色为灰色
        .fontColor(Color.Gray);

      // 创建按钮组件
      Button('Go!') // 按钮组件开始
        // 设置按钮类型为胶囊样式
        .type(ButtonType.Capsule)
        // 设置字体大小为30逻辑像素
        .fontSize(30)
        // 设置按钮宽度为父容器的40%
        .width('40%')
        // 设置固定高度为40逻辑像素（vp单位）
        .height(40)
        // 设置字体加粗
        .fontWeight(FontWeight.Bold)

      // 设置上边距为20逻辑像素
      .margin({ // margin对象字面量开始
        top: 20
      }) // margin对象字面量结束
      // 绑定点击事件
      .onClick(() => { // 点击回调开始
        // 使用路由跳转到Second页面
        router.pushUrl({
          url: 'pages/Second', // 目标页面路径
          params: { message: this.message } // 携带的参数
        });
        // 控制台输出日志
        console.info('Succeeded in returning to the second page.')
      }); // 点击回调结束
    } // Column组件结束
    // 设置容器宽度为100%父容器宽度
    .width('100%')
    // 设置容器高度为100%父容器高度
    .height('100%')

  } // build方法结束
} // Index结构体结束
![第一个页面](./image1.jpg)
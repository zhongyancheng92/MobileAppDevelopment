// 导入ArkUI路由模块
import { router } from '@kit.ArkUI';

// 定义路由参数类型约束
interface RouteParams { // interface开始
  message?: string;     // 可选字符串参数
} // interface结束

@Entry // 入口组件装饰器
@Component // 组件装饰器
struct Second { // struct开始
  // 响应式状态变量
  @State message: string = 'Hi there'; // 默认消息

  // UI构建方法
  build() { // build方法开始
    // 创建垂直布局容器
    Column() { // Column组件开始
      // 主文本组件
      Text(this.message) // 使用状态变量
        .fontSize(50)    // 字号50逻辑像素
        .fontWeight(FontWeight.Bold) // 粗体
        .textAlign(TextAlign.Center); // 居中

      // 返回按钮组件
      Button('Back') // 按钮文本
        .type(ButtonType.Capsule)  // 胶囊样式
        .backgroundColor('#FF5733')// 背景色
        .width('40%')   // 相对宽度
        .height(40)     // 固定高度
        .margin({ top: 20 }) // 上边距
        .onClick(() => { // 点击回调开始
          router.back();  // 路由返回
          console.info('Succeeded in returning to the first page.') // 日志
        }); // 点击回调结束

    } // Column组件结束
    .width('100%')  // 容器宽度
    .height('100%') // 容器高度

  } // build方法结束

  // 生命周期钩子：页面显示前触发
  aboutToAppear() { // 方法开始
    // 获取路由参数并类型断言
    const params = router.getParams() as RouteParams;
    // 更新消息(带默认值处理)
    this.message = params?.message || 'No message received';
  } // 方法结束
} // struct结束
![第二个页面](./image2.jpg)
![日志](./image3.png)
```java
// 导入ArkUI的路由模块，用于页面跳转管理
import { router } from '@kit.ArkUI';
// 导入基础服务错误类型，用于错误处理
import { BusinessError } from '@kit.BasicServicesKit';

// @Entry装饰器标记此为应用入口组件
@Entry// @Entry start
  // @Component装饰器声明自定义组件
@Component// @Component start
struct Index {// struct Index start
  // @State装饰器管理组件状态，message变化会触发UI更新
  @State message: string = 'Hello World'

  // build方法描述UI结构
  build() {// build() start
    // Row横向布局容器
    Row() {// Row() start
      // Column纵向布局容器（Row的唯一子元素）
      Column() {// Column() start
        // 文本组件显示状态变量message
        Text(this.message)// Text() start
          .fontSize(50)          // 字体大小50
          .fontWeight(FontWeight.Bold)  // 加粗字体
        // Text() end
        // 按钮组件开始
        Button() {// Button() start
          // 按钮内的文本组件
          Text('Next')// Text() start
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }// Text() end
        // Button() end

        // 设置按钮样式为胶囊形状
        .type(ButtonType.Capsule)
        // 设置上边距20
        .margin({ // margin对象字面量 start
          top: 20
        })// margin对象字面量 end
        // 设置背景颜色为蓝色
        .backgroundColor('#0D9FFB')
        // 设置宽度为父容器的40%
        .width('40%')
        // 设置高度为父容器的5%
        .height('5%')
        // 绑定点击事件处理
        .onClick(() => {// onClick回调函数 start
          // 点击时输出日志
          console.info(`Succeeded in clicking the 'Next' button.`)

          // 使用路由模块跳转到第二页
          router.pushUrl({ url: 'pages/Second' }).then(() => {// then回调 start
            // 跳转成功回调
            console.info('Succeeded in jumping to the second page.')
          }).catch((err: BusinessError) => {// catch回调 start
            // 跳转失败回调，输出错误信息
            console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`)
          })// catch回调 end
        })// onClick回调函数 end
      }// Column() end
      // Column占满父容器宽度
      .width('100%')
    }// Row() end
    // Row占满父容器高度
    .height('100%')
  }// build() end
}// struct Index end
// @Component end
// @Entry end
```
```java
{
    "src": [
      "pages/Index",
      "pages/second"
    ]
  }
  ```
# <center>**实验一 页面跳转**</center>
## <center>空数3班 3225706082 茅涵馨 </center> 
### 一、创建Index页面  
``` JS
//router是ArkUI框架提供的页面路由管理工具，用于实现页面跳转、参数传递、返回等导航操作
import { router } from '@kit.ArkUI';
//BusinessError是ArkTS中定义的业务错误类型，用于处理应用中的异常情况。
import { BusinessError } from '@kit.BasicServicesKit';

@Entry
@Component
//定义组件名为Index
struct Index {
  @State message: string = 'Index页面';
  //UI构建方法build（）
  build() {
    Row(){
      Column(){
      //UI内容
        //显示@State变量message里的内容，并设置其相关属性
        Text(this.message)
          .fontSize(50)
          .fontWeight(FontWeight.Bold)
        //添加按钮，以响应用户点击
        Button(){
          Text('Next')
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }
        //设置按钮样式为胶囊形状
        .type(ButtonType.Capsule)
        .margin({
          top: 20
        })
        .backgroundColor('#0D9FF8')
        .width('40%')
        .height('5%')
        //（异步事件处理）跳转按钮绑定onClick事件，点击时触发回调函数
        .onClick(()=> {
          console.info(`Succeeded in clicking the 'Next' button.`)
            //跳转到第二页
            //用到了Promise链式调用；.then（）代表跳转成功时执行，打印成功日志；.catch()代表跳转失败时捕获BusinessError错误，输出错误码和消息
            router.pushUrl({ url:'pages/Second'}).then(() =>{console.info(`Succeeded in jumping to the second page.`)
            }).catch ((err:BusinessError) => {
            console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`)
          })
        })
      }
      .width('100%')
    }
    .height('100%')
  }
}
```  

### 二、Second页面  

``` JS 
import { router } from '@kit.ArkUI';
import { BusinessError } from '@kit.BasicServicesKit';

@Entry
@Component
//定义组件名为Second
struct Second {
  @State message: string = 'Hello World';

  build() {
    Row() {
      Column() {
        Text(this.message)
          .fontSize(50)
          .fontWeight(FontWeight.Bold)

        Button() {
          Text('Back')
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }
        .type(ButtonType.Capsule)
        .margin({
          top: 20
        })
        .backgroundColor('#0D9FF8')
        .width('40%')
        .height('5%')
        //跳转按钮绑定onClick事件，点击时返回到第一页
        .onClick(() => {
          console.info(`Succeeded in clicking the 'Back' button.`)
          try {
            /*返回第一页
            此函数完成页面跳转
            try-catch：捕获可能抛出的异常*/
            router.back()
            console.info(`Succeeded in returning to the first page.`)
          }catch (err) {
            let code = (err as BusinessError).code;
            let message = (err as  BusinessError).message;
            console.error(`Failed to return to the first page. Code is ${code},message is ${message}`)
          }
        })
      }
      .width('100%')
    }
    .height('100%')
  }
}  
```  

### 三、截图
![alt text](Index页面.png.png)
![alt text](Second页面.png.png) 
![alt text](日志.png.png)
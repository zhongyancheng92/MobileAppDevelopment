# lesson1:页面跳转
使用Row和Column组件构建页面，并在页面中添加按钮，点击按钮跳转到第二个界面




### 第一个界面
```json5 {.line-numbers}
// 从 '@kit.ArkUI' 模块导入 router 对象，用于页面跳转
import { router } from '@kit.ArkUI';

// 从 '@kit.BasicServicesKit' 模块导入 BusinessError 类，用于处理业务错误
import { BusinessError } from '@kit.BasicServicesKit';

// 使用 @Entry 装饰器标记这是一个入口组件
@Entry

// 使用 @Component 装饰器标记这是一个组件
@Component

// 定义一个名为 Index 的组件结构
struct Index {
  // 使用 @State 装饰器定义一个状态变量 message，初始值为 'Hello World'
  @State message: string = 'Hello World';

  // 定义组件的构建方法
  build() {
    // 创建一个 Row 容器，用于水平布局
    Row() {
      // 创建一个 Column 容器，用于垂直布局
      Column() {
        // 创建一个 Text 组件，显示 message 的内容
        Text(this.message)
          // 设置字体大小为 50
          .fontSize(50)
          // 设置字体加粗
          .fontWeight(FontWeight.Bold)

        // 创建一个 Button 组件
        Button(){
          // 在 Button 中创建一个 Text 组件，显示按钮文本 'Next'
          Text('Next')
            // 设置字体大小为 30
            .fontSize(30)
            // 设置字体加粗
            .fontWeight(FontWeight.Bold)
        }
        // 设置按钮类型为胶囊形状
        .type(ButtonType.Capsule)
        // 设置按钮的外边距，顶部为 20
        .margin({
          top: 20
        })
        // 设置按钮的背景颜色为 '#0D9FFB'
        .backgroundColor('#0D9FFB')
        // 设置按钮的宽度为屏幕的 40%
        .width('40%')
        // 设置按钮的高度为屏幕的 5%
        .height('5%')
        // 设置按钮的点击事件
        .onClick(() => {
          // 打印日志，表示按钮被点击
          console.info('Succeeded in clicking the "Next" button.')
          // 使用 router.pushUrl 方法跳转到 'pages/Second' 页面
          router.pushUrl({ url: 'pages/second' }).then(() => {
            // 如果跳转成功，打印成功日志
            console.info('Succeeded in jumping to the second page.')
          }).catch((err: BusinessError) => {
            // 如果跳转失败，捕获错误并打印错误信息
            console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`)
          })
        })
      }
      // 设置 Column 容器的宽度为屏幕的 100%
      .width("100%")
    }
    // 设置 Row 容器的高度为屏幕的 100%
    .height("100%")
  }
}
```
界面展示：
![[1.png]]{width="300px" height=300px"}




# 
#### 第二个界面
```json5 {.line-numbers}
// 从 '@kit.ArkUI' 模块导入 router 对象，用于页面导航（如返回上一页）
import { router } from '@kit.ArkUI';

// 从 '@kit.BasicServicesKit' 模块导入 BusinessError 类，用于处理可能发生的业务错误
import { BusinessError } from '@kit.BasicServicesKit';

// 使用 @Entry 装饰器标记这是一个入口组件
@Entry

// 使用 @Component 装饰器标记这是一个组件
@Component

// 定义一个名为 Second 的组件结构，表示第二个页面
struct Second {
  // 使用 @State 装饰器定义一个状态变量 message，初始值为 'Hi there'
  @State message: string = 'Hi there';

  // 定义组件的构建方法，用于构建页面的 UI 结构
  build() {
    // 创建一个 Row 容器，用于水平布局，包裹整个页面内容
    Row() {
      // 创建一个 Column 容器，用于垂直布局，将内容垂直排列
      Column() {
        // 创建一个 Text 组件，显示状态变量 message 的内容
        Text(this.message)
          // 设置文本的字体大小为 50
          .fontSize(50)
          // 设置文本的字体为加粗
          .fontWeight(FontWeight.Bold);

        // 创建一个 Button 组件，用于返回第一个页面
        Button() {
          // 在按钮中嵌套一个 Text 组件，显示按钮文本 "Back"
          Text("Back")
            // 设置按钮文本的字体大小为 30
            .fontSize(30)
            // 设置按钮文本的字体为加粗
            .fontWeight(FontWeight.Bold);
        }
        // 设置按钮的类型为胶囊形状
        .type(ButtonType.Capsule)
        // 设置按钮的外边距，顶部为 20
        .margin({
          top: 20
        })
        // 设置按钮的背景颜色为 #0D9FFB
        .backgroundColor("0D9FFB")
        // 设置按钮的宽度为屏幕宽度的 40%
        .width('40%')
        // 设置按钮的高度为屏幕高度的 5%
        .height('5%')
        // 设置按钮的点击事件
        .onClick(() => {
          // 打印日志，表示按钮被点击
          console.info('Succeeded in clicking the "Back" button.')
          try {
            // 调用 router.back() 方法返回上一页
            router.back();
            // 如果返回成功，打印成功日志
            console.info("Succeeded in returning to the first page.")
          } catch (err) {
            // 如果返回失败，捕获错误并处理
            // 将错误对象强制转换为 BusinessError 类型，以获取错误代码和消息
            let code = (err as BusinessError).code;
            let message = (err as BusinessError).message;
            // 打印错误日志，包含错误代码和错误消息
            console.error(`Failed to return to the first page. Code is ${code}, message is ${message}`)
          }
        });
      }
      // 设置 Column 容器的宽度为屏幕宽度的 100%
      .width('100%');
    }
    // 设置 Row 容器的高度为屏幕高度的 100%
    .height('100%');
  }
}
```
界面展示：
![[2.png]]{width="300px" height=300px"}
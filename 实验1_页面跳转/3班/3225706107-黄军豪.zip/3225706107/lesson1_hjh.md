# 实现页面跳转
## 第一个页面
```typescript {.line-numbers}
import { router } from '@kit.ArkUI';// 导入ArkUI框架中的router模块，用于页面跳转
import { BusinessError } from '@kit.BasicServicesKit';// 导入BasicServicesKit框架中的BusinessError类，用于处理业务错误
@Entry// 使用@Entry注解标记First组件为应用的入口组件
@Component// 使用@Component注解定义First组件
struct First {// 定义 First 组件结构体
  @State message: string = 'First_Page';// 定义一个状态变量message，初始值为'First_Page'
  build() { // build方法用于构建组件的UI
    Row() { // 使用Row布局容器，用于水平排列子组件
      Column(){ // 使用Column布局容器，用于垂直排列子组件
        Text(this.message)// 显示message变量内容
          .fontSize(50)//设置文本字体大小为50
          .fontWeight(FontWeight.Bold) //设置文本字体加粗
        Button(){// 创建一个按钮
          Text('Next') // 按钮中的文本内容显示'Next'
            .fontSize(30)//设置按钮内文本字体大小为30
            .fontWeight(FontWeight.Bold)//设置按钮内文本字体加粗
        }
        .type(ButtonType.Capsule) // 设置按钮类型为胶囊型
        .margin({// 设置按钮的外边距
          top: 20//顶部外边距为20
        })
        .backgroundColor('#FFF68F')//背景色为#FFF68F
        .width('40%')//设置按钮的宽度为父容器的 40%
        .height('5%')//设置按钮的高度为父容器的 5%
        .onClick(() => { // 为按钮设置点击事件监听器
          console.info('Succeeded in clicking the "Next" button.')//输出日志，表示点击按钮成功，在控制台输出点击按钮成功信息
          router.pushUrl({url: 'pages/Second' }).then(() => {// 使用 router 的 pushUrl 方法跳转到'pages/Second'页面
            // 输出日志，表示跳转到第二页成功，在控制台输出跳转成功信息
            console.info('Succeeded in jumping to the second page.')
          }).catch((err: BusinessError) => {// 跳转失败时的回调，接收一个 BusinessError 类型的参数 err
            console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`)// 捕获BusinessError错误，输出错误代码和错误信息
          })
        })
      }
      .width('100%')// 设置列布局的宽度为父容器的 100%
    }
    .height('100%')// 设置行布局的高度为父容器的 100%
  }
}
```
 ## 第二个页面
```typescript {.line-numbers}
import { router } from '@kit.ArkUI';//导入ArkUI框架中的router模块，用于页面跳转
import { BusinessError } from '@kit.BasicServicesKit';//导入BasicServicesKit框架中的BusinessError类，用于处理业务错误
@Entry// 使用@Entry注解标记Second组件为应用的另一个可能的入口组件
@Component// 使用@Component注解定义Second组件
struct Second {// 定义 Second 组件结构体
  @State message: string = 'Second_Page';// 定义一个状态变量message，初始值为'Second_Page'
  build() { // build方法用于构建组件的UI
    Row(){ // 使用Row布局容器，用于水平排列子组件
      Column() { // 使用Column布局容器，用于垂直排列子组件
        Text(this.message)// 创建一个文本元素，显示 this.message 的值
          .fontSize(50)// 设置文本字体大小为 50
          .fontWeight(FontWeight.Bold) // 设置文本字体加粗
        // 创建一个按钮
        Button() {// 创建一个按钮
          Text('Back')// 按钮中的文本内容为 'Back'
            .fontSize(30)// 设置按钮内文本字体大小为 30
            .fontWeight(FontWeight.Bold) // 设置按钮内文本字体加粗
        }
        .type(ButtonType.Capsule) // 设置按钮类型为胶囊型
        .margin({ // 设置按钮的外边距
          top: 20// 顶部外边距为 20
        })
        .backgroundColor('#FFF68F')// 设置按钮的背景颜色
        .width('40%')// 设置按钮的宽度为父容器的 40%
        .height('5%')// 设置按钮的高度为父容器的 5%
        .onClick(() => { // 为按钮设置点击事件监听器
          console.info('Succeeded in clicking the "Back" button.') //输出日志，表示点击按钮成功，在控制台输出点击按钮成功信息
          try{
            router.back()// 使用 router 的 back 方法返回上一页
            console.info('Succeeded in returning to the first page.') // 返回成功后，在控制台输出返回成功信息
          }catch(err){// 捕获返回上一页时可能出现的异常
            let code = (err as BusinessError).code; // 获取错误的代码
            let message = (err as BusinessError).message; // 获取错误的消息
            console.error(`Failed in return to the first page. Code is ${code}, message is ${message}`)// 输出错误日志，包含错误代码和消息
          }
        })
      }
      .width('100%') // 设置列布局的宽度为父容器的 100%
    }
    .height('100%') // 设置行布局的高度为父容器的 100%
  }
}

```
<img src="第一个页面.png" width="400" height="550" alt="alt text">
<img src="第二个页面.png" width="400" height="550" alt="alt text">

# Experiment 1 实现页面跳转

## 一、实验目的

实现Ability内页面的跳转。

在第一个页面单击**”NEXT“**按钮后，能从第一个页面跳转到第二个页面；

在第二个页面单击**“BACK”**按钮后，会重新回到第一个页面。

## 二、代码与注释

### 第一个页面

> [!NOTE]
>
> Index.ets

```json5 {.line-numbers}
// 导入页面路由模块
import { router } from '@kit.ArkUI'; // 从ArkUI工具包中导入router模块，用于页面跳转
import { BusinessError } from '@kit.BasicServicesKit'; // 从基础服务工具包中导入BusinessError类，用于错误处理
@Entry // @Entry装饰器标记当前组件为入口组件
@Component // 使用@Component装饰器定义一个自定义组件
struct Index { // 定义名为Index的组件结构体
  @State message: string = 'This is the first page!'; // @State装饰器声明响应式数据，当message变化时会触发UI更新，定义了一个状态变量message，并初始化为字符串'This is the first page!'
  build() { // build函数是组件UI的构建入口
    Row(){  // 使用Row组件水平/横向布局容器（根布局）
      Column(){ // Column纵向布局容器（作为Row的直接子组件）
        Text(this.message) // 使用Text组件显示message变量的值
          .fontSize(50) // 设置字体大小为50
          .fontWeight(FontWeight.Bold); // 设置字体加粗
        
        Button(){ // 定义Button按钮组件
          Text('Next') // 显示按钮文本
            .fontSize(30) // 设置字体大小为30
            .fontWeight(FontWeight.Bold); // 设置字体加粗
        }// 结束Button内容定义
          .type(ButtonType.Capsule) // 设置按钮类型为胶囊（Capsule)样式
        .margin({ top: 20 }) // 设置按钮上边距为20
        .backgroundColor('#0D9FF8') // 设置按钮的背景颜色为#0D9FF8（蓝色）
        .width('40%') // 设置按钮的宽度为父容器的40%
        .height('5%'); // 设置按钮的高度为父容器的5%
        .onClick(() => { // 为按钮绑定了一个点击事件处理函数
          console.info(`Succeeded in clicking the 'Next' button.`); // 点击时在控制台输出信息，表示成功点击了'Next'按钮
          router.pushUrl({ url: 'pages/Second' }) // 使用router的pushUrl方法尝试跳转到第二页
            .then(() => { // 跳转成功回调
              console.info('Succeeded in jumping to the second page.'); // 跳转成功，在控制台输出成功信息
            }) // then回调结束
            .catch((err: BusinessError) => { // 跳转失败回调
              console.error(`Failed to jump to the second page. Code is ${err.code}，message is ${err.message}`); // 捕获BusinessError类型的错误，并在控制台输出错误信息和代码
            }); // catch回调结束
        }); // 结束onClick事件处理
     } // 结束Column子组件
     .width('100%') // 设置Column宽度占满父容器Row
   } // 结束Row根布局容器
   .height('100%') // 设置Row高度占满整个屏幕
  } // 结束build方法定义
} // 结束Index组件结构体定义
```

### 第二个页面

> [!NOTE]
>
> Second.ets

```json5 {.line-numbers}
// 导入页面路由模块
import { router } from '@kit.ArkUI'; // 从ArkUI工具包中导入router模块，用于页面跳转
import { BusinessError } from '@kit.BasicServicesKit'; // 从基础服务工具包中导入BusinessError类，用于错误处理
@Entry // @Entry装饰器标记当前组件为入口组件
@Component // 使用@Component装饰器定义一个自定义组件
struct Second { // 定义名为Second的组件结构体
  @State message: string = 'Successfully redirected to the second page!!!(*^-^)' // 声明响应式数据，当message变化时自动更新UI
  build() {  // 组件UI构建入口方法
    Row(){ // 横向布局容器（根布局）
      Column(){ // 纵向布局容器（作为Row的直接子组件）
        Text(this.message) // 显示消息文本
          .fontSize(50) // 设置字体大小为30
          .fontWeight(FontWeight.Bold) //设置字体加粗
        Button(){ // 定义Button按钮组件
          Text('Back') // 显示按钮文本
            .fontSize(30) // 设置字体大小为30
            .fontWeight(FontWeight.Bold); // 设置字体加粗
        } // 结束Button内容定义
          .type(ButtonType.Capsule) // 设置按钮类型为胶囊（Capsule)样式
        .margin({ top: 20 }) // 设置按钮上边距为20
        .backgroundColor('#0D9FF8') // 设置按钮的背景颜色为#0D9FF8（蓝色）
        .width('40%') // 设置按钮的宽度为父容器的40%
        .height('5%'); // 设置按钮的高度为父容器的5%
        .onClick(() => { // 为按钮绑定了一个点击事件处理函数，点击按钮时返回到第一页
          console.info(`Succeeded in clicking the 'Back' button.`) // 点击时在控制台输出信息，表示成功点击了'Back'按钮
          try{ // 异常捕获开始
            router.back() // 执行路由返回操作（返回上一页）
            console.info('Succeeded in returning to the first page.') // 打印成功日志
          } // 异常捕获结束
          catch (err) { // 捕获异常开始，如果在返回过程中捕获到错误，尝试将错误转换为BusinessError类型
            let code = (err as BusinessError).code; // 获取错误的代码
            let message = (err as BusinessError).message; // 获取错误的消息
            console.error(`Failed to return to the first page.Code is ${code}，message is ${message}`) // 在控制台输出错误信息，包括错误代码和错误消息
          } // 结束try-catch块
        }) // 结束onClick事件处理
      } // 结束Column子组件
      .width('100%') // Column宽度占满父容器
    } // 结束Row根布局容器
    .height('100%') // Row高度占满屏幕
  } // 结束build方法定义
} // 结束Second组件结构体
```



## 三、结果展示

> [!NOTE]
>
> Index.ets
>

![image-gljpage1](page1.png)

> [!NOTE]
>
> Second.ets

![image-gljpage2](page2.png)

```typescript
// second.ets
import { router } from '@kit.ArkUI'; // 导入路由功能
import { BusinessError } from '@kit.BasicServicesKit'; // 导入错误处理功能

@Entry // 标记当前组件为入口组件
@Component // 标记当前结构体为组件
// 创建Second页面
struct Second {
  @State message: string = 'Hi there'; // 使用@State装饰器声明一个响应式变量message，初始值为'Hi there'

  // 构建UI组件
  build() {
    // 创建一个行布局
    Row() {
      // 创建一个列布局
      Column() {
        // 创建一个文本组件，显示message变量的值
        Text(this.message)
          .fontSize(50) // 设置文本字体大小为50
          .fontWeight(FontWeight.Bold) // 设置文本字体加粗
          .fontColor(Color.Pink); // 设置文本字体颜色为粉色

        // 创建一个按钮组件
        Button() {
          // 在按钮内部创建一个文本组件，显示'Back'
          Text('Back')
            .fontSize(30) // 设置按钮文本字体大小为30
            .fontWeight(FontWeight.Bold); // 设置按钮文本字体加粗
        }
        .type(ButtonType.Capsule) // 设置按钮类型为胶囊形状
        .margin({
          top: 20 // 设置按钮上边距为20
        })
        .backgroundColor('#FF7500') // 设置按钮背景颜色为橙色
        .width('40%') // 设置按钮宽度为父容器的40%
        .height('5%') // 设置按钮高度为父容器的5%
        // 设置按钮点击事件
        .onClick(() => {
          console.info('Succeeded in clicking the "Back" button.'); // 打印日志，表示按钮点击成功

          // 使用路由跳转回Index页面
          router.pushUrl({ url: 'pages/Index' }).then(() => {
            console.info('Succeeded in jumping to the Index page.'); // 打印日志，表示页面跳转成功
          }).catch((err: BusinessError) => {
            // 如果跳转失败，捕获错误并打印错误信息
            console.error(`Failed to jump to the Index page. Code is ${err.code}, message is ${err.message}`);
          });
        });
      }
      .width('100%'); // 设置列布局宽度为父容器的100%
    }
    .height('100%'); // 设置行布局高度为父容器的100%
  }
}
```typescript
// index.ets
import { router } from '@kit.ArkUI'; // 导入路由功能
import { BusinessError } from '@kit.BasicServicesKit'; // 导入错误处理功能

@Entry // 标记当前组件为入口组件
@Component // 标记当前结构体为组件
// 创建Index页面
struct Index {
  @State message: string = 'Hello World'; // 使用@State装饰器声明一个响应式变量message，初始值为'Hello World'

  // 构建UI组件
  build() {
    // 创建一个行布局
    Row() {
      // 创建一个列布局
      Column() {
        // 创建一个文本组件，显示message变量的值
        Text(this.message)
          .fontSize(50) // 设置文本字体大小为50
          .fontWeight(FontWeight.Bold); // 设置文本字体加粗

        // 创建一个按钮组件
        Button() {
          // 在按钮内部创建一个文本组件，显示'Next'
          Text('Next')
            .fontSize(30) // 设置按钮文本字体大小为30
            .fontWeight(FontWeight.Bold); // 设置按钮文本字体加粗
        }
        .type(ButtonType.Capsule) // 设置按钮类型为胶囊形状
        .margin({
          top: 20 // 设置按钮上边距为20
        })
        .backgroundColor('#41BA41') // 设置按钮背景颜色为绿色
        .width('40%') // 设置按钮宽度为父容器的40%
        .height('5%') // 设置按钮高度为父容器的5%
        // 设置按钮点击事件
        .onClick(() => {
          console.info('Succeeded in clicking the "Next" button.'); // 打印日志，表示按钮点击成功

          // 使用路由跳转到第二个页面
          router.pushUrl({ url: 'pages/second' }).then(() => {
            console.info('Succeeded in jumping to the second page.'); // 打印日志，表示页面跳转成功
          }).catch((err: BusinessError) => {
            // 如果跳转失败，捕获错误并打印错误信息
            console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`);
          });
        });
      }
      .width('100%'); // 设置列布局宽度为父容器的100%
    }
    .height('100%'); // 设置行布局高度为父容器的100%
  }
}
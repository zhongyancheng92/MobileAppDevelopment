# HarmonyOS应用开发

## 实验一、页面跳转
### Index页面:
```
// Index.ets
// 导入页面路由模块，用于页面跳转
import { router } from '@kit.ArkUI';
// 导入错误处理模块，用于处理页面跳转失败时的错误
import { BusinessError } from '@kit.BasicServicesKit';

// 定义一个名为Index的页面组件，并标记为入口页面
@Entry
@Component
struct Index {
  // 定义一个状态变量message，用于存储页面显示的文本内容
  @State message: string = 'Index页面'

  // 定义页面的构建方法，用于构建页面的UI结构
  build() {
    // 使用Row组件创建一个水平布局容器
    Row() {
      // 使用Column组件创建一个垂直布局容器
      Column() {
        // 使用Text组件显示页面的文本内容，内容为状态变量message的值
        Text(this.message)
          // 设置文本字体大小为50
          .fontSize(50)
          // 设置文本字体加粗
          .fontWeight(FontWeight.Bold)
        // 添加一个按钮组件，用于响应用户点击
        Button() {
          // 设置按钮的文本内容为'Next'
          Text('Next')
            // 设置按钮文本字体大小为30
            .fontSize(30)
            // 设置按钮文本字体加粗
            .fontWeight(FontWeight.Bold)
        }
        // 设置按钮的类型为胶囊形状
        .type(ButtonType.Capsule)
        // 设置按钮的外边距，顶部为20
        .margin({
          top: 20
        })
        // 设置按钮的背景颜色为'#0D9FFB'
        .backgroundColor('#0D9FFB')
        // 设置按钮的宽度为屏幕宽度的40%
        .width('40%')
        // 设置按钮的高度为屏幕高度的5%
        .height('5%')
        // 为按钮绑定点击事件
        .onClick(() => {
          // 在控制台打印点击按钮成功的信息
          console.info(`Succeeded in clicking the 'Next' button.`)
          // 调用router的pushUrl方法，跳转到第二页
          router.pushUrl({ url: 'pages/Second' }).then(() => {
            // 如果跳转成功，在控制台打印成功信息
            console.info('Succeeded in jumping to the second page.')
          }).catch((err: BusinessError) => {
            // 如果跳转失败，捕获错误并打印错误信息
            console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`)
          })
        })
      }
      // Column组件的结束括号
      .width('100%') // 设置Column组件的宽度为屏幕宽度的100%
    }
    // Row组件的结束括号
    .height('100%') // 设置Row组件的高度为屏幕高度的100%
  }
}
// Index组件的结束括号
```
### Second页面:
```
// Second.ets
// 定义一个名为 Second.ets 的文件，这是一个页面组件文件。
// 导入页面路由模块，用于页面跳转功能。
import { router } from '@kit.ArkUI';

// 导入 BusinessError 类，用于处理业务错误。
import { BusinessError } from '@kit.BasicServicesKit';

// 使用 @Entry 装饰器标记这是一个页面入口组件。
// 使用 @Component 装饰器标记这是一个组件。
@Entry
@Component
struct Second {
  // 定义一个状态变量 message，初始值为 'Hi there'，用于在页面中显示文本。
  @State message: string = 'Hi there'

  // 定义组件的构建方法，用于构建页面的布局。
  build() {
    // 创建一个 Row 容器，用于水平布局页面内容。
    Row() {
      // 创建一个 Column 容器，用于垂直布局页面内容。
      Column() {
        // 创建一个 Text 组件，用于显示文本内容。
        Text(this.message)
          // 设置文本字体大小为 50。
          .fontSize(50)
          // 设置文本字体加粗。
          .fontWeight(FontWeight.Bold)
        // 创建一个 Button 组件，用于定义一个按钮。
        Button() {
          // 在按钮中添加一个 Text 组件，用于显示按钮文本。
          Text('Back')
            // 设置按钮文本字体大小为 30。
            .fontSize(30)
            // 设置按钮文本字体加粗。
            .fontWeight(FontWeight.Bold)
        }
        // 设置按钮的类型为胶囊形状。
        .type(ButtonType.Capsule)
        // 设置按钮的外边距，顶部为 20。
        .margin({
          top: 20
        })
        // 设置按钮的背景颜色为 '#0D9FFB'。
        .backgroundColor('#0D9FFB')
        // 设置按钮的宽度为页面宽度的 40%。
        .width('40%')
        // 设置按钮的高度为页面高度的 5%。
        .height('5%')
        // 为按钮绑定 onClick 事件，点击按钮时触发。
        .onClick(() => {
          // 打印日志，表示点击了 'Back' 按钮。
          console.info(`Succeeded in clicking the 'Back' button.`)
          try {
            // 调用路由模块的 back 方法，返回到上一个页面。
            router.back()
            // 打印日志，表示成功返回到第一页。
            console.info('Succeeded in returning to the first page.')
          } catch (err) {
            // 捕获错误，将错误对象转换为 BusinessError 类型。
            let code = (err as BusinessError).code; 
            let message = (err as BusinessError).message; 
            // 打印错误日志，包含错误代码和错误信息。
            console.error(`Failed to return to the first page. Code is ${code}, message is ${message}`)
          }
        })
      } // Column 容器的结束括号
      // 设置 Column 容器的宽度为页面宽度的 100%。
      .width('100%')
    } // Row 容器的结束括号
    // 设置 Row 容器的高度为页面高度的 100%。
    .height('100%')
  } // build 方法的结束括号
} // Second 组件的结束括号
```

### 结果截图：

![1](C:\Users\yitong\Desktop\3225706085梁怡彤\1.png)

![2](C:\Users\yitong\Desktop\3225706085梁怡彤\2.png)


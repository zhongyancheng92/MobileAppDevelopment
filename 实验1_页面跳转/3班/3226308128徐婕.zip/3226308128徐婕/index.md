```  typescript {.line-numbers}
// 导入页面路由模块，用于页面跳转  
import { router } from '@kit.ArkUI';  
// 导入错误处理模块，用于捕获和处理错误  
import { BusinessError } from '@kit.BasicServicesKit';  
// @Entry 装饰器表示这个组件是应用的入口组件  
@Entry  
// @Component 装饰器表示这个结构体是一个自定义组件
@Component
struct Index {  
// @State 装饰器表示这个变量是组件的状态变量，当状态变化时，UI会自动更新  
@State message: string = 'Hello World';  
// build 方法是组件的UI构建方法，用于描述UI的结构  
  build() {  
    // Row 组件表示一个横向布局容器  
    Row() { // Row 的开始括号  
      // Column 组件表示一个纵向布局容器  
      Column() { // Column 的开始括号  
        // Text 组件用于显示文本内容  
        Text(this.message) // Text 的开始括号  
          .fontSize(50) // 设置字体大小为50，结束括号  
          .fontWeight(FontWeight.Bold) // 设置字体加粗，结束括号  
        // Button 组件用于创建一个按钮  
        Button() { // Button 的开始括号  
          // Text 组件用于显示按钮上的文本  
          Text('Next') // Text 的开始括号  
            .fontSize(30) // 设置字体大小为30，结束括号  
            .fontWeight(FontWeight.Bold) // 设置字体加粗，结束括号  
        } // Button 的结束括号  
        .type(ButtonType.Capsule) // 设置按钮类型为胶囊形状，结束括号  
        .margin({ // 设置按钮的外边距，开始括号  
          top: 20 // 设置按钮的上边距为20  
        }) // margin 的结束括号  
        .backgroundColor('#0D9FFB') // 设置按钮的背景颜色，结束括号  
        .width('40%') // 设置按钮的宽度为父容器的40%，结束括号  
        .height('5%') // 设置按钮的高度为父容器的5%，结束括号  
        // 为按钮绑定onClick事件，当用户点击按钮时触发  
        .onClick(() => { // onClick 的开始括号  
          // 打印日志，表示按钮点击成功  
          console.info('Succeeded in clicking the ‘Next’ button.');  
          // 使用router.pushUrl方法跳转到第二页  
          router.pushUrl({ url: 'pages/Hello' }) // pushUrl 的开始括号  
            .then(() => { // then 的开始括号  
              // 打印日志，表示页面跳转成功  
              console.info('Succeeded in jumping to the second page.');  
            }) // then 的结束括号  
            .catch((err: BusinessError) => { // catch 的开始括号  
              // 如果跳转失败，捕获错误并打印错误信息  
              console.error(`Failed to jump to the second page. Code is ${err.code},  message is ${err.message}`);  
            }); // catch 的结束括号  
        }) // onClick 的结束括号  
      } // Column 的结束括号  
      .width('100%') // 设置Column组件的宽度为父容器的100%，结束括号  
    } // Row 的结束括号  
    .height('100%') // 设置Row组件的高度为父容器的100%，结束括号  
  } // build 方法的结束括号  
} // Index 结构体的结束括号  
```
```  typescript {.line-numbers}
// 导入页面路由模块，用于页面跳转  
import { router } from '@kit.ArkUI';  
// 导入错误处理模块，用于捕获和处理异常  
import { BusinessError } from '@kit.BasicServicesKit';  
// @Entry 装饰器表示这是一个入口组件，即应用的根组件  
@Entry  
// @Component 装饰器表示这是一个自定义组件  
@Component  
struct Hello {  
  // @State 装饰器表示这是一个状态变量，当状态变化时，UI会自动更新  
  @State message: string = 'Hello World';  
  // build 函数用于定义组件的UI结构  
  build() {  
    // Row 组件表示一个横向布局容器  
    Row() {  
      // Column 组件表示一个纵向布局容器  
      Column() {  
        // Text 组件用于显示文本内容  
        Text(this.message)  
          .fontSize(50)  // 设置字体大小为50  
          .fontWeight(FontWeight.Bold)  // 设置字体加粗  
        // Button 组件用于创建一个按钮  
        Button() {  
          // 按钮内部的文本内容  
          Text('Back')  
            .fontSize(30)  // 设置字体大小为30  
            .fontWeight(FontWeight.Bold)  // 设置字体加粗  
        } // 结束Button内部Text组件的定义
        .type(ButtonType.Capsule)  // 设置按钮类型为胶囊形状  
        .margin({  
          top: 20  // 设置按钮的上边距为20  
        })  
        .backgroundColor('#0D9FFB')  // 设置按钮的背景颜色  
        .width('40%')  // 设置按钮宽度为父容器的40%  
        .height('5%')  // 设置按钮高度为父容器的5%  
        // 为按钮绑定点击事件  
        .onClick(() => {  
          // 打印日志，表示按钮点击成功  
          console.info('Succeeded in clicking the ‘Back’ button.');  
          try {
            // 调用路由的back方法，返回上一页
            router.back();
            // 打印日志，表示成功返回上一页
            console.info('Succeeded in returning to the first page.');
          } catch (err) {
            // 捕获异常并处理，开始异常处理逻辑
            let code = (err as BusinessError).code;  // 获取错误代码
            let message = (err as BusinessError).message;  // 获取错误信息
            // 打印错误日志
            console.error('Failed to return to the first page. Code is $(err.code), message is $(err.message)');
          } // 结束异常处理逻辑
        }) // 结束点击事件的处理逻辑的定义
      } // 结束Column布局的定义
      .width('100%')  // 设置Column组件的宽度为100%
    }// 结束Row布局的定义
    .height('100%')  // 设置Row组件的高度为100%
  }// 结束build函数的定义
}// 结束Hello组件的定义
```  
# <a href="#" style="display: block; text-align: center;">实验一：页面跳转</a>
## Step1：编写第一个页面
```TypeScript{.line-numbers}
// Index.ets 
//标注文件名，指明代码片段来自哪个文件

@Entry // 标记这个组件为应用的入口点
@Component // 标记这个对象为组件
struct Index {  // 定义一个名为 Index 的结构体

  @State message: string = 'Index页面' 
  // 定义一个状态变量 message，类型为 string，并初始化为 'Index页面'

  build() { // 组件的构建方法，用于描述组件的 UI 结构
    Row() { // 创建一个 Row 布局容器
      Column(){ // 在 Row 中创建一个 Column 布局容器
        Text(this.message) // 创建一个 Text 组件，显示 message 变量的内容
          .fontSize(50) // 设置 Text 组件的字体大小为 50
          .fontWeight(FontWeight.Bold) // 设置 Text 组件的字体为加粗
      } //与第16行前括号配对
      .width('100%') // 设置 Column 容器的宽度为 100%
    } //与第15行前括号配对
    .height('100%') // 设置 Row 容器的高度为 100%
  } //与第14行前括号配对
} //与第9行前括号配对

```

## Step2：给第一个页面添加静态按钮
```TypeScript{.line-numbers}
//Index.ets

@Entry
@Component
struct Index {
  @State message: string = 'Index页面'

  build() {
    Row() {
      Column(){
        Text(this.message)
          .fontSize(50)
          .fontWeight(FontWeight.Bold)
        //添加按钮，以响应用户点击
        Button() { // 创建一个 Button 组件
            Text('Next') 
            // 在按钮内创建一个 Text 组件，显示文本 'Next'
            .fontSize(30) // 设置 Text 组件的字体大小为 30
            .fontWeight(FontWeight.Bold) 
            // 设置 Text 组件的字体为加粗
        }
        .type(ButtonType.Capsule) 
        // 设置按钮的类型为 Capsule（胶囊形）
        .margin({ // 设置按钮的外边距
            top: 20 // 设置上边距为 20
        })
        .backgroundColor('#0D9FFB') 
        // 设置按钮的背景颜色为十六进制值 #0D9FFB（蓝色）
        .width('40%') // 设置按钮的宽度为 40%
        .height('5%') // 设置按钮的高度为 5%
      }
      .width('100%')
    }
    .height('100%')
  }
}
```
## Step3:创建第二页面以及添加静态按钮
```TypeScript{.line-numbers}
//Second.ets

@Entry
@Component
struct Second {
  @State message: string = 'Hi there'

  build() {
    Row() {
      Column(){
        Text(this.message)
          .fontSize(50)
          .fontWeight(FontWeight.Bold)
        //添加按钮，以响应用户点击
        Button(){
          Text('Back')
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }
        .type(ButtonType.Capsule)
        .margin({
          top: 20
        })
        .backgroundColor('#0D9FFB')
        .width('40%')
        .height('5%')
      }
      .width('100%')
    }
    .height('100%')
  }
}
```
## Step4:给第一个页面的静态按钮添加动态功能
```TypeScript{.line-numbers}
//Index.ets

//导入页面路由模块
import { router } from  '@kit.ArkUI';
import  { BusinessError } from  '@kit.BasicServicesKit'

@Entry
@Component
struct Index {
  @State message: string = 'Index页面'

  build() {
    Row() {
      Column(){
        Text(this.message)
          .fontSize(50)
          .fontWeight(FontWeight.Bold)
        //添加按钮，以响应用户点击
        Button() {
          Text('Next')
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }
        .type(ButtonType.Capsule)
        .margin({
          top: 20
        })
        .backgroundColor('#0D9FFB')
        .width('40%')
        .height('5%')
        //跳转按钮绑定onClick事件，点击时跳转到第二页
        .onClick(() => { //// 为按钮绑定点击事件处理函数
          console.info(`Succeeded in clicking the 'Next' Button.`)
          // 打印信息，表示按钮被成功点击
          //跳转到第二页
          router.pushUrl({ url: 'pages/Second' }).then(() =>{
            // 调用 router.pushUrl 方法，尝试跳转到 'pages/Second' 页面
            console.info('Succeeded in jumping to the second page.')
            // 打印信息，表示成功跳转到第二页

          }).catch((err: BusinessError) => {
            console.error(`Failed to jump to the second page. Code is ${err.code},message is ${err.message}`)
            // 捕获跳转过程中的错误，并打印错误信息
          })
        })
      }
      .width('100%')
    }
    .height('100%')
  }
}
```
## Step5:给第二个页面的静态按钮添加动态功能
```TypeScript{.line-numbers}
//Second.ets

//导入页面路由模块
import { router } from '@kit.ArkUI'
import { BusinessError } from '@kit.BasicServicesKit'

@Entry
@Component
struct Second {
  @State message: string = 'Hi there'

  build() {
    Row() {
      Column(){
        Text(this.message)
          .fontSize(50)
          .fontWeight(FontWeight.Bold)
        //添加按钮，以响应用户点击
        Button(){
          Text('Back')
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }
        .type(ButtonType.Capsule)
        .margin({
          top: 20
        })
        .backgroundColor('#0D9FFB')
        .width('40%')
        .height('5%')
        //返回按钮绑定onClick事件，点击按钮时返回到第一页
        .onClick(() => { // 为按钮绑定点击事件处理函数
          console.info(`Succeeded in clicking the 'Back' button.`)
          // 输出信息，表示用户成功点击了“Back”按钮
          try {
            //返回第一页
            router.back() 
            // 调用 router.back() 方法，尝试返回到上一页
            console.info('Succeeded in returning to the first page.') 
            // 输出信息，表示成功返回到上一页
          }catch (err) {
            let code = (err as BusinessError).code;
            // 从错误对象中提取错误码
            let message = (err as BusinessError).message;
            // 从错误对象中提取错误信息
            console.error(`Failed to return to the first page. Code is ${code},message is ${message}`)
            // 输出错误信息，包括错误码和错误消息
          }
        })
      }
      .width('100%')
    }
    .height('100%')
  }
}
```
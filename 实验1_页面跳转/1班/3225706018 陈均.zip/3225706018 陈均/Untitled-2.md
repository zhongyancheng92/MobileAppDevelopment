### 3225706018
### 陈均
~~~typescript {.line-numbers}

<title></title><style>
@font-face{
font-family:"Times New Roman";
}
@font-face{
font-family:"宋体";
}
@font-face{
font-family:"等线";
}
p.MsoNormal{
mso-style-name:正文;
mso-style-parent:"";
margin:0pt;
margin-bottom:.0001pt;
mso-pagination:none;
text-align:justify;
text-justify:inter-ideograph;
font-family:等线;
mso-bidi-font-family:'Times New Roman';
font-size:10.5000pt;
mso-font-kerning:1.0000pt;
}
span.msoIns{
mso-style-type:export-only;
mso-style-name:"";
text-decoration:underline;
text-underline:single;
color:blue;
}
span.msoDel{
mso-style-type:export-only;
mso-style-name:"";
text-decoration:line-through;
color:red;
}
@page{mso-page-border-surround-header:no;
 mso-page-border-surround-footer:no;}@page Section0{
}
div.Section0{page:Section0;}</style>

// 导入ArkUI框架中的路由模块，用于页面跳转。  
**import** { router } **from** '@kit.ArkUI'  
// 导入BusinessError类，用于处理业务错误。  
**import** { BusinessError } **from**  '@kit.BasicServicesKit'  

// 使用@Entry装饰器标记该组件为应用的入口组件。  
@Entry  
  // 使用@Component装饰器定义一个ArkUI组件。  
@Component  
**struct** Second {  
  // 使用@State装饰器定义一个响应式状态变量message，并初始化为'Hello!'。  
  @State message: string = 'Hello!'  

  // build函数定义了组件的UI结构。  
  build(){  
    // 使用Row组件创建一个水平排列的布局。  
    Row(){  
      // 使用Column组件创建一个垂直排列的布局。  
      Column(){  
        // 添加一个Text组件显示message变量的内容。  
        Text(**this**.message)  
          // 设置文本的字体大小为50。  
          .fontSize(50)  
            // 设置文本的字体权重为Bold。  
          .fontWeight(FontWeight.Bold)  
        // 添加一个按钮，用于响应用户的点击事件。  
        Button(){  
          // 在按钮内添加一个Text组件显示'Back'。  
          Text('Back')  
            // 设置按钮内文本的字体大小为30。  
            .fontSize(30)  
              // 设置按钮内文本的字体权重为Bold。  
            .fontWeight(FontWeight.Bold)  
        }//Button  
        // 设置按钮的类型为Capsule（胶囊型）。  
        .type(ButtonType.Capsule)  
        // 设置按钮的外边距，上边距为20。  
        .margin({  
          top: 20  
        })//.margin  
        // 设置按钮的背景颜色。  
        .backgroundColor('#0D9FFB')  
        // 设置按钮的宽度为父组件宽度的30%。  
        .width('30%')  
        // 设置按钮的高度为父组件高度的5%。  
        .height('5%')  
        // 为按钮添加点击事件监听器。  
        .onClick(() => {  
          console.info('Succeeded in clicking the ‘Back’ button.')  
          **try**{  
            // 使用router.back方法返回第一页。  
            router.back()  
            console.info('Succeeded in returning to first page.')  
          }**catch**(err){  
            // 如果返回失败，从错误对象中提取code和message属性。  
            **let** code = (err **as** BusinessError).code;  
            **let** message = (err **as** BusinessError).message;  
            // 打印错误信息。  
            console.error(`Failed to return to the first page. Code is ${code}, message is ${message}`);  
          }//catch  
        })//.onClick  
      }//Column  
      // 设置Column组件的宽度为100%。  
      .width('100%')  
    }//Row  
    // 设置Row组件的高度为100%。  
    .height('100%')  
  }//build  
}//Second

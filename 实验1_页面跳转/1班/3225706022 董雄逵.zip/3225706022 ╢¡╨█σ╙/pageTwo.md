### 3225706022 董雄逵
```typescript{.line-numbers}

// 导入ArkUI框架中的router模块，用于页面跳转
import { router } from '@kit.ArkUI';
// 导入BasicServicesKit框架中的BusinessError类，用于处理业务错误
import {BusinessError} from  '@kit.BasicServicesKit';

// 使用@Entry装饰器声明这是一个页面的入口组件
@Entry
// 使用@Component装饰器声明这是一个组件
@Component
struct Second {
  // 使用@State装饰器声明一个响应式状态变量message，初始值为'Second页面'
  @State message: string = 'Second页面';

  // build方法用于构建组件的UI结构
  build() {
    // 使用Row组件创建一个水平布局容器
    Row(){
      // 使用Column组件创建一个垂直布局容器
      Column(){
        // 使用Text组件显示message状态变量的值，并设置字体大小和字体加粗
        Text(this.message)
          .fontSize(50)
          .fontWeight(FontWeight.Bold)
        // 使用Button组件创建一个按钮，内部包含Text组件显示'back'文本
        Button(){
          Text('back')
            .fontSize(50)
            .fontWeight(FontWeight.Bold)
        }
        // 设置按钮的类型为胶囊型，顶部外边距为20，背景颜色，宽度和高度
        .type(ButtonType.Capsule)
        .margin({
          top:20
        })
        .backgroundColor('#0D9FFB')
        .width('40%')
        .height('10%')
        // 为按钮添加点击事件处理函数
        .onClick(()=>{
          // 打印点击按钮的信息
          console.info('Succeeded in clicking the back button')
          try{
            // 调用router.back()方法尝试返回上一个页面
            router.back()
            // 如果返回成功，打印成功信息
            console.info('Succeeded in jumping to the Index page. ')
          }catch(err) {
            // 如果捕获到错误，尝试将错误转换为BusinessError类型
            let code = (err as BusinessError).code; // 获取错误码
            let message = (err as BusinessError).message; // 获取错误信息
            // 打印错误信息，注意这里的字符串模板使用错误，应该使用${}而不是${err.code}和${err.message}
            // 正确写法应为：`Code is ${code}, message is ${message}`
            console.error('Failed to return to the Index page. Code is ${code}, message is ${message}')
          }
        })
      }
      // 设置Column容器的宽度为100%
      .width('100%')
    }
    // 设置Row容器的高度为100%
    .height('100%')
  }
}


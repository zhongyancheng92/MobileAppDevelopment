# 实验一  页面跳转

## 1. 第一个页面

```typescript
// 导入页面路由模块，用于页面跳转
import { router } from '@kit.ArkUI';
// 导入业务错误类，用于处理路由跳转失败时的错误
import { BusinessError } from '@kit.BasicServicesKit';

// 使用 @Entry 装饰器定义一个页面组件，表示这是一个入口页面
@Entry
// 使用 @Component 装饰器定义一个页面组件，表示这是一个可复用的组件
@Component
struct Index { // 定义一个名为 Index 的页面组件
  // 定义一个状态变量 message，用于显示页面的文本内容
  @State message: string = 'Hello World'; // 初始化状态变量，值为 'Hello World'

  // 定义页面的构建逻辑
  build() { // 定义页面的构建方法
    // 使用 Row 布局组件，将页面内容水平排列
    Row() { // 开始 Row 布局组件的定义
      // 使用 Column 布局组件，将内容垂直排列
      Column() { // 开始 Column 布局组件的定义
        // 添加一个 Text 组件，用于显示文本内容
        Text(this.message) // 创建一个 Text 组件，内容为状态变量 message 的值
          // 设置文本字体大小为 50
          .fontSize(50) // 设置字体大小为 50
          // 设置文本字体加粗
          .fontWeight(FontWeight.Bold); // 设置字体为加粗

        // 添加一个按钮组件，用于响应用户点击
        Button() { // 开始 Button 组件的定义
          // 按钮内的文本内容
          Text("Next") // 创建一个 Text 组件，内容为 "Next"
            // 设置按钮内文本字体大小为 30
            .fontSize(30) // 设置字体大小为 30
            // 设置按钮内文本字体加粗
            .fontWeight(FontWeight.Bold); // 设置字体为加粗
        } // 结束按钮内的 Text 组件定义
        // 设置按钮的类型为胶囊形状
        .type(ButtonType.Capsule) // 设置按钮的类型为胶囊形状
        // 设置按钮的外边距，顶部为 20
        .margin({
          top: 20 // 设置按钮的顶部外边距为 20
        })
        // 设置按钮的背景颜色为蓝色
        .backgroundColor('#0D9FFB') // 设置按钮的背景颜色为蓝色
        // 设置按钮的宽度为页面宽度的 40%
        .width('40%') // 设置按钮的宽度为页面宽度的 40%
        // 设置按钮的高度为页面高度的 5%
        .height('5%') // 设置按钮的高度为页面高度的 5%
        // 设置按钮的点击事件
        .onClick(() => { // 定义按钮的点击事件
          // 在控制台打印点击按钮成功的日志
          console.info('Succeeded in clicking the "Next" button.'); // 打印点击成功的日志
          // 调用路由模块的 pushUrl 方法，跳转到第二页
          router.pushUrl({ url: 'pages/Second' }) // 调用路由模块的 pushUrl 方法
            .then(() => { // 定义跳转成功的回调
              // 如果跳转成功，在控制台打印成功日志
              console.info('Succeeded in jumping to the second page.'); // 打印跳转成功的日志
            })
            .catch((err: BusinessError) => { // 定义跳转失败的回调
              // 如果跳转失败，捕获错误并在控制台打印错误信息
              console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`); // 打印错误信息
            });
        }); // 结束按钮的点击事件定义
      } // 结束 Column 布局组件的定义
      // 设置 Column 组件的宽度为 100%，即占满整个页面宽度
      .width('100%'); // 设置 Column 的宽度为 100%
    } // 结束 Row 布局组件的定义
    // 设置 Row 组件的高度为 100%，即占满整个页面高度
    .height('100%'); // 设置 Row 的高度为 100%
  } // 结束页面的构建方法定义
} // 结束页面组件 Index 的定义
```
---
## 2. 第二个页面

```typescript
// 导入页面路由模块，用于页面跳转
import { router } from '@kit.ArkUI'; // 导入路由模块，用于页面跳转功能
// 导入业务错误类，用于处理路由跳转失败时的错误
import { BusinessError } from '@kit.BasicServicesKit'; // 导入业务错误类，用于捕获和处理错误

// 使用 @Entry 和 @Component 装饰器定义一个页面组件
@Entry // @Entry 装饰器，表示这是一个页面的入口点
@Component // @Component 装饰器，表示这是一个可复用的组件
struct Second { // 定义一个名为 Second 的页面组件
  // 定义一个状态变量 message，用于显示页面的文本内容
  @State message: string = '返回上一页'; // 使用 @State 装饰器定义状态变量 message，初始值为 '返回上一页'

  // 定义页面的构建逻辑
  build() { // 定义页面的构建方法，用于构建页面的 UI 结构
    // 使用 Row 布局组件，将页面内容水平排列
    Row() { // 创建一个 Row 布局组件，用于水平排列子组件
      // 使用 Column 布局组件，将内容垂直排列
      Column() { // 创建一个 Column 布局组件，用于垂直排列子组件
        // 添加一个 Text 组件，用于显示文本内容
        Text(this.message) // 创建一个 Text 组件，内容为状态变量 message 的值
          // 设置文本字体大小为 50
          .fontSize(50) // 调用 Text 组件的 fontSize 方法，设置字体大小为 50
          // 设置文本字体加粗
          .fontWeight(FontWeight.Bold); // 调用 Text 组件的 fontWeight 方法，设置字体为加粗

        // 添加一个按钮组件，用于响应用户点击
        Button() { // 创建一个 Button 组件，用于响应用户的点击事件
          // 按钮内的文本内容
          Text('Back') // 在 Button 内部创建一个 Text 组件，内容为 'Back'
            // 设置按钮内文本字体大小为 30
            .fontSize(30) // 调用 Text 组件的 fontSize 方法，设置字体大小为 30
            // 设置按钮内文本字体加粗
            .fontWeight(FontWeight.Bold); // 调用 Text 组件的 fontWeight 方法，设置字体为加粗
        } // 结束 Button 内部的 Text 组件定义
        // 设置按钮的类型为胶囊形状
        .type(ButtonType.Capsule) // 调用 Button 组件的 type 方法，设置按钮类型为胶囊形状
        // 设置按钮的外边距，顶部为 20
        .margin({ // 调用 Button 组件的 margin 方法，设置外边距
          top: 20 // 设置按钮的顶部外边距为 20
        })
        // 设置按钮的背景颜色为蓝色
        .backgroundColor('#0D9FFB') // 调用 Button 组件的 backgroundColor 方法，设置背景颜色为蓝色
        // 设置按钮的宽度为页面宽度的 40%
        .width('40%') // 调用 Button 组件的 width 方法，设置按钮宽度为页面宽度的 40%
        // 设置按钮的高度为页面高度的 5%
        .height('5%') // 调用 Button 组件的 height 方法，设置按钮高度为页面高度的 5%
        // 设置按钮的点击事件
        .onClick(() => { // 调用 Button 组件的 onClick 方法，定义按钮的点击事件
          // 在控制台打印点击按钮成功的日志
          console.info('Succeeded in clicking the "Back" button.'); // 打印按钮点击成功的日志
          try {
            // 调用路由模块的 back 方法，返回上一页
            router.back(); // 调用路由模块的 back 方法，返回上一页
            // 如果返回成功，在控制台打印成功日志
            console.info('Succeeded in returning to the first page.'); // 打印返回成功的日志
          } catch (err) { // 使用 try...catch 捕获可能出现的错误
            // 如果返回失败，捕获错误并提取错误信息
            let code = (err as BusinessError).code; // 将 err 断言为 BusinessError 类型，并提取错误代码
            let message = (err as BusinessError).message; // 提取错误消息
            // 在控制台打印错误信息
            console.error(`Failed to return to the first page. Code is ${code}, message is ${message}`); // 打印错误信息
          }
        }); // 结束按钮的点击事件定义
      } // 结束 Column 布局组件的定义
      // 设置 Column 组件的宽度为 100%，即占满整个页面宽度
      .width('100%'); // 调用 Column 组件的 width 方法，设置宽度为 100%
    } // 结束 Row 布局组件的定义
    // 设置 Row 组件的高度为 100%，即占满整个页面高度
    .height('100%'); // 调用 Row 组件的 height 方法，设置高度为 100%
  } // 结束页面的构建方法定义
} // 结束页面组件 Second 的定义
```
---
## 3. 截图

### (1) 第一页
![第一页](1.png)

### (2) 第二页
![第二页](2.png)

### (3) 日志
![日志](3.png)
# 实验一实验报告
22空数1班翁鑫洲
## Index页面代码
```typescript
import { router } from '@kit.ArkUI'; // 从 ArkUI 组件库中导入 router，用于页面跳转
import { BusinessError } from '@kit.BasicServicesKit'; // 从 BasicServicesKit 导入 BusinessError，用于处理可能出现的错误

@Entry // 这个 @Entry 装饰器表示这个组件是应用程序的入口（第一个显示的页面）
@Component // 这个 @Component 装饰器表示这个类是一个 UI 组件
struct Index { // 定义一个名为 Index 的页面组件
  @State message: string = 'Index页面'; // 定义一个状态变量 message，初始值是 'Index页面'，用于显示当前页面的标题

  build() { // 组件的构建方法，相当于这个页面的“布局结构”
    Row() { // 使用 Row 组件创建一个横向排列的布局，相当于 HTML 里的 <div style="display: flex; flex-direction: row;">
      Column() { // 在 Row 里面放一个 Column 组件，创建一个竖向排列的布局，相当于一列
        Text(this.message) // 在页面上显示文本内容，默认是 'Index页面'
          .fontSize(50) // 设置文本的字体大小为 50，文字比较大
          .fontWeight(FontWeight.Bold); // 让文字加粗，看起来更突出

        Button() { // 创建一个按钮
          Text('Next') // 按钮上的文字是 'Next'，表示跳转到下一个页面
            .fontSize(50) // 设置按钮上的文字大小为 50，保持和标题大小一致
            .fontWeight(FontWeight.Bold); // 让按钮文字加粗
        }
        .type(ButtonType.Capsule) // 设置按钮样式为“胶囊形”按钮，圆角风格
        .margin({ top: 30 }) // 设置按钮的上边距，往下移动 30 像素，避免紧贴上面的文本
        .backgroundColor('#BD9FFB') // 设置按钮的背景颜色，使用淡紫色（十六进制颜色码）
        .width('40%') // 让按钮的宽度占父容器的 40%
        .height('15%'); // 让按钮的高度占父容器的 15%

        // 绑定点击事件，当用户点击按钮时执行下面的代码
      }
      .onClick(() => { 
        console.info('Succeeded in clicking the Next button'); // 在控制台输出日志，提示用户成功点击了 Next 按钮
        
        // 调用 router 进行页面跳转，跳转到 Second 页面
        router.pushUrl({ url: 'pages/Second' })
          .then(() => { // 如果跳转成功
            console.info('Succeeded in jumping to the second page'); // 在控制台输出日志，提示用户成功跳转
          })
          .catch((err: BusinessError) => { // 如果跳转失败，进入 catch 处理错误
            console.error(`Failed to jump to the second page. Code: ${err.code}, Message: ${err.message}`);
            // 在控制台输出错误信息，包含错误代码和具体的错误描述，方便排查问题
          });
      });
    }
    .justifyContent(FlexAlign.Center) // 让 Row 组件的子元素在主轴（水平）方向居中显示
    .width('100%') // 让 Row 组件占满整个屏幕的宽度
    .height('100%'); // 让 Row 组件占满整个屏幕的高度
  }
}

```
## Second页面代码
```typescript
import { router } from '@kit.ArkUI'; // 从 ArkUI 组件库中导入 router，用于页面跳转
import { BusinessError } from '@kit.BasicServicesKit'; // 从 BasicServicesKit 导入 BusinessError，用于处理可能出现的错误

@Entry // 这个装饰器（@Entry）表示这是应用的入口页面
@Component // 这个装饰器（@Component）表示这是一个组件
struct Second { // 定义一个名为 Second 的页面组件
  @State message: string = 'Second页面'; // 定义一个状态变量 message，初始值是 'Second页面'，用于显示当前页面的标题

  build() { // 组件的构建方法，类似于页面的“布局结构”
    Row() { // 使用 Row 组件创建一个水平布局，相当于一行元素
      Column() { // 在 Row 里面使用 Column 组件，创建一个垂直方向的布局，相当于一列元素
        Text(this.message) // 在页面上显示文本内容，默认是 'Second页面'
          .fontSize(50) // 设置文本的字体大小为 50
          .fontWeight(FontWeight.Bold); // 设置字体加粗，让它更醒目

        Button() { // 创建一个按钮
          Text('Back') // 按钮上的文字是 'Back'，表示返回上一页
            .fontSize(40) // 设置按钮上的文字大小为 40
            .fontWeight(FontWeight.Bold); // 让按钮文字加粗
        }
        .type(ButtonType.Capsule) // 设置按钮的样式为“胶囊形”按钮，圆角风格
        .margin({ top: 30 }) // 设置按钮的上边距，往下移动 30 像素，让它不贴着上面的文本
        .backgroundColor('#0D9FFB') // 设置按钮的背景颜色，使用蓝色（十六进制颜色码）
        .width('40%') // 让按钮的宽度占据父容器的 40%
        .height('20%') // 让按钮的高度占据父容器的 20%
        
        // 绑定按钮的点击事件
        .onClick(() => { 
          console.info('Succeeded in clicking the Back button'); // 在控制台输出一条日志，表示“成功点击了 Back 按钮”
          try {
            router.back(); // 使用 router 进行页面跳转，返回上一页
            console.info('Succeeded in returning to the first page'); // 在控制台输出一条日志，表示“成功返回到上一页”
          } catch (err) { // 如果返回操作失败，进入 catch 处理错误
            const error = err as BusinessError; // 把错误转换成 BusinessError 类型，以便获取具体的错误信息
            console.error(`Failed to return to the first page. code is ${error.code}, message is ${error.message}`);
            // 在控制台输出一条错误信息，包含错误代码和错误描述，方便排查问题
          }
        });
      }
      .width('100%'); // 让 Column 组件占满整个宽度
    }
    .height('100%'); // 让 Row 组件占满整个高度
  }
}

```
## 页面展示
！[index页面](image01.png)

>点击next按钮跳转至Second页面

！[Second页面][def]

>点击Back按键跳转回Index页面

[def]: image02.png
### 3225706016

### 刘国华

```stypesvript
// 导入ArkUI路由模块，用于实现页面导航功能
import { router } from '@kit.ArkUI';
// 导入基础业务错误模块，用于处理系统级错误
import { BusinessError } from '@kit.BasicServicesKit';

// @Entry装饰器声明为页面入口组件（应用启动的第一个页面）
@Entry
// @Component装饰器声明自定义组件（组件化开发基础单元）
@Component
struct second {
  // @State装饰器声明响应式数据（数据变化自动触发UI更新）
  // 定义页面核心文本内容，初始值为'Second页面'
  @State message: string = 'Second页面';

  // build方法为组件UI描述入口（必须实现的生命周期方法）
  build() {
    // Row容器组件：水平布局容器（子元素横向排列）
    Row() {
      // Column容器组件：垂直布局容器（子元素纵向排列）
      Column() {
        // 文本组件：展示页面核心内容
        Text(this.message)
          .fontSize(50)          // 设置字号为50vp（虚拟像素单位）
          .fontWeight(FontWeight.Bold) // 设置字重为粗体

        // 按钮组件：实现返回功能
        Button() {
          // 按钮内部文本
          Text('返回')
            .fontSize(30)        // 按钮文本字号
            .fontWeight(FontWeight.Bold) // 按钮文本加粗
        }
        // 设置按钮样式为胶囊形状（两端半圆形）
        .type(ButtonType.Capsule)
        // 设置上边距为20vp（与上方元素间距）
        .margin({ top: 20 })
        // 设置按钮背景色（ARGB格式，#ff0df3fb表示浅粉色）
        .backgroundColor('#ff0df3fb')
        // 设置按钮宽度为父容器的40%（响应式布局）
        .width('40%')
        // 设置按钮高度为父容器的5%（根据屏幕高度自适应）
        .height('5%')

        // 绑定按钮点击事件（用户点击时触发）
        .onClick(() => {
          // 打印调试信息到控制台（级别为info）
          console.info("Succeeded in clicking the 'BACK' button.")

          // 使用try-catch进行异常捕获（保障程序健壮性）
          try {
            // 调用路由返回方法（返回上一个页面）
            router.back()
            // 返回成功日志（用于调试追踪）
            console.info("Succeeded in returning to the first page.")
          } catch (err) {
            // 将错误对象转型为业务错误类型（类型断言）
            let code = (err as BusinessError).code;
            let message = (err as BusinessError).message;
            // 打印错误详情到控制台（级别为error）
            // 使用模板字符串拼接错误信息（ES6语法特性）
            console.error(`Failed to return to the first page. Code is ${code}, message is ${message}`)
          }
        })
      }
      // 设置列容器宽度占满父容器（100%宽度）
      .width('100%')
    }
    // 设置行容器高度占满父容器（100%高度）
    .height('100%')

  }
}
```

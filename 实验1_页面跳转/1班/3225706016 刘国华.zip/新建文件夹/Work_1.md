### 3225706016

### 刘国华

```stypesvript
import {router} from '@kit.ArkUI';        // 导入页面路由管理模块
import { BusinessError } from '@kit.BasicServicesKit';  // 导入业务错误处理模块

@Entry  // 标记为应用入口组件
@Component  // 声明自定义组件
struct Index {
  @State message: string = 'Index页面';  // 响应式状态变量，驱动UI更新

  build() {  // UI构建入口
    Row(){    // 横向布局容器
      Column(){  // 纵向布局容器
        // 标题文本组件
        Text(this.message)
          .fontSize(50)                 // 设置50px字体
          .fontWeight(FontWeight.Bold)   // 设置粗体样式

        // 跳转按钮组件
        Button(){
          Text('跳转')                   // 按钮文字
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }
        .type(ButtonType.Capsule)       // 胶囊形状按钮
        .margin({ top:20 })             // 顶部间距20px
        .backgroundColor('#0D9FFB')    // 按钮背景色
        .width('40%')                   // 宽度占父容器40%
        .height('5%')                   // 高度占父容器5%

        // 按钮点击事件
        .onClick(() =>{
          // 打印点击日志
          console.info("Succeeded in clicking the 'NEXT' button.")

          // 执行页面跳转
          router.pushUrl({ url: 'pages/second'})  // 跳转到second页面
            .then(()=>{  // 跳转成功回调
              console.info("Succeeded in jumping to the second page.")
            })
            .catch((err: BusinessError) =>{  // 错误捕获
              // 打印错误详细信息
              console.error(`Failed to jumping to the second page. Code is ${err.code},message is ${err.message}`)
            })
        })
      }
      .width('100%')  // 列容器占满父宽度
    }
    .height('100%')   // 行容器占满父高度

  }
}
```

### 3225706021
### 王聪
~~~typescript {.line-numers}

// 导入页面路由模块，用于页面导航和跳转  
import { router } from '@kit.ArkUI';  
// 导入业务错误处理模块，用于捕获和处理可能发生的错误  
import { BusinessError } from '@kit.BasicServicesKit';  

// 使用 @Entry 和 @Component 装饰器定义一个页面组件，名为 Index@Entry  
@Component  
struct Index {  
  // 定义一个状态变量 message，用于存储页面上显示的文本内容  
  @State message: string = 'wang cong';  

  // 定义组件的构建方法，用于渲染页面的 UI 结构  
  build() {  
    Row() { // 创建一个水平布局容器，用于包裹整个页面的内容  
      Column() { // 创建一个垂直布局容器，用于垂直排列子组件  
        Text(this.message) // 创建一个文本组件，显示状态变量 message 的内容  
          .fontSize(50) // 设置文本的字体大小为 50          .fontWeight(FontWeight.Bold); // 设置文本的字体为加粗  

        Button() { // 创建一个按钮组件  
          Text('Back') // 设置按钮上的文本内容为 "Back"            .fontSize(30) // 设置按钮文本的字体大小为 30            .fontWeight(FontWeight.Bold); // 设置按钮文本的字体为加粗  
        }  
        .type(ButtonType.Capsule) // 设置按钮的形状为胶囊型  
        .margin({ top: 20 }) // 设置按钮的上边距为 20        .backgroundColor('#8D9FFB') // 设置按钮的背景颜色为 '#8D9FFB'        .width('40%') // 设置按钮的宽度为父容器宽度的 40%        .height('5%') // 设置按钮的高度为父容器高度的 5%        // 为按钮绑定 onClick 事件，点击时执行返回操作  
        .onClick(() => {  
          console.info('Succeeded in clicking the \'Back\' button.'); // 打印点击成功的日志  
          try {  
            // 调用路由模块的 back 方法，返回到上一个页面  
            router.back();  
            console.info('Succeeded in returning to the first page.'); // 打印返回成功的日志  
          } catch (err) {  
            // 捕获返回过程中可能发生的错误  
            let code = (err as BusinessError).code; // 获取错误的代码  
            let message = (err as BusinessError).message; // 获取错误的消息  
            // 打印错误信息  
            console.error(`Failed to return to the first page. Code is ${code}, message is ${message}`);  
          }  
        });  
      }  
      .width('100%'); // 设置垂直布局容器的宽度为父容器宽度的 100%    }  
    .height('100%'); // 设置水平布局容器的高度为父容器高度的 100%  }  

}

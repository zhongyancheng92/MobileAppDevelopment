// Index.ets
// 导入页面路由模块
import { router } from '@kit.ArkUI'; // 导入ArkUI框架中的路由模块
import { BusinessError } from '@kit.BasicServicesKit'; // 导入基础服务模块中的错误处理类

@Entry // 标记当前组件为应用的入口组件
@Component // 标记当前结构体为一个组件
struct Index { // 定义名为Index的结构体组件
  @State message: string = 'Hello World' // 使用@State装饰器定义一个变量message，并初始化为'Hello World'

  build() { // 定义build方法，用于描述UI结构
    Row() { // 创建一个行布局容器
      Column() { // 创建一个列布局容器
        Text(this.message) // 创建一个文本组件，显示this.message的内容
          .fontSize(50) // 设置文本字体大小为50
          .fontWeight(FontWeight.Bold) // 设置文本字体加粗

        // 添加按钮，以响应用户点击
        Button() { // 创建一个按钮组件
          Text('Next') // 在按钮内部创建一个文本组件，显示'Next'
            .fontSize(50) // 设置按钮文本字体大小为50
            .fontWeight(FontWeight.Bold) // 设置按钮文本字体加粗
        }
        .type(ButtonType.Capsule) // 设置按钮类型为胶囊形状
        .margin({ // 设置按钮的外边距
          top: 20 // 设置上边距为20
        })
        .backgroundColor('#0D9FFB') // 设置按钮背景颜色为#0D9FFB
        .width('40%') // 设置按钮宽度为父容器的40%
        .height('10%') // 设置按钮高度为父容器的10%

        // 跳转按钮绑定onClick事件，点击时跳转到第二页
        .onClick(() => { // 为按钮绑定点击事件
          console.info(`Succeeded in clicking the 'Next' button.`) // 打印日志，表示按钮点击成功
          // 跳转到第二页
          router.pushUrl({ url: 'pages/Second' }).then(() => { // 调用pushUrl方法，跳转到'pages/Second'页面
            console.info('Succeeded in jumping to the second page.') // 打印日志，表示跳转成功
          }).catch((err: BusinessError) => { // 捕获跳转过程中可能出现的错误
            console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`) // 打印错误日志，包含错误代码和错误信息
          })
        })

      }
      .width('100%') // 设置列布局容器的宽度为100%
    }
    .height('100%') // 设置行布局容器的高度为100%
  }
}
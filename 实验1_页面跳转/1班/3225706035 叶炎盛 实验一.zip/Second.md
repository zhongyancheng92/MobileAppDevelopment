// Second.ets
// 导入页面路由模块
import { router } from '@kit.ArkUI'; // 导入ArkUI框架中的路由模块
import { BusinessError } from '@kit.BasicServicesKit'; // 导入基础服务模块中的错误处理类

@Entry // 标记当前组件为应用的入口组件
@Component // 标记当前结构体为一个组件
struct Second { // 定义名为Second的结构体组件
  @State message: string = 'This is second' // 使用@State装饰器定义一个变量message，并初始化为'This is second'

  build() { // 定义build方法，用于描述UI结构
    Row() { // 创建一个行布局容器
      Column() { // 创建一个列布局容器
        Text(this.message) // 创建一个文本组件，显示this.message的内容
          .fontSize(50) // 设置文本字体大小为50
          .fontWeight(FontWeight.Bold) // 设置文本字体加粗

        Button() { // 创建一个按钮组件
          Text('Back') // 在按钮内部创建一个文本组件，显示'Back'
            .fontSize(50) // 设置按钮文本字体大小为30
            .fontWeight(FontWeight.Bold) // 设置按钮文本字体加粗
        }
        .type(ButtonType.Capsule) // 设置按钮类型为胶囊形状
        .margin({ // 设置按钮的外边距
          top: 20 // 设置上边距为20
        })
        .backgroundColor('#0D9FFB') // 设置按钮背景颜色为#0D9FFB
        .width('40%') // 设置按钮宽度为父容器的40%
        .height('10%') // 设置按钮高度为父容器的5%

        // 返回按钮绑定onClick事件，点击按钮时返回到第一页
        .onClick(() => { // 为按钮绑定点击事件
          console.info(`Succeeded in clicking the 'Back' button.`) // 打印日志，表示按钮点击成功
          try { // 尝试执行以下代码
            // 返回第一页
            router.back() // 调用back方法，返回上一页
            console.info('Succeeded in returning to the first page.') // 打印日志，表示返回成功
          } catch (err) { // 捕获返回过程中可能出现的错误
            let code = (err as BusinessError).code; // 将错误对象转换为BusinessError类型，并获取错误代码
            let message = (err as BusinessError).message; // 将错误对象转换为BusinessError类型，并获取错误信息
            console.error(`Failed to return to the first page. Code is ${code}, message is ${message}`) // 打印错误日志，包含错误代码和错误信息
          }
        })

      }
      .width('100%') // 设置列布局容器的宽度为100%
    }
    .height('100%') // 设置行布局容器的高度为100%
  }
}
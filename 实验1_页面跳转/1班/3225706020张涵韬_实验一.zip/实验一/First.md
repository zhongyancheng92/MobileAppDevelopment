## 3225706020张涵韬

## First_Page

```typescript
// 导入ArkUI路由模块和基础服务错误类型
import { router } from '@kit.ArkUI';  
import { BusinessError } from '@kit.BasicServicesKit';

// @Entry装饰器标记为入口组件（整个应用的根节点）
@Entry
// @Component声明自定义组件（组件作用域开始）
@Component
struct First {  // 结构体声明开始
  // @State装饰器管理组件内部状态（状态变量message的作用域）
  @State message: string = 'Index页面';  

  // build方法定义UI布局（方法体括号开始）
  build() {
    // Row容器组件（参数括号定义组件属性）
    Row() {  // Row组件作用域开始
      // Column子容器（垂直布局）
      Column() {  // Column组件作用域开始
        // 文本组件
        Text(this.message)  // Text组件开始
          .fontSize(50)     // 链式调用设置字号
          .fontWeight(FontWeight.Bold)  // 设置字体加粗  

        // 按钮组件（开始定义）
        Button() {  // Button组件作用域开始
          Text('Next')  // 按钮文本
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }  // Button组件作用域结束
        .type(ButtonType.Capsule)  // 胶囊样式  
        .margin({  // 外边距设置（对象参数括号）
          top: 20 
        })
        .backgroundColor('#OD9FFB')  // 背景色（注意颜色值拼写应为#0D9FFB）
        .width('40%')    // 宽度比例
        .height('5%')    // 高度比例

        // 点击事件处理（箭头函数括号开始）
        .onClick(() => {  // 事件回调作用域开始
          console.info('Succeeded in clicking to the Next button.');

          // 路由跳转（参数对象括号）
          router.pushUrl({ url: 'pages/second' })
            .then(() => {  // Promise成功回调
              console.info('Succeeded in jumping to the second page.')
            })
            .catch((err: BusinessError) => {  // 异常处理开始  
              // 建议使用模板字符串：`Error ${code}`
              console.error('Failed to jump to the second page.Code is ${err.code},message is ${err.massage}')
            })  // catch代码块结束
        })  // onClick回调结束
      }  // Column组件结束
      .width('100%')  // 列宽设置
    }  // Row组件结束
    .height('100%')   // 行高设置

  }  // build方法结束
}  // struct结构体结束
```

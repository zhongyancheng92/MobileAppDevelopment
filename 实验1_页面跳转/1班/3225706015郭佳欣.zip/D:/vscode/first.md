#Index.ets
```typescript {.line-numbers}
// 从 '@kit.ArkUI' 库中导入 router 对象，用于实现页面路由跳转功能
import { router } from '@kit.ArkUI';
// 从 '@kit.BasicServicesKit' 库中导入 BusinessError 类，用于处理业务相关的错误
import { BusinessError } from '@kit.BasicServicesKit';
// 标记该组件为应用的入口组件，程序启动时会首先加载此组件
@Entry
// 声明这是一个组件，用于构建界面元素
@Component
// 定义名为 Index 的组件结构体
struct Index {
  // 使用 @State 装饰器声明一个响应式状态变量 message，初始值为 'Hello World'，当该值改变时，相关 UI 会自动更新
  @State message: string = 'Hello World';
  // 组件的构建方法，用于定义组件的 UI 结构和布局
  build() {
    // 创建一个 Row 布局容器，用于水平排列其子组件
    Row() {
      // 开始 Row 布局容器的定义
      // 创建一个 Column 布局容器，用于垂直排列其子组件，该 Column 是上面 Row 的子组件
      Column() {
        // 开始 Column 布局容器的定义
        // 创建一个 Text 组件，显示状态变量 message 的值
        Text(this.message)
          // 设置 Text 组件的字体大小为 50
          .fontSize(50)
          // 设置 Text 组件的字体加粗
          .fontWeight(FontWeight.Bold)
        // 创建一个 Button 组件，用于触发特定操作
        Button() {
          // 开始 Button 组件的定义
          // 在 Button 组件内部创建一个 Text 组件，显示文本 'Next'
          Text('Next')
            // 设置 Text 组件的字体大小为 30
            .fontSize(30)
            // 设置 Text 组件的字体加粗
            .fontWeight(FontWeight.Bold)
        } // 结束 Button 组件的定义
        // 设置 Button 组件的形状为胶囊形状
        .type(ButtonType.Capsule)
        // 设置 Button 组件的外边距，这里只设置了顶部外边距为 20
        .margin({
          // 开始设置 Button 组件外边距对象的定义
          top: 20
        }) // 结束设置 Button 组件外边距对象的定义
        // 设置 Button 组件的背景颜色为 '#0D9FFB'
        .backgroundColor('#0D9FFB')
        // 设置 Button 组件的宽度为父容器宽度的 40%
        .width('40%')
        // 设置 Button 组件的高度为父容器高度的 5%
        .height('5%')
        // 为 Button 组件添加点击事件监听器，当按钮被点击时执行回调函数
        .onClick(() => {
          // 开始 Button 组件点击事件回调函数的定义
          // 打印一条信息到控制台，表示成功点击了 'Next' 按钮
          console.info('Succeeded in clicking the ‘Next’ button.')
          // 使用 router 对象的 pushUrl 方法跳转到指定页面，这里是 'pages/Second'
          router.pushUrl({ url: 'pages/Second' }).then(() => {
            // 开始跳转成功回调函数的定义
            // 跳转成功后的回调函数，这里为空
          }) // 结束跳转成功回调函数的定义
          .catch((err: BusinessError) => {
            // 开始跳转失败回调函数的定义
            // 跳转失败时的回调函数，打印错误信息，包含错误码和错误消息
            console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`)
          }) // 结束跳转失败回调函数的定义
        }) // 结束 Button 组件点击事件回调函数的定义
      } // 结束 Column 布局容器的定义
      // 设置 Column 组件的宽度为父容器宽度的 100%
      .width('100%')
    } // 结束 Row 布局容器的定义
    // 设置 Row 组件的高度为父容器高度的 100%
    .height('100%')
  }//结束bulid方法体
}//结束IndexPage结构体
```
#Second.etc
```typescript {.line-numbers}
// 从 '@kit.ArkUI' 库中导入 router 对象，用于实现页面路由跳转功能
import { router } from '@kit.ArkUI';
// 从 '@kit.BasicServicesKit' 库中导入 BusinessError 类，用于处理业务相关的错误
import { BusinessError } from '@kit.BasicServicesKit';
// 标记该组件为应用的入口组件，程序启动时会首先加载此组件
@Entry
// 声明这是一个组件，用于构建界面元素
@Component
// 定义名为 Index 的组件结构体
struct Index {
  // 使用 @State 装饰器声明一个响应式状态变量 message，初始值为 'Hi there'，当该值改变时，相关 UI 会自动更新
  @State message: string = 'Hi there';
  // 组件的构建方法，用于定义组件的 UI 结构和布局
  build() {
    // 创建一个 Row 布局容器，用于水平排列其子组件
    Row() {
      // 开始 Row 布局容器的定义
      // 创建一个 Column 布局容器，用于垂直排列其子组件，该 Column 是上面 Row 的子组件
      Column() {
        // 开始 Column 布局容器的定义
        // 创建一个 Text 组件，显示状态变量 message 的值
        Text(this.message)
          // 设置 Text 组件的字体大小为 50
          .fontSize(50)
          // 设置 Text 组件的字体加粗
          .fontWeight(FontWeight.Bold)
        // 创建一个 Button 组件，用于触发特定操作
        Button() {
          // 开始 Button 组件的定义
          // 在 Button 组件内部创建一个 Text 组件，显示文本 'Back'
          Text('Back')
            // 设置 Text 组件的字体大小为 30
            .fontSize(30)
            // 设置 Text 组件的字体加粗
            .fontWeight(FontWeight.Bold)
        } // 结束 Button 组件的定义
        // 设置 Button 组件的形状为胶囊形状
        .type(ButtonType.Capsule)
        // 设置 Button 组件的外边距，这里只设置了顶部外边距为 20
        .margin({
          // 开始设置 Button 组件外边距对象的定义
          top: 20
        }) // 结束设置 Button 组件外边距对象的定义
        // 设置 Button 组件的背景颜色为 '#0D9FFB'
        .backgroundColor('#0D9FFB')
        // 设置 Button 组件的宽度为父容器宽度的 40%
        .width('40%')
        // 设置 Button 组件的高度为父容器高度的 5%
        .height('5%')
        // 为 Button 组件添加点击事件监听器，当按钮被点击时执行回调函数
        .onClick(() => {
          // 开始 Button 组件点击事件回调函数的定义
          // 打印一条信息到控制台，表示成功点击了 'Back' 按钮
          console.info('Succeeded in clicking the ‘Back’ button.')
          try {
            // 开始 try 代码块，用于尝试执行返回上一页的操作
            // 使用 router 对象的 back 方法返回上一个页面
            router.back()
            // 打印一条信息到控制台，表示成功返回第一页
            console.info('Succeeded in returning to the first page.')
          } catch (err) {
            // 开始 catch 代码块，用于捕获返回上一页操作中的错误
            // 将错误对象转换为 BusinessError 类型，并获取错误码
            let code = (err as BusinessError).code;
            // 将错误对象转换为 BusinessError 类型，并获取错误消息
            let message = (err as BusinessError).message;
            // 打印错误信息到控制台，包含错误码和错误消息
            console.error(`Failed to return to the first page. Code is ${code}, message is ${message}`)
          } // 结束 catch 代码块
        }) // 结束 Button 组件点击事件回调函数的定义
      } // 结束 Column 布局容器的定义
      // 设置 Column 组件的宽度为父容器宽度的 100%
      .width('100%')
    } // 结束 Row 布局容器的定义
    // 设置 Row 组件的高度为父容器高度的 100%
    .height('100%')
  }//结束bulid方法体
}//结束SecondPage结构体
```
##运行结果图片
<img
src="D:\vscode\111.png">
<img
src="D:\vscode\222.png">
<img
src="D:\vscode\333.png">

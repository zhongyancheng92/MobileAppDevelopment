# index页面
import { BusinessError } from '@kit.BasicServicesKit';//导入BusinessError类，用于处理相关错误
import { router } from '@kit.ArkUI';//导入页面路由模块，用于页面之间的路由跳转操作

@Entry//标志该组件为一个页面入口
@Component//标志这是一个组件
struct Index { //定义名为Index的组件结构
  @State message: string = 'Index页面' ;//定义状态变量message，类型为字符串，显示初始值为‘Index页面’
  build() {  // 构建组件的视图方法
    Row(){// 创建一个水平布局容器 Row
      Column(){// 在 Row 容器中创建一个垂直布局容器 Column
        Text(this.message)    // 创建一个文本组件，显示 this.message 的内容
          .fontSize(50)   // 字体大小50
          .fontWeight(FontWeight.Bold) //字体加粗
          .fontColor(0xff0000)//颜色红色

        Button() {//添加点击按钮
          Text('跳转')//按钮文本为跳转
            .fontSize(50)// 字体大小50
            .fontWeight(FontWeight.Bold) //字体加粗
            .fontColor(0xffffff)//颜色白色
        }//为16行的大括号下
        .type(ButtonType.Capsule)//胶囊形按钮
        .margin({
          top:20//与message文本间隔20
        })//为23行的大括号和小括号下
        .backgroundColor(0x0000ff)//颜色蓝色
        .width('40%')//设置按钮的宽度为40
        .height('7%')//设置按钮的高度为7
        .onClick(() => { // 为按钮添加点击事件监听器
          console.info('Click Successes')//点击成功提示
          router.pushUrl({url:'pages/Second'}).then(()=>{//使用router.pushUrl方式进行跳转到pages/Second页面
            console.info('Loading Successes')//跳转成功提示

          }).catch((err: BusinessError)=>{
            console.error('Loading Failed.Code is ${err.code},message is ${err.message}')
          }) // 如果跳转失败，在控制台输出错误信息，包括错误码和错误消息
        })//为29行的大括号和小括号下

      }//为10行的大括号下
      .width('100%')    // Column 容器的宽度为Row容器宽度的 100%
    }//为9行的大括号下

    .height('100%') // Column 容器的宽度为Row容器高度的 100%

  }//为8行的大括号下
}

## second页面
import { BusinessError } from '@kit.BasicServicesKit';//导入BusinessError类，用于处理相关错误
import { router } from '@kit.ArkUI';//导入页面路由模块，用于页面之间的路由跳转操作

@Entry// 标识该组件为一个页面入口
@Component// 标识这是一个可组合的组件
struct Second {// 定义名为 Second 的组件结构
  @State message: string = 'Second页面'; //定义一个状态变量 message，类型为字符串，初始值为 'Second页面'

  build() { // 构建组件视图的方法
    Row(){// 创建一个水平布局容器 Row
      Column(){ // 在 Row 容器中创建一个垂直布局容器 Column
        Text(this.message)  // 文本组件显示 this.message 的内容
          .fontSize(50) // 文本的字体大小为 50
          .fontWeight(FontWeight.Bold) // 文本字体加粗
          .fontColor('0xff0000')//颜色红色
        Button(){  // 创建一个按钮组件
          Text('返回') // 在按钮内创建一个文本组件，显示文本为 '返回'
            .fontSize(30)  // 设置按钮内文本的字体大小为 30
            .fontWeight(FontWeight.Bold)// 按钮内字体加粗
        }//为16行的大括号下
        .type(ButtonType.Capsule) // 设置按钮的类型为胶囊形
        .margin({
          top:20 // 设置按钮的外边距，顶部外边距为 20
        })//为22行的大括号和小括号下
        .backgroundColor('rgba(255,105,10,0.85)')//85%不透明度的红色背景（使用 rgba 格式）
        .width('40%') //设置按钮的宽度为Row容器宽度的 40%
        .height('5%')//设置按钮的宽度为Row容器高度的 5%
        .onClick(()=>{ //返回绑定的onclick事件
          console.info('Clicking Successes') // 点击成功
          try {
            //返回第一页
            router.back()
            console.info('Returning Successes')// 返回成功
          }catch (err){
            let code=(err as BusinessError).code;// 将捕获到的错误转换为 BusinessError 类型，获取错误码
            let message=(err as BusinessError).message;  // 将捕获到的错误转换为 BusinessError 类型，获取错误消息
            console.error('Failed to return to the first page.Code is &{code},message is &{message}' )// 在控制台输出返回第一页失败的错误信息，包含错误码和错误消息
          }//为34行的大括号下
        })//为28行的大括号和小括号下
      }//为11行的大括号下
      .width('100%') // Column 容器的宽度为Row容器宽度的 100%
    }//为10行的大括号下
    .height('100%')// Column 容器的宽度为Row容器高度的 100%
  }//为9行的大括号下
}//为6行的大括号下

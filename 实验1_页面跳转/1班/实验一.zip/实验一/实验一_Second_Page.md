## 3225706020 张涵韬 实验一
## Second_Page
```typescript{.line-numbers}
// 导入ArkUI路由模块和基础服务错误类型[4,9](@ref)
import { router }  from '@kit.ArkUI';
import  { BusinessError }  from '@kit.BasicServicesKit';

// @Entry装饰器标记为入口组件（整个组件的根节点）
@Entry
// @Component表示自定义组件（struct结构体的作用域开始）
@Component 
struct Second {  // 结构体声明开始
  // @State装饰器管理组件内部状态（状态变量message的作用域）
  @State message: string = 'Hello World';

  // build方法定义UI布局（方法体括号开始）
  build() {
    // Row容器组件（参数括号定义组件属性）
    Row() {  // Row组件作用域开始
      // Column子容器（嵌套布局）
      Column() {  // Column组件作用域开始
        // 文本组件
        Text(this.message)  // Text组件开始
          .fontSize(50)     // 链式调用设置属性
          .fontWeight(FontWeight.Bold)  // 字体加粗
        // 文本组件作用域结束

        // 按钮组件（开始定义）
        Button() {  // Button组件作用域开始
          Text('Back')  // 按钮文本
            .fontSize(30)
            .fontWeight(FontWeight.Bold)
        }  // Button组件作用域结束
        .type(ButtonType.Capsule)  // 胶囊样式
        .margin({  // 外边距设置（对象参数括号）
          top: 20
        })
        .backgroundColor('#OD9FFB')  // 背景色（注意颜色值拼写应为#0D9FFB）
        .width('40%')    // 宽度比例
        .height('5%')    // 高度比例
    
        // 点击事件处理（箭头函数括号开始）
        .onClick(() => {  // 事件回调作用域开始
          console.info('Succeeded in clicking to the Back button.');
          try {  // try代码块开始
            // 路由返回操作
            router.back();
            console.info('Succeeded in returning to the first page.');
          } catch (err) {  // 异常处理开始
            // 类型断言为BusinessError
            let massage = (err as BusinessError).code;
            let code = (err as BusinessError).code;
            // 建议使用模板字符串：`Error ${code}`
            console.error('Failed to jump to the first page.Code is ${err.code},message is ${err.massage}')
          }  // catch代码块结束
        })  // onClick回调结束
      }  // Column组件结束
      .width('100%')  // 列宽设置
    }  // Row组件结束
    .height('100%')   // 行高设置
  }  // build方法结束
}  // struct结构体结束

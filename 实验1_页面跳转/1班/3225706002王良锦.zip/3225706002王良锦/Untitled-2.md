### 3225706002
### 王良锦
~~~stypescript {.line-numbbers}

// Second.ets  
// 导入页面路由模块  
**import** { router } **from** '@kit.ArkUI'; // 导入路由模块，用于页面跳转  
**import** { BusinessError } **from** '@kit.BasicServicesKit'; // 导入错误处理模块，用于捕获业务错误  

@Entry // 装饰器，标记该组件为页面入口  
@Component // 装饰器，标记该结构为组件  
**struct** Index { // 定义组件结构  
  @State message: string = 'Welcome'; // 定义状态变量，用于存储显示的文本内容  

  build() { // 构建页面的 UI 结构  
    Row() { // 创建一个水平布局容器（第1层括号）  
      Column() { // 创建一个垂直布局容器（第2层括号）  
        Text(**this**.message) // 创建一个文本组件，显示状态变量 message 的内容  
          .fontSize(50) // 设置文本字体大小为 50  
          .fontWeight(FontWeight.Bold) // 设置文本字体为加粗  
        Button() { // 创建一个按钮组件（第3层括号）  
          Text('Back') // 按钮内部显示文本 "Back"  
            .fontSize(30) // 设置按钮内文本字体大小为 30  
            .fontWeight(FontWeight.Bold) // 设置按钮内文本字体为加粗  
        } // 第3层括号结束  
        .type(ButtonType.Capsule) // 设置按钮形状为胶囊形  
        .margin({ // 设置按钮的外边距  
          top: 20 // 上边距为 20  
        }) // 外边距设置结束  
        .backgroundColor('#0D9FFB') // 设置按钮背景颜色  
        .width('40%') // 设置按钮宽度为父容器的 40%  
        .height('5%') // 设置按钮高度为父容器的 5%  
        // 返回按钮绑定onClick事件，点击按钮时返回到第一页  
        .onClick(() => { // 绑定点击事件的回调函数（第4层括号）  
          console.info('succeeded in clicking the **\'**Back**\'** button.') // 打印点击事件成功的日志  
          **try** { // 尝试执行页面返回操作（第5层括号）  
            // 返回第一页  
            // 此函数完成页面跳转  
            router.back() // 调用路由模块的 back 方法，返回到上一个页面  
            console.info('succeeded in returning to the first page') // 打印返回成功的日志  
          } **catch** (err) { // 捕获返回操作中可能出现的错误（第5层括号）  
            **let** code = (err **as** BusinessError).code; // 获取错误代码  
            **let** message = (err **as** BusinessError).message; // 获取错误信息  
            console.error('Failed to return to the first page. Code is ${code},message is ${message}') // 打印错误信息  
          } // 第5层括号结束  
        }) // 第4层括号结束  
      } // 第2层括号结束  
      .width('100%') // 设置垂直布局容器的宽度为父容器的 100%  
    } // 第1层括号结束  
    .height('100%') // 设置水平布局容器的高度为父容器的 100%  
  } // build 方法结束  
} // Index 组件结构结束

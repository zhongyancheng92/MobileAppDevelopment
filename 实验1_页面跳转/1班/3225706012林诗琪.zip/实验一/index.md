# 实验一

## 代码实现过程
```typescript
// index.etc

// 导入页面路由模块
import { router } from '@kit.ArkUI';  // 导入ArkUI框架中的路由模块
import { BusinessError } from '@kit.BasicServicesKit';  // 导入基础服务模块中的错误处理类

@Entry  // 标记当前组件为应用的入口组件
@Component  // 标记当前结构体为自定义组件
struct Index {  // 定义名为Index的结构体组件
  @State message: string = 'Index页面';  // 使用@State装饰器定义一个响应式状态变量message，初始值为'Index页面'

  build() {  // 定义组件的UI构建方法
    Row() {  // 创建一个行布局容器
      Column() {  // 创建一个列布局容器
        Text(this.message)  // 创建一个文本组件，显示message的内容
          .fontSize(50)  // 设置文本字体大小为50
          .fontWeight(FontWeight.Bold)  // 设置文本字体加粗
        // 添加按钮，以响应用户点击
        Button(){  // 创建一个按钮组件
          Text('Next')  // 在按钮内部创建一个文本组件，显示'Next'
            .fontSize(30)  // 设置按钮文本字体大小为30
            .fontWeight(FontWeight.Bold)  // 设置按钮文本字体加粗
        }//按钮组件创建完毕
        .type(ButtonType.Capsule)  // 设置按钮类型为胶囊形状
        .margin({  // 设置按钮的外边距
          top:20  // 上边距为20
        })//按钮的外边距设置完毕
        .backgroundColor('#0D9FFB')  // 设置按钮的背景颜色为#0D9FFB
        .width('40%')  // 设置按钮的宽度为父容器的40%
        .height('5%')  // 设置按钮的高度为父容器的5%
        // 跳转按钮绑定onClick事件，点击时跳转到第二页
        .onClick(() =>{  // 为按钮绑定点击事件
          console.info('Succeeded in clicking the "Next" button.')  // 打印日志，表示按钮点击成功
          // 跳转到第二页
          router.pushUrl({ url: 'pages/Second' }).then(() =>{  // 调用路由模块的pushUrl方法，跳转到'pages/Second'页面
            console.info('Succeeded in jumping to the second page.')  // 打印日志，表示跳转成功
          }).catch((err: BusinessError) =>{  // 捕获跳转过程中可能出现的错误
            console.error('Failed to jump to the second page. Code is ${err.code}, message is ${err.message}')  // 打印错误日志，包含错误代码和错误信息
          })//捕获完毕
         })//按钮绑定事件结束
      }//列布局创建完毕
      .width('100%')  // 设置列布局容器的宽度为100%
    }//行布局创建完毕
    .height('100%')  // 设置行布局容器的高度为100%
  }//组件的UI构建方法结束
}//Index的结构体组件创建完毕


// Second.ets

// 导入页面路由模块
import { router } from '@kit.ArkUI';  // 导入ArkUI框架中的路由模块
import { BusinessError } from '@kit.BasicServicesKit';  // 导入基础服务模块中的错误处理类

@Entry  // 标记当前组件为应用的入口组件
@Component  // 标记当前结构体为自定义组件
struct Second {  // 定义名为Second的结构体组件
  @State message: string = 'Hi there';  // 使用@State装饰器定义一个响应式状态变量message，初始值为'Hi there'

  build() {  // 定义组件的UI构建方法
    Row() {  // 创建一个行布局容器
      Column() {  // 创建一个列布局容器
        Text(this.message)  // 创建一个文本组件，显示message的内容
          .fontSize(50)  // 设置文本字体大小为50
          .fontWeight(FontWeight.Bold)  // 设置文本字体加粗
        // 添加按钮，以响应用户点击
        Button() {  // 创建一个按钮组件
          Text('Back')  // 在按钮内部创建一个文本组件，显示'Back'
            .fontSize(30)  // 设置按钮文本字体大小为30
            .fontWeight(FontWeight.Bold)  // 设置按钮文本字体加粗
        }//按钮组件创建完毕
        .type(ButtonType.Capsule)  // 设置按钮类型为胶囊形状
        .margin({  // 设置按钮的外边距
          top: 20  // 上边距为20
        })//按钮的外边距设置完毕
        .backgroundColor('#0D9FFB')  // 设置按钮的背景颜色为#0D9FFB
        .width('40%')  // 设置按钮的宽度为父容器的40%
        .height('5%')  // 设置按钮的高度为父容器的5%
        // 返回按钮绑定onClick事件，点击按钮时返回到第一页
        .onClick(() => {  // 为按钮绑定点击事件
          console.info('Succeeded in clicking the "Back" button.')  // 打印日志，表示按钮点击成功
          try {  // 尝试执行以下代码
            // 返回第一页
            router.back()  // 调用路由模块的back方法，返回上一页
            console.info('Succeeded in returning to the first page.')  // 打印日志，表示返回成功
          } catch (err) {  // 捕获可能出现的错误
            let code = (err as BusinessError).code;  // 获取错误代码
            let message = (err as BusinessError).message;  // 获取错误信息
            console.error(`Failed to return to the first page. Code is ${code}, message is ${message}`)  // 打印错误日志，包含错误代码和错误信息
          }//捕获完毕
        })//按钮绑定事件结束
      }//列布局创建完毕
      .width('100%')  // 设置列布局容器的宽度为100%
    }//行布局创建完毕
    .height('100%')  // 设置行布局容器的高度为100%
  }//组件的UI构建方法结束
}//Second的结构体组件创建完毕
```
## 插入第一个代码实现的截图
![](1.png)
## 插入第二个代码实现的截图
![](2.png)


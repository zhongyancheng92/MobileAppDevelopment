# <font ><center>移动应用开发 </font>
## <center>实验一:页面跳转
##### <font ><center>班级：22空数1班 姓名：范馨霏 学号：3225706008</font>
#### 一、实验演示： 
![image-test1](test1.png)
#### 二：实验代码：
页面一Index.ets：
```typescript
// Index.ets

// 导入页面路由模块（用于页面跳转）
import { router } from '@kit.ArkUI';
// 导入业务错误处理模块（用于捕获路由错误）
import { BusinessError } from '@kit.BasicServicesKit'

// @Entry 装饰器：标记本组件为页面入口
// @Component 装饰器：声明本结构体为UI组件
struct Index {
  // @State 装饰器：声明响应式状态变量，用于动态更新UI
  @State message: string = 'Index页面';

  // 构建UI结构的方法
  build() {
    // 创建水平布局容器，设置高度为100%
    Row() {
      // 创建垂直布局容器，设置宽度为100%
      Column() {
        // 显示文本组件，绑定message状态变量
        Text(this.message)
          // 设置字体大小为50
          .fontSize(50)
          // 设置字体加粗
          .fontWeight(FontWeight.Bold)

        // 创建按钮
        Button() {
          // 按钮内文本内容
          Text('Next')
            // 设置字体大小为30
            .fontSize(30)
            // 设置字体加粗
            .fontWeight(FontWeight.Bold)
        }
        // 设置按钮
        .type(ButtonType.Capsule)
        // 设置外边距（上20）
        .margin({
          top: 20
        })
        // 设置背景颜色为蓝色
        .backgroundColor('#0D9FFB')
        // 设置按钮宽度为父容器的40%
        .width('40%')
        // 设置按钮高度为父容器的5%
        .height('5%')
        // 按钮点击事件处理
        .onClick(() => {
          // 点击时输出日志信息
          console.info('Succeeded in clicking the "Next" button.')
          
          // 执行页面跳转操作
          router.pushUrl({ url: 'pages/Second' })
            // 跳转成功回调
            .then(() => {
              console.info('Succeeded in jumping to the second page.')
            })
            // 跳转失败回调
            .catch((err: BusinessError) => {
              // 输出错误日志（使用模板字符串拼接错误码和消息）
              console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`)
            })
        })
      }
      // 设置Column容器宽度为100%
      .width('100%')
    }
    // 设置Row容器高度为100%
    .height('100%')
  }
}
```
页面二Second.ets：
```typescript
// Second.ets

// 导入页面路由模块（用于页面导航）
import { router } from '@kit.ArkUI';
// 导入业务错误处理模块（用于捕获路由错误）
import { BusinessError } from '@kit.BasicServicesKit';

// @Entry 装饰器：标记本组件为页面入口
// @Component 装饰器：声明本结构体为UI组件
struct Second {
  // @State 装饰器：声明响应式状态变量，用于动态更新UI
  @State message: string = 'Hi There';

  // 构建UI结构的方法
  build() {
    // 创建水平布局容器，设置高度为100%
    Row() {
      // 创建垂直布局容器，设置宽度为100%
      Column() {
        // 显示文本组件，绑定message状态变量
        Text(this.message)
          // 设置字体大小为50
          .fontSize(50)
          // 设置字体加粗
          .fontWeight(FontWeight.Bold)

        // 创建按钮
        Button() {
          // 按钮内文本内容
          Text('Back')
            // 设置字体大小为30
            .fontSize(30)
            // 设置字体加粗
            .fontWeight(FontWeight.Bold)
        }
        // 设置按钮
        .type(ButtonType.Capsule)
        // 设置外边距（上20）
        .margin({
          top: 20
        })
        // 设置背景颜色为蓝色
        .backgroundColor('#0D9FFB')
        // 设置按钮宽度为父容器的40%
        .width('40%')
        // 设置按钮高度为父容器的5%
        .height('5%')
        // 按钮点击事件处理
        .onClick(() => {
          // 点击时输出日志信息
          console.info('Succeeded in clicking the "Back" button.')
          
          try {
            // 执行返回操作（返回上一页）
            router.back()
            // 返回成功日志
            console.info('Succeeded in returning to the first page.')
          } catch (err) {
            // 错误处理（尝试将错误转换为BusinessError类型）
            let code = (err as BusinessError).code;
            let message = (err as BusinessError).message;
            // 输出错误日志（使用模板字符串拼接错误码和消息）
            console.error(`Failed to return to the first page. Code is ${code}, message is ${message}`)
          }
        })
      }
      // 设置Column容器宽度为100%
      .width('100%')
    }
    // 设置Row容器高度为100%
    .height('100%')
  }
}
```
#### 三：对函数的总结说明：
1. 导航相关 API
`router.back()`
功能：关闭当前页面并返回上一页。
说明：属于 `@kit.ArkUI` 的路由管理模块，用于页面栈的导航操作。若页面栈中无上一页，可能触发异常。
参考：
HarmonyOS API - router.back()
1. 错误处理 API
`BusinessError`
功能：表示业务逻辑层抛出的错误类型，包含错误码（code）和错误信息（message）。
说明：属于 `@kit.BasicServicesKit`，用于统一错误处理。通过 (err as BusinessError) 类型断言提取错误详情。
参考：
HarmonyOS API - BusinessError
1. 组件与装饰器
`@Entry`
功能：标记组件为页面入口，使组件可被路由加载。
说明：必须与 `@Component `配合使用，定义页面的根组件。
参考：
HarmonyOS API - @Entry
`@Component`
功能：声明一个 UI 组件，定义组件的生命周期和模板。
说明：所有可视化组件均需通过此装饰器注册。
参考：
HarmonyOS API - @Component
`@State`
功能：声明组件的响应式状态变量，数据变化时自动触发 UI 更新。
说明：需初始值，修改时需通过 setState 方法（本例直接赋值可能依赖框架隐式更新）。
参考：
HarmonyOS API - @State
1. UI 组件与布局
`Row() / Column()`
功能：定义水平（Row）或垂直（Column）布局容器，自动排列子组件。
说明：通过 `.width('100%')` 和` .height('100%') `设置布局尺寸，适配父容器。
参考：
HarmonyOS API - Row/Column
`Text()`
功能：显示文本内容，支持样式定制。
说明：通过 `.fontSize(50) `和 `.fontWeight(FontWeight.Bold)` 设置字体大小和粗细。
参考：
HarmonyOS API - Text
`Button()`
功能：创建可交互按钮，支持点击事件和样式配置。
关键属性：
`.type(ButtonType.Capsule)`：设置按钮形状为胶囊样式。
`.margin({ top: 20 })`：设置外边距。
`.backgroundColor('#0D9FFB')`：设置背景色。
`.onClick(() => { ... })`：绑定点击事件。
参考：
HarmonyOS API - Button
1. 样式与布局属性
`.fontSize() / .fontWeight()`
功能：设置字体大小和粗细，参数为数值或枚举值（如 FontWeight.Bold）。
说明：属于 TextStyle 属性，影响文本显示效果。
参考：
HarmonyOS API - TextStyle
`.margin() / .width() / .height()`
功能：设置组件的外边距、宽度和高度，支持百分比或固定值。
说明：`.width('40%')` 表示按钮宽度为父容器的 40%。
参考：
HarmonyOS API - LayoutStyle
1. 事件处理
`.onClick(() => { ... })`
功能：为按钮绑定点击事件回调函数。
说明：用户点击按钮时触发，内部调用 router.back() 并处理异常。
参考：
HarmonyOS API - onClick

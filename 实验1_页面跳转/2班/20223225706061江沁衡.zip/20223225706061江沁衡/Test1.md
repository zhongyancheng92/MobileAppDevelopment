# Page1

Index.ets:

```ArkTS
// 导入页面路由模块，实现页面之间的跳转
import { router } from '@kit.ArkUI';  // 从 '@kit.ArkUI' 模块中导入 router 对象

// 导入业务错误处理模块，捕获页面跳转过程中可能出现的错误
import { BusinessError } from '@kit.BasicServicesKit';  // 从 '@kit.BasicServicesKit' 模块中导入 BusinessError 类

// 使用 @Entry 装饰器标记这是应用的入口页面
@Entry
  // 使用 @Component 装饰器声明一个组件
@Component
  // 定义名为 Index 的结构体
struct Index {
  // 定义一个状态属性 message，初始值为 'Index页面'
  @State message: string = 'Index页面';

  // 定义组件的构建方法，用于描述页面的 UI 结构
  build() {
    // 创建一个水平布局容器 Row
    Row() {
      // 在 Row 内部创建一个垂直布局容器 Column
      Column() {
        // 创建一个文本组件，内容为当前组件的 message 状态值
        Text(this.message)
          .fontSize(50)                // 设置文本的字体大小为 50
          .fontWeight(FontWeight.Bold);  // 设置文本的字体加粗

        // 添加一个按钮组件，用于响应用户的点击事件
        Button() {
          // 在按钮内部添加一个文本组件，显示 'Next'
          Text('Next')
            .fontSize(30)                // 设置按钮中文本的字体大小为 30
            .fontWeight(FontWeight.Bold);  // 设置按钮中文本的字体加粗
        }
        .type(ButtonType.Capsule)           // 设置按钮的样式为胶囊型
        .margin({ top: 20 })                // 设置按钮顶部外边距为 20
        .backgroundColor('#0D9FFB')         // 设置按钮背景颜色为 '#0D9FFB'
        .width('40%')                       // 设置按钮宽度为 40%
        .height('5%')                       // 设置按钮高度为 5%
        // 为按钮添加点击事件监听器
        .onClick(() => {
          // 当按钮被点击时，输出点击成功的日志信息
          console.info('Succeeded in clicking the Next button.');
          // 通过 router 对象跳转到第二个页面
          router.pushUrl({ url: 'pages/Second' }).then(() => {
            // 跳转成功后，输出成功跳转的日志信息
            console.info('Succeeded in jumping to the second page.');
          }).catch((err: BusinessError) => {
            // 如果跳转失败，则捕获错误并输出错误代码和错误信息
            console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`);
          });
        });
      }
      .width('100%')   // 设置 Column 组件的宽度为 100%
    }
    .height('100%')    // 设置 Row 组件的高度为 100%
  }
}
```

# Page2

Second.ets:

```ArkTS
// 导入页面路由模块，用于实现页面之间的跳转
import { router } from '@kit.ArkUI';
// 导入业务错误处理模块，用于捕获页面跳转过程中可能出现的错误
import { BusinessError } from '@kit.BasicServicesKit';

// 使用 @Entry 装饰器标记这是应用的入口组件之一
@Entry
  // 使用 @Component 装饰器声明这是一个组件
@Component
  // 定义名为 Second 的结构体（组件），表示第二个页面
struct Second {
  // 定义一个状态属性 message，初始值为 'Hi there'
  @State message: string = 'Hi there';

  // 定义组件的构建方法，用于描述页面的 UI 布局结构
  build() {
    // 创建一个行布局组件 Row，用于将内部组件水平排列
    Row() {
      // 在 Row 内部创建一个列布局组件 Column，用于将内部组件垂直排列
      Column() {
        // 创建一个文本组件，显示当前组件的 message 状态值
        Text(this.message)
          .fontSize(50)                    // 设置文本的字体大小为 50
          .fontWeight(FontWeight.Bold);    // 设置文本为加粗字体

        // 添加按钮组件，用于响应用户点击操作
        Button() {
          // 在按钮内部创建一个文本组件，显示 'Back'
          Text('Back')
            .fontSize(30)                  // 设置按钮中文本的字体大小为 30
            .fontWeight(FontWeight.Bold);  // 设置按钮中文本为加粗字体
        }
        .type(ButtonType.Capsule)           // 设置按钮的样式为胶囊型
        .margin({ top: 20 })                // 设置按钮顶部外边距为 20
        .backgroundColor('#0D9FFB')         // 设置按钮的背景颜色为 '#0D9FFB'
        .width('40%')                       // 设置按钮宽度为 40%
        .height('5%')                       // 设置按钮高度为 5%
        // 为按钮添加点击事件监听器，当用户点击时触发回调函数
        .onClick(() => {
          // 输出日志信息，表明点击 Back 按钮成功
          console.info('Succeeded in clicking the Back button.');
          // 使用 router 对象跳转到首页（Index 页面）
          router.pushUrl({ url: 'pages/Index' }).then(() => {
            // 页面跳转成功后输出日志信息
            console.info('Succeeded in jumping to the first page.');
          }).catch((err: BusinessError) => {
            // 如果页面跳转失败，则捕获错误并输出错误代码及错误信息
            console.error(`Failed to jump to the first page. Code is ${err.code}, message is ${err.message}`);
          })
        })
      }
      .width('100%')  // 设置 Column 组件的宽度为 100%
    }
    .height('100%')   // 设置 Row 组件的高度为 100%
  }
}
```
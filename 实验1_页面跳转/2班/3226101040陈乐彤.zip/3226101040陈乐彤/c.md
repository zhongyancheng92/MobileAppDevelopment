# 这是第一个页面
```typescript {.line-numbers}
// 从 '@kit.ArkUI' 模块中导入 router 对象，该对象用于处理页面的路由跳转操作
import { router } from '@kit.ArkUI';
// 从 '@kit.BasicServicesKit' 模块中导入 BusinessError 类，用于处理业务相关的错误
import {BusinessError} from '@kit.BasicServicesKit';

// @Entry 装饰器表明该组件是应用的一个入口点，通常用于指定应用启动时首先加载的页面
@Entry
// @Component 装饰器将 Index 类标记为一个组件，组件是 ArkTS 中构建 UI 的基本单元
@Component
// 定义一个名为 Index 的结构体，作为组件的主体
struct Index {
  // @State 装饰器创建一个响应式状态变量 message，初始值为 'Hello World'
  // 当这个变量的值发生改变时，依赖它的 UI 元素会自动更新
  @State message: string = 'Hello World';

  // 组件的 build 方法，用于定义组件的 UI 结构
  build() {
    // 创建一个 Row 容器组件，它会将其子组件水平排列
    Row(){
      // 在 Row 容器内创建一个 Column 容器组件，它会将其子组件垂直排列
      Column(){
        // 创建一个 Text 组件，用于显示 message 状态变量的值
        Text(this.message)
          // 设置 Text 组件的字体大小为 50
          .fontSize(50)
          // 设置 Text 组件的字体粗细为粗体
          .fontWeight(FontWeight.Bold)
        // 创建一个 Button 组件
        Button() {
          // 在 Button 组件内部创建一个 Text 组件，显示文本 'Next'
          Text('Next')
            // 设置 Button 内部 Text 组件的字体大小为 30
            .fontSize(30)
            // 设置 Button 内部 Text 组件的字体粗细为粗体
            .fontWeight(FontWeight.Bold)
          // 结束 Button 内部 Text 组件的创建
          }
          // 设置 Button 组件的样式类型为胶囊形状
          .type(ButtonType.Capsule)
          // 设置 Button 组件的外边距，这里只设置了顶部外边距为 20
          .margin({
            top:20
          })
          // 设置 Button 组件的背景颜色为 '#0D9FFB'
          .backgroundColor('#0D9FFB')
          // 设置 Button 组件的宽度为父容器宽度的 40%
          .width('%40')
          // 设置 Button 组件的高度为父容器高度的 5%
          .height('%5')
          // 为 Button 组件绑定 onClick 事件，当按钮被点击时会执行相应的回调函数
          .onClick(() =>{
            // 在控制台输出信息，表示成功点击了 'Next' 按钮
            console.info(`Succeeded in clicking  the 'Next' button.`)
            // 调用 router 对象的 pushUrl 方法，尝试跳转到 'pages/Second' 页面
            // pushUrl 方法返回一个 Promise 对象，用于处理跳转结果
            router.pushUrl({ url: 'pages/Second'}).then(() => {
              // 当跳转成功时，在控制台输出信息，表示成功跳转到第二页
              console.info('Succeeded in jumping to the second page.')
            // 当跳转失败时，捕获错误并进行处理
            }).catch((err:BusinessError) => {
              // 在控制台输出错误信息，包含错误代码和错误消息
              console.error(`Failed to jump to the second page. Code is ${err.code},message is ${err.message}`)
            })
            // 结束 Button 组件 onClick 事件的回调函数
          })
        // 结束 Column 容器组件内的内容定义，此右括号对应上面创建 Column 容器的左括号
        }
        // 设置 Column 容器组件的宽度为父容器宽度的 100%
        .width('100%')
      // 结束 Row 容器组件内的内容定义，此右括号对应上面创建 Row 容器的左括号
      }
      // 设置 Row 容器组件的高度为父容器高度的 100%
      .height('100%')
    // 结束 build 方法的内容定义，此右括号对应上面 build 方法定义的左括号
    }
  // 结束 Index 结构体的定义，此右括号对应上面 struct Index { 的左括号
  }
```
# 这是第二个页面Second
```typescript {.line-numbers}
// 从 '@kit.ArkUI' 模块中导入 router 对象，该对象用于处理页面的路由跳转操作，如页面的前进、后退等
import { router } from '@kit.ArkUI';
// 从 '@kit.BasicServicesKit' 模块中导入 BusinessError 类，用于处理业务相关的错误，当路由跳转等操作失败时可能会抛出此类错误
import {BusinessError} from '@kit.BasicServicesKit';

// @Entry 装饰器表明该组件是应用的一个入口点，通常用于指定应用启动时首先加载的页面，这里 SecondPage 可作为应用启动后可访问的一个页面入口
@Entry
// @Component 装饰器将 SecondPage 类标记为一个组件，组件是 ArkTS 中构建 UI 的基本单元，一个组件可以包含各种 UI 元素和交互逻辑
@Component
// 定义一个名为 SecondPage 的结构体组件
struct SecondPage {
  // @State 装饰器创建一个响应式状态变量 message，初始值为 'This is my phone'
  // 当这个变量的值发生改变时，依赖它的 UI 元素会自动更新，例如这里的 Text 组件显示的内容会随之改变
  @State message: string = 'This is my phone';

  // 组件的 build 方法，用于定义组件的 UI 结构，在组件实例化时会自动调用该方法来构建 UI
  build() {
    // 创建一个 Row 容器组件，它会将其子组件水平排列，方便对多个组件进行横向布局
    Row(){
      // 在 Row 容器内创建一个 Column 容器组件，它会将其子组件垂直排列，用于构建垂直方向的 UI 布局
      Column(){
        // 创建一个 Text 组件，用于显示 message 状态变量的值，这样 UI 上会显示 'This is my phone'
        Text(this.message)
          // 设置 Text 组件的字体大小为 50，调整文本显示的大小
          .fontSize(50)
          // 设置 Text 组件的字体粗细为粗体，让文本显示更突出
          .fontWeight(FontWeight.Bold)
        // 创建一个 Button 组件，用于提供交互功能，这里是作为返回按钮
        Button() {
          // 在 Button 组件内部创建一个 Text 组件，显示文本 'Back'，作为按钮的显示内容
          Text('Back')
            // 设置 Button 内部 Text 组件的字体大小为 30，调整按钮上文本的大小
            .fontSize(30)
            // 设置 Button 内部 Text 组件的字体粗细为粗体，让按钮文本更醒目
            .fontWeight(FontWeight.Bold)
        // 结束 Button 组件内部 Text 组件的定义，此右括号对应上面 Button 内部创建 Text 组件的左括号
        }
        // 设置 Button 组件的样式类型为胶囊形状，改变按钮的外观
        .type(ButtonType.Capsule)
        // 设置 Button 组件的外边距，这里只设置了顶部外边距为 20，调整按钮与上方元素的间距
        .margin({
          top:20
        })
        // 设置 Button 组件的背景颜色为 '#0D9FFB'，改变按钮的背景色
        .backgroundColor('#0D9FFB')
        // 设置 Button 组件的宽度为父容器宽度的 40%，根据父容器的宽度来确定按钮的宽度
        .width('%40')
        // 设置 Button 组件的高度为父容器高度的 5%，根据父容器的高度来确定按钮的高度
        .height('%5')
        // 为 Button 组件绑定 onClick 事件，当按钮被点击时会执行相应的回调函数，实现交互逻辑
        .onClick(() =>{
          // 在控制台输出信息，表示成功点击了 'Back' 按钮，方便调试和查看交互情况
          console.info(`Succeeded in clicking  the 'Back' button.`)
          // 使用 try-catch 块来捕获可能出现的异常，确保在返回操作出错时能进行相应处理
          try{
            // 调用 router 对象的 back 方法，尝试返回到上一个页面（即第一页），实现页面的返回操作
            router.back()
            // 在控制台输出信息，表示成功返回到第一页，方便确认返回操作是否成功
            console.info(`Succeeded in returning to the first page.`)
          // 捕获返回操作中可能出现的错误
          } catch (err) {
            // 将捕获到的错误对象强制转换为 BusinessError 类型，并获取错误代码，用于定位错误原因
            let code = (err as BusinessError).code;
            // 将捕获到的错误对象强制转换为 BusinessError 类型，并获取错误消息，用于详细了解错误情况
            let message = (err as BusinessError).message;
            // 在控制台输出错误信息，包含错误代码和错误消息，方便调试和排查问题
            console.error(`Failed to return to the first page. Code is ${code},message is ${message}`)
          }
        // 结束 Button 组件 onClick 事件回调函数的定义，此右括号对应上面 onClick 事件回调函数的左括号
        })
      // 结束 Column 容器组件内子元素的定义，此右括号对应上面创建 Column 容器的左括号
      }
      // 设置 Column 容器组件的宽度为父容器宽度的 100%，让 Column 容器填满父容器的宽度
      .width('100%')
    // 结束 Row 容器组件内子元素的定义，此右括号对应上面创建 Row 容器的左括号
    }
    // 设置 Row 容器组件的高度为父容器高度的 100%，让 Row 容器填满父容器的高度
    .height('100%')
  // 结束 build 方法的定义，此右括号对应上面 build 方法的左括号
  }
// 结束 SecondPage 结构体组件的定义，此右括号对应上面 struct SecondPage { 的左括号
}
```
<img src="D:\3226101040陈乐彤\picture1.png">
<img src="D:\3226101040陈乐彤\picture2.png">
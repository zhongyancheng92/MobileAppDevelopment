# Index.ets
```typescript {.line-numbers}
import { router } from '@kit.ArkUI'; // 导入router模块，用于页面跳转功能。{}用于调用模块导入功能
import { BusinessError } from '@kit.BasicServicesKit'; // 导入BusinessError类，用于处理业务错误。{}用于
// 调用模块导入功能
@Entry // ArkUI框架的装饰器，标记这是一个页面入口
@Component // ArkUI框架的装饰器，标记这是一个组件
struct Index { // 定义一个名为Index的结构体，表示一个页面组件。定义一个名为Index的结构体，{}表示结构体的主体部分。
  @State message: string = 'Hello World'; // 定义一个状态变量message，初始值为'Hello World'，用于页面显示
  build() { // 定义build方法，用于构建页面的UI结构。()表示方法的参数列表（此处为空）。 定义build方法的主体部分，{}表示方法的实现代码
Row() { // 创建一个水平布局容器Row，用于排列子组。调用Row方法创建水平布局容器，()表示方法调用。定义Row方法的主体部分，{}表示Row组件的布局内容
      Column() { // 在Row中创建一个垂直布局容器Column，用于垂直排列子组件。在Row中调用Column方法创建垂直布局容器，()表示方法调用。定义Column方法的主体部分，{}表示Column组件的布局内容
        Text(this.message) // 在Column中创建一个文本组件，显示状态变量message的值。调用Text方法创建文本组件，()表示方法调用，并传递this.message作为参数
          .fontSize(50) // 设置文本字体大小为50
          .fontWeight(FontWeight.Bold) // 设置文本字体为加粗
        // 添加按钮，以响应用户点击
        Button() { // 在Column中创建一个按钮组件。调用Button方法创建按钮组件，()表示方法调用。定义Button方法的主体部分，{}表示按钮的内容
          Text('Next') // 在按钮中创建一个文本组件，显示文本'Next'。在按钮中调用Text方法创建文本组件，()表示方法调用，并传递字符串'Next'作为参数
            .fontSize(30) // 设置按钮内文本字体大小为30
            .fontWeight(FontWeight.Bold) // 设置按钮内文本字体为加粗
        } // Button组件的结束括号
        .type(ButtonType.Capsule) // 设置按钮的类型为胶囊形状
        .margin({ // 设置按钮的外边距。定义margin方法的参数对象，{}表示一个对象字面量
          top: 20 // 设置按钮的上边距为20
        }) // margin方法的结束括号
        .backgroundColor('#0D9FF8') // 设置按钮的背景颜色为'#0D9FF8'
        .width('%40') // 设置按钮的宽度为屏幕宽度的40%
        .height('%5') // 设置按钮的高度为屏幕高度的5%
        .onClick(() => { // 跳转按钮绑定onClick事件，点击时跳转到第二页。绑定按钮的点击事件，()定义了箭头函数的参数列表（此处为空）。定义按钮点击事件的回调函数体，{}表示回调函数的实现代码
          console.info(`Succeeded in Clicking the 'Next' button.`); // 打印点击成功的日志
          // 跳转到第二页
          router.pushUrl({ url: 'pages/Second' }) // 使用router模块的pushUrl方法跳转到第二页。调用router.pushUrl方法进行页面跳转，()表示方法调用，并传递一个对象作为参数
            .then(() => { // 跳转成功时的回调。定义Promise的then方法的回调函数，()定义了回调函数的参数列表（此处为空）。定义Promise的then方法的回调函数体，{}表示回调函数的实现代码
              console.info('Succeeded in jumping to the second page.'); // 打印跳转成功的日志
            }) // then方法的结束括号
            .catch((err: BusinessError) => { // 跳转失败时的回调，捕获BusinessError类型的错误。定义Promise的catch方法的回调函数，()定义了回调函数的参数列表，err为捕获的错误对象。定义Promise的catch方法的回调函数体，{}表示回调函数的实现代码
              console.error(`Failed to jump to the second page. Code is ${err.code}, message is ${err.message}`); // 打印错误信息
            }) // catch方法的结束括号
        }) // onClick方法的结束括号
      } // Column组件的结束括号
    } // Row组件的结束括号
    .width('100%') // 设置Row的宽度为屏幕宽度的100%
    .height('100%') // 设置Row的高度为屏幕高度的100%
  } // build方法的结束括号
} // Index结构体的结束括号
```

# Second.ets
```typescript {.line-numbers}
arkts{.line-numbers}
import { router } from '@kit.ArkUI'; // 导入router模块，用于页面跳转功能。{}用于调用模块导入功能
import { BusinessError } from '@kit.BasicServicesKit'; // 导入BusinessError类，用于处理业务错误。{}用于调用模块导入功能

@Entry // 标记这是一个页面入口
@Component // 标记这是一个组件
struct SecondPage { // 定义一个名为SecondPage的结构体，表示一个页面组件。 定义一个名为SecondPage的结构体，{}表示结构体的主体部分
  @State message: string = 'Hi there'; // 定义一个状态变量message，初始值为'Hi there'，用于页面显示

  build() { // 定义build方法，用于构建页面的UI结构。定义build方法，()表示方法的参数列表（此处为空）。定义build方法的主体部分，{}表示方法的实现代码
    Row() { // 创建一个水平布局容器Row。调用Row方法创建水平布局容器，()表示方法调用。定义Row方法的主体部分，{}表示Row组件的布局内容
      Column() { // 在Row中创建一个垂直布局容器Column。在Row中调用Column方法创建垂直布局容器，()表示方法调用。定义Column方法的主体部分，{}表示Column组件的布局内容
        Text(this.message) // 创建一个文本组件，显示状态变量message的值。调用Text方法创建文本组件，()表示方法调用，并传递this.message作为参数。
          .fontSize(50) // 设置文本字体大小为50
          .fontWeight(FontWeight.Bold) // 设置文本字体为加粗
        Button() { // 创建一个按钮组件。定义Button方法的主体部分，{}表示按钮的内容
          Text('Back') // 在按钮中创建一个文本组件，显示文本'Back'。在按钮中调用Text方法创建文本组件，()表示方法调用，并传递字符串'Back'作为参数
            .fontSize(30) // 设置按钮内文本字体大小为30
            .fontWeight(FontWeight.Bold) // 设置按钮内文本字体为加粗
        } // 定义按钮内容的结束括号
        .type(ButtonType.Capsule) // 设置按钮的类型为胶囊形状
        .margin({ // 设置按钮的外边距。定义margin方法的参数对象，{}表示一个对象字面量
          top: 20 // 设置按钮的上边距为20
        }) // margin方法的参数对象的结束括号
        .backgroundColor('#0D9FFB') // 设置按钮的背景颜色为'#0D9FFB'
        .width('%40') // 设置按钮的宽度为屏幕宽度的40%
        .height('%5') // 设置按钮的高度为屏幕高度的5%
        // 返回按钮绑定onClick事件，点击按钮时返回第一页
        .onClick(() => { // 绑定按钮的点击事件，箭头函数的开始。 绑定按钮的点击事件，()定义了箭头函数的参数列表（此处为空）。定义按钮点击事件的回调函数体，{}表示回调函数的实现代码。
          console.info(`Succeeded in clicking the 'Back' button.`); // 打印点击成功的日志
          try { // 开始一个try代码块，用于捕获可能的错误。定义try代码块的主体部分，{}表示try代码块的实现代码
            router.back() // 调用router的back方法返回上一个页面，此函数完成页面跳转
            console.info('Succeeded in returning to the first page.'); // 打印返回成功的日志
          } catch (err) { // 捕获try代码块中抛出的错误。定义Promise的catch方法的回调函数，()定义了回调函数的参数列表，err为捕获的错误对象。 定义catch代码块的主体部分，{}表示catch代码块的实现代码
            let code = (err as BusinessError).code; // 将err强制转换为BusinessError类型，并获取错误代码。 将err强制转换为BusinessError类型，并获取错误代码，()用于类型断言
            let message = (err as BusinessError).message; // 获取错误消息。获取错误消息，()用于类型断言
            console.error(`Failed to return to the first page. Code is ${code}，message is ${message}`); // 打印错误信息
          } // catch代码块的结束
        }) // onClick方法的结束括号
      } // Column组件的结束括号
      .width('100%') // 设置Column的宽度为屏幕宽度的100%
    } // Row组件的结束括号
    .height('100%') // 设置Row的高度为屏幕高度的100%
  } // build方法的结束括号
} // SecondPage结构体的结束括号
```

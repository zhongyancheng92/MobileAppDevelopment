## 实验一 实现页面的简单跳转

### 1. Index.ets

```typescript {.line-numbers}
// 导入ArkUI的路由模块
import { router } from '@kit.ArkUI';
// 导入基础服务错误处理模块
import { BusinessError } from '@kit.BasicServicesKit';

// @Entry 装饰器表示当前组件是应用入口组件
@Entry
// @Component 表示这是一个自定义组件
@Component

// 定义名为 Index 的结构体组件
struct Index {
  // @State 装饰器声明响应式变量message，用于维护组件状态
  @State message: string = 'First_Page';// 初始化页面标题为“First_Page”
  // build 方法用于描述UI布局
  build() {
    // Row 方法进行横向布局
    Row(){
      // Column 纵向布局
      Column(){
        // 文本组件显示message变量内容“First_Page”
        Text(this.message)
          // 设置字体大小为50
          .fontSize(50)
          // 对字体进行加粗
          .fontWeight(FontWeight.Bold)
        // 设置按钮组件
          Button(){
          // 按钮内文本为“Next_Page”
            Text('Next_Page')
              // 设置文本字体大小为30
              .fontSize(30)
              // 设置按钮文本加粗
              .fontWeight(FontWeight.Bold)
          }// 与28行括号对应的按钮方法的反括号，结束按钮内的文本设置
          // 设置按钮样式为胶囊形状
          .type(ButtonType.Capsule)
          // 设置按钮外边距
          .margin({
            // 顶部间距设置为20
            top:20
        })//为39行.margin属性赋值的反括号
          //设置按钮背景颜色，'#fff9cffa'为粉色
        .backgroundColor('#fff9cffa')
          // 设置按钮宽度为父容器的60%
        .width('60%')
          // 设置按钮高度为父容器的5%
        .height('5%')
          // 设置按钮点击事件
        .onClick(()=>{
          // 控制台打印点击成功信息
          console.info(`Succeeded in clicking the 'Next_Page'button.`)
          // 根据URL路径跳转到Second页面
          router.pushUrl({url:'pages/Second'}).then(()=>{
            // 控制台打印跳转成功信息
            console.info(`Succeeded in jumping to the second page.`)
          }).catch((err:BusinessError)=>{// 捕获跳转过程中的错误
            // 打印错误信息
            console.error(`Failed to jump to the second page.Code is ${err.code},message is ${err.message}`)
          })//为catch()方法捕获错误的反括号
        })// 为50行按钮点击事件的反括号
      }// 20行纵向布局的反括号
      // 设置纵向布局宽度为父容器的100%
      .width('100%')
    }// 18行横向布局的反括号
    // 设置横向布局高度为父容器的100%
    .height('100%')
  }//为16行build()方法的反括号
}//为12行 Index 的结构体组件的反括号
```
### 2.Second.ets
```typescript {.line-numbers}
// 导入ArkUI的路由模块
import { router } from '@kit.ArkUI';
// 导入基础服务错误处理模块
import { BusinessError } from '@kit.BasicServicesKit';

// @Entry 装饰器表示当前组件是应用入口组件
@Entry
  // @Component 表示这是一个自定义组件
@Component
  // 定义名为 Second 的结构体组件
struct Second {
  // @State 装饰器声明响应式变量message，用于维护组件状态
  @State message: string = 'Hi there';// 初始化页面标题为“Hi there”
  // build 方法用于描述UI布局
  build() {
    // Row 方法进行横向布局
    Row(){
      // Column 方法进行纵向布局
      Column(){
        // 文本组件显示message变量内容“First_Page”
        Text(this.message)
          // 设置字体大小为50
          .fontSize(50)
            // 对字体进行加粗
          .fontWeight(FontWeight.Bold)
        // 设置按钮组件
        Button(){
          // 按钮内文本为“Back”
          Text('Back')
            // 设置文本字体大小为30
            .fontSize(30)
              // 设置按钮文本加粗
            .fontWeight(FontWeight.Bold)
        }// 与27行括号对应的按钮方法的反括号，结束按钮内的文本设置
        // 设置按钮样式为胶囊形状
        .type(ButtonType.Capsule)
        // 设置按钮外边距
          .margin({
            // 顶部间距设置为20
            top:20
          })//为38行.margin属性赋值的反括号
        //设置按钮背景颜色，'#0D9FFB'为蓝色
          .backgroundColor('#0D9FFB')
        // 设置按钮宽度为父容器的40%
          .width('40%')
        // 设置按钮高度为父容器的5%
          .height('5%')
        // 设置按钮点击事件
        .onClick(()=>{
          // 控制台打印点击成功信息
          console.info(`Succeeded in clicking the 'Back'button.`)
          //使用try()方法
          try {
            // 尝试通过路由返回上一页
            router.back()
            // 如果成功返回上一页，在控制台打印成功信息
            console.info(`Succeeded in returning to the first page.`)
          }catch (err){//如果在尝试返回上一页时发生错误，进入catch块
            // 获取错误的代码
            let code = (err as BusinessError).code;
            // 获取错误的消息
            let message = (err as BusinessError).message;
            // 在控制台打印错误信息，包括错误代码和消息
            console.error(`Failed to return to the first page.Code is ${code}, message is ${message}`)
          }// 与58行catch(err)的括号对应的反括号
        })// 为49行按钮点击事件的反括号
      }// 19行纵向布局的反括号
      // 设置纵向布局宽度为父容器的100%
      .width('100%')
    }// 17行横向布局的反括号
    // 设置横向布局高度为父容器的100%
    .height('100%')
  }//为15行build()方法的反括号
}//为11行 Second 的结构体组件的反括号
```
### 页面1预览
<img src="./页面1.png" width="400" height="600" alt="alt text">

#### 页面2预览
<img src="页面2.png" width="400" height="600" alt="alt text">
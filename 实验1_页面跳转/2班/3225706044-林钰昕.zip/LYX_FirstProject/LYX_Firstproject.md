# 实验一

## 一、页面一的代码块及注释

**Index.ets**

```typescript {.line-numbers}
//导入页面路由模块
// 导入页面路由模块中的router对象
import { router } from '@kit.ArkUI';// 导入语句结束分号
// 导入基础服务模块中的BusinessError类
import { BusinessError } from '@kit.BasicServicesKit';// 导入语句结束分号

@Entry// 标识为应用入口的装饰器
@Component// 标识为自定义组件的装饰器
struct Index {// 定义名为Index的结构体开始
  @State // 状态变量装饰器
  message: string = 'First Page'// 声明响应式状态变量并初始化，定义为第一页

  build() { // 组件build方法开始
    Row(){ // 创建行布局容器开始
      Column(){ // 创建列布局容器开始
        Text(this.message) // 文本组件（使用状态变量），即调用第11行的代码
          .fontSize(50) // 文本样式设置，设置字体大小为50
          .fontWeight(FontWeight.Bold) // 文本样式设置，设置字体粗细为粗体
      //添加跳转按钮，以响应用户点击
        Button(){ // 按钮组件开始
          Text('Next') // 按钮内文本组件，意为“下一页”
            .fontSize(30) // 文本样式设置，设置字体大小为30
            .fontWeight(FontWeight.Bold)//文本样式设置，设置字体粗细为粗体
        } // 按钮组件结束
        .type(ButtonType.Capsule) // 设置按钮类型方法调用
        .margin({ // 设置外边距方法调用开始
          top: 20 // 顶部间距设置
        }) // 外边距对象结束
        .backgroundColor('#0D9ffB') // 设置背景颜色
        .width('40%') // 设置宽度为40%
        .height('5%') // 设置高度为5%
        //跳转按钮绑定onClick事件，点击时跳转到第二页
        .onClick(()=>{ // 点击事件回调函数开始
          console.info('Succeeded in clicking the ‘Next’ button.') // 路由跳转操作
          //跳转到第二页
          router.pushUrl({url:'pages/Second'}) // 调用路由方法，只有一个信息，只能完成跳转，无法完成信息传递
            .then(()=>{ // Promise成功回调开始
              console.info('Succeeded in jumping to the second page.')//提示性信息，翻译为“成功点击了‘Next’按钮”
            }) // then回调结束
            .catch((err: BusinessError) => { // catch回调开始
               console.info(`Failed to jump to the second page.Code is ${err.code},message is ${err.message}`)// 提示性信息，打印错误日志（注意此处应使用反引号）
            }) // catch回调结束
        }) // onClick回调结束
    } // Column布局结束
    .width('100%') // 设置列宽度为100%
  } // Row布局结束
  .height('100%') // 设置行高度为100%
} // build方法结束
} // Index结构体结束
```
## 二、页面二的代码块及注释

**Second.ets**

```typescript {.line-numbers}
// 导入页面路由模块
// 导入页面路由模块中的router对象
import { router } from '@kit.ArkUI';// 导入语句结束分号
// 导入基础服务模块中的BusinessError类
import { BusinessError } from '@kit.BasicServicesKit';// 导入语句结束分号
@Entry // 应用入口装饰器
@Component // 自定义组件装饰器
struct Index { // 定义组件结构体开始
  @State // 状态变量装饰器
  message: string = 'Second Page'; // 声明响应式状态变量并初始化

  build() { // 组件构建方法开始
    Row() { // 创建行布局容器开始
      Column() { // 创建列布局容器开始
        Text(this.message) // 显示状态变量文本
          .fontSize(50) // 设置字体大小
          .fontWeight(FontWeight.Bold) // 设置字体粗细
        //添加返回按钮，以响应用户点击
        Button() { // 按钮组件开始
          Text('Back') // 按钮文本
            .fontSize(30)// 设置字体大小
            .fontWeight(FontWeight.Bold)// 设置字体粗细
        } // 按钮组件结束
        .type(ButtonType.Capsule) // 设置按钮样式为胶囊
        .margin({ // 设置外边距开始
          top: 20 // 顶部间距20单位
        }) // 外边距对象结束
        .backgroundColor('#0D9ffB') // 设置按钮背景色
        .width('40%') // 设置按钮宽度
        .height('5%') // 设置按钮高度
        //返回按钮绑定onClick事件，点击时跳转到第一页
        .onClick(() => { // 点击事件回调开始
          console.info('Succeeded in clicking the ‘Back’ button.')//提示性信息，翻译为“成功点击了‘Back’按钮”
          try { // try代码块开始
            // 执行路由返回操作
            //返回到第一页
            //此函数完成页面跳转
            router.back() // 调用路由返回方法
            console.info('Succeeded in returning to the first page.')
          } catch (err) { // catch代码块开始
            // 类型断言转换错误对象
            let code = (err as BusinessError).code; // 获取错误码
            let message = (err as BusinessError).message; // 获取错误信息
            console.error(`Failed to return to the first page.Code is ${code},message is ${message}`)// 提示性信息，打印错误日志（注意此处应使用反引号）
          } // catch代码块结束
        }) // onClick回调结束

      } // Column布局结束
      .width('100%') // 设置列宽度为100%
    } // Row布局结束
    .height('100%') // 设置行高度为100%
  } // build方法结束
} // Index结构体结束
```
## 三、添加页面实施跳转

为解决无法跳转页面的问题，
在**main_pages.json**中添加一行
``
"pages/Second"
``
即可实现跳转。

```json {.line-numbers}
{
  "src": [
    "pages/Index",
    "pages/Second"
  ]
}
```

## 四、运行展示


**页面一**

![Image-Index](Index.png)

**页面二**

![Image-Second](Second.png)
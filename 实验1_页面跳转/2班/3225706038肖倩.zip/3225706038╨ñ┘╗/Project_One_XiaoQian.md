# 实验一：页面跳转
## 一、按钮跳转功能的实现
### 1.router对象
__import {router} from '@kit.ArkUI';__
*导入@kit.ArkUI模块中的router对象以使用此对象的方法实现页面的跳转功能*

 *   相关API：pushUrl(options: RouterOptions): Promise<void>
> 参数options的类型为 RouterOptions（跳转页面描述信息）
> RouterOptions路由跳转选项有三种：


| 名称       | 类型           | 
| ------------- |:-------------:| 
| url     | string |
|  params   | Object      |   
| recoverable | boolean     |   

```typescript{.line-numbers}
router.pushUrl({
  //router.pushUrl异步方法跳转到指定页面
            url: 'pages/Step5'//跳转到名为Step5的页面
          })
          .then(() => {
            //Promise成功回调函数
              console.info(`Succeeded in jumping to the second page`)//控制台记录成功跳转
            })
```      
> Promise：一种用于处理异步操作的JavaScript对象。本次实验用到了其中的两个操作（.then和.catch）   

### 2.BusinessError类
__import{ BusinessError } from '@kit.BasicServicesKit'__
*导入@kit.BasicServicesKit模块中的BusinessError类以在代码中对特定的错误类型进行区分和处理*

*    在 catch 块中，捕获的错误对象声明为 BusinessError 类型，并访问其 code 和 message 属性来记录错误信息。
```json5{.line-numbers}
 .catch((err: BusinessError) => {//err: BusinessError类型注解，表明 err 变量应该是一个 BusinessError 类型的实例。
  //Promise失败回调函数，跳转失败时捕获错误
           console.error(`Failed to jump to the secong page.Code is ${err.code},message is ${err.message}`)
              //控制台记录跳转失败，输出错误日志
          })
```

> err：catch方法的参数，表示错误对象
> code:错误码
> message：错误信息
表达式通过 ${     } 语法插入，能够在字符串中动态地嵌入变量的值。
### 3.类型断言
__变量名 as 类型__
*告诉编译器我更加清楚这个变量的类型，将该变量的类型定死*
* 在第二个页面的catch块中，将err变量的类型定为BusinessError类，编译器接受后，err就可以访问BusinessError类型中定义的任何属性（即code和message）
```typescript{.line-numbers}
catch(err) {//出现错误时进行捕获
            let code = (err as BusinessError).code;//将捕获的错误对象类型断言为BusinessError，并获取错误的代码
            let message = (err as BusinessError).message;//将捕获的错误对象类型断言为BusinessError，并获取错误的信息
            console.error(`Failed to return to the first page.Code is ${code},message is ${message}`)//控制台记录返回错误
          }

```

## 二、实验步骤
### 1.创建一个初始界面（无按钮）
* * * * 
```typescript{.line-numbers}
@Entry//定义入口点
@Component//定义这是一个组件
struct Index {//定义名为Index的结构体
  @State message: string = 'Hello World';//定义静态变量message

//创建一个初始界面（无按钮）
  build() {//定义界面
   Row(){//创建一行
     Column(){//创建一列
       Text(this.message)//添加文本，调用前面创建的message
         .fontSize(50)//字体大小
         .fontWeight(FontWeight.Bold)//字体加粗
     }//结束列的定义
     .width('100%')//设置列的宽度
   }//结束行的定义
   .height('100%')//设置行的高度
  }//结束界面的定义
}//结束结构体的定义
```
![alt text](image-5.png)
### 2.添加一个静态按钮
* * * * 
```typescript{.line-numbers}
@Entry//定义入口点
@Component//定义这是一个组件
struct Step2 {//定义了一个名为Step2的结构体
  @State message2: string = 'Hi Fujian';//定义了一个字符串类型的状态变量
  
  build() {//创建界面背景
    Row(){//创建一行
      Column(){//创建一列
        Text(this.message2)//添加文本，调用前面定义的message变量
          .fontSize(50)//文本大小
          .fontWeight(FontWeight.Bold)//本文加粗

        //添加按钮
        Button(){//创建按钮
          Text('Next')//按钮上的文本，以下是对文本的样式设置，并不是对按钮的
            .fontSize(30)//文本大小
            .fontWeight(FontWeight.Bold)//文本加粗
        }//创建按钮文本时的右括号
        .type(ButtonType.Capsule)//设置按钮的形式为胶囊型
        .margin({//设置按钮的位置：
          top:20//按钮的上边距离上一个元素（即文本message2）有20像素的距离
        })//margin函数的右括号
        .backgroundColor('#0D9FFB')//按钮的背景颜色
        .width('40%')//设置按钮的宽度为整个页面的40%
        .height('5%')//设置按钮的高度为整个页面的5%
      }//列的右括号
      .width('100%')//设置列的宽度占满整行
    }//行的右括号
    .height('100%')//设置行的高度占满整个屏幕
  }//界面背景的右括号
}//结构体的右括号
```
![alt text](image-6.png)
### 3.创建第二个页面
* * * * 
```typescript{.line-numbers}
@Entry//定义入口点
@Component//定义这是一个组件
struct Step3 {//定义名为Step3的结构体
  @State message3: string = 'Hello World';//定义一个静态变量message3

  build() {//定义界面背景
    Row(){//定义一行
      Column(){//定义一列
        Text(this.message3)//输出文本，调用前方定义的message3
          .fontSize(50)//文本字体
          .fontWeight(FontWeight.Bold)//文本加粗

        //添加按钮
        Button(){//创建按钮
          Text('Back')//给按钮命名为Back
            .fontSize(30)//按钮的文本大小
            .fontWeight(FontWeight.Bold)//按钮的文本加粗
        }//结束按钮中的Text的定义
        .type(ButtonType.Capsule)//定义按钮的形状是胶囊型
        .margin({//设置按钮的位置
          top:20//按钮的上边距离其他元素（即message3）20像素的距离
        })//margin的右括号
        .backgroundColor('#0D9FFB')//按钮的背景颜色
        .width('40%')//按钮的宽度
        .height('5%')//按钮的高度
      }//结束列的定义
      .width('100%')//定义列宽为整个屏幕的100%（即占满整个屏幕）
    }//结束行的定义
    .height('100%')//定义行高为整个屏幕的100%（即占满整个屏幕）
  }//结束界面的定义
}//结束结构体的定义
```
![alt text](image-7.png)
### 4.给第一个页面的静态按钮添加动态功能
* * * * 
```typescript{.line-numbers}
import { router } from '@kit.ArkUI';//导入跳转模块中的router对象
import { BusinessError } from '@kit.BasicServicesKit';//导入模块中的Business

@Entry//定义入口点
@Component//定义这是一个组件
struct Step4 {//定义名为Step4的结构体
  @State message: string = 'Fujian Agriculture And Forestry University';//定义静态变量message

  build() {//定义界面背景
    Row() {//定义一行
      Column() {//定义一列
        Text(this.message)//输出文本，文本内容调用前面定义的message
          .fontSize(30)//定义文本的大小
          .fontWeight(FontWeight.Bold)//文本加粗

        //添加按钮
        Button() {//定义按钮
          Text('Next')//定义按钮里面的文本内容
            .fontSize(30)//定义按钮文本的大小
            .fontWeight(FontWeight.Bold)//文本加粗
        }//结束按钮文本的定义
        .type(ButtonType.Circle)//定义按钮的形状
        .margin({//定义按钮的位置
          top: 20//按钮的上边距离上一个元素的位置有20像素
        })//结束按钮位置的定义
        .backgroundColor('#0D9FFB')//定义按钮的背景颜色
        .height("30%")//定义按钮的高
        .width("30%")//定义按钮的宽

        //按钮绑定onclick事件，点击时跳转
        .onClick(() => {//为按钮绑定点击事件
          console.info(`Succeeded in clicking the 'Next' button.`)//控制台记录按钮被点击

          //跳转到第二页
          router.pushUrl({//router.pushUrl异步方法跳转到指定页面
            url: 'pages/Step5'//跳转到名为Step5的页面
          })
            .then(() => {//一个Promise成功回调函数
              console.info('Succeeded in jumping to the second page')//控制台记录成功跳转
            })//结束then函数的定义
            .catch((err: BusinessError) => {//一个Promise失败回调函数，跳转失败时捕获错误
              console.error(`Failed to jump to the secong page.Code is ${err.code},message is ${err.message}`)
              //控制台记录跳转失败，输出错误日志
          })//结束catch方法
        })//结束onClick方法
      }//结束列的内部定义
      .width("100%")//定义列的宽度（即占满行）
    }//结束行的内部定义
    .height("100%")//定义行的高度（即占满屏幕）
  }//结束屏幕的定义
}//结束结构体的定义
```
![alt text](image-1.png)
### 5.给第二个页面的静态按钮添加动态功能
* * * * 
```typescript{.line-numbers}
import {router} from '@kit.ArkUI';//导入模块中的router对象
import { BusinessError } from '@kit.BasicServicesKit';//导入模块中的BusinessError类

@Entry//定义入口点
@Component//定义这是一个组件
struct Step5 {//定义结构体
  @State message: string = 'XiaoQian3225706038';//定义静态变量message

  build() {//定义界面
    Row(){//定义一行
      Column() {//定义一列
        Text(this.message)//定义文本，并调用前面定义的message以输出
          .fontSize(30)//文本大小
          .fontWeight(FontWeight.Bold)//文本加粗

        Button() {//定义按钮
          Text('Back')//定义按钮中的文本
            .fontSize(30)//定义大小
            .fontWeight(FontWeight.Bold)//文本加粗
        }//结束按钮的定义
        .type(ButtonType.Circle)//定义按钮形状
        .margin({//定义按钮的位置
          top: 20//按钮的上边距离上一元素20像素的距离
        })//结束按钮位置的定义
        .backgroundColor('0D9FF8')//定义按钮的背景颜色
        .height('30%')//定义按钮的高
        .width('30%')//定义按钮的宽

        
        .onClick(() => {//按钮绑定onClick事件，点击时进行跳转
          console.info(`Succeeded in clicking the 'Back' button.`)//控制台记录按钮被点击
          //使用try...catch块来捕获返回页面过程中可能会遇到的错误
          try{//尝试返回到第一个页面
            router.back()//调用router对象的back方法，返回到Step4页面
            console.info(`Succeeded in returning to the first page.`)//控制台记录成功返回
          } catch(err) {//出现错误时进行捕获
            let code = (err as BusinessError).code;//将捕获的错误对象类型设为BusinessError，并获取错误的代码
            let message = (err as BusinessError).message;//将捕获的错误对象类型设置为BusinessError，并获取错误的信息
            console.error(`Failed to return to the first page.Code is ${code},message is ${message}`)//控制台记录返回错误
          }//try...catch块完成
        })//结束onClick事件的定义
      }//结束列的定义
      .width('100%')//设置列宽
    }//结束行的定义
    .height('100%')//设置行高

  }//结束界面的定义
}//结束结构体的定义
```
![alt text](image-2.png)
## 三、控制台信息
* 正常进行跳转时
![alt text](image-3.png)
* 当url路径改为不存在的页面名时
![alt text](image-4.png)
> I (Info)：信息，表示一般的信息记录。
> W (Warning)：警告，表示某些非致命问题，可能需要关注，但程序仍可继续运行。
> E (Error)：错误，表示程序运行过程中遇到的严重问题，通常会导致程序无法继续正常运行。

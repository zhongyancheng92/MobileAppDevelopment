# 实验一
## 1. 页面一 index 

```javascript{.line-numbers}

import { router } from '@kit.ArkUI';
// 导入 ArkUI 模块中的 router 对象，用于页面路由和导航。

import { BusinessError } from '@kit.BasicServicesKit';
// 导入 BasicServicesKit 模块中的 BusinessError 类型，用于处理业务错误。

@Entry
  // 使用 @Entry 装饰器，表示当前组件是应用的入口页面。

@Component
  // 使用 @Component 装饰器，表示当前是一个自定义组件。

struct Index {
  // 定义名为 Index 的结构体（组件）。

  @State message: string = 'Long Live';
  // 使用 @State 装饰器定义一个响应式状态变量 message，初始值为 'Long Live'。

  build() {
    // 定义 build 方法，用于描述组件的 UI 结构。

    Row() {
      // 创建一个行布局容器。

      Column() {
        // 创建一个列布局容器。

        Text(this.message)
          // 创建一个文本组件，显示 this.message 的内容。

          .fontSize(50)
            // 设置文本字体大小为 50。

          .fontWeight(FontWeight.Bold);
        // 设置文本字体粗细为粗体。

        // 添加按钮，以响应用户点击。
        Button() {
          // 创建一个按钮组件。

          Text("Next")
            // 在按钮内部创建一个文本组件，显示 "Next"。

            .fontSize(30)
              // 设置按钮文本字体大小为 30。

            .fontWeight(FontWeight.Bold);
          // 设置按钮文本字体粗细为粗体。
        }
        // 结束 Button 组件的定义。

        .type(ButtonType.Capsule)
        // 设置按钮类型为胶囊形状。

        .margin({
          // 设置按钮的外边距。

          top: 20
          // 设置按钮顶部外边距为 20。
        })
        // 结束 margin 方法的调用。

        .backgroundColor('#806D9E')
        // 设置按钮背景颜色为 '#806D9E'。

        .width('40%')
        // 设置按钮宽度为父容器宽度的 40%。

        .height('10%')
        // 设置按钮高度为父容器高度的 10%。

        // 跳转按钮绑定到 onclick 事件，点击时跳转到第二页。
        .onClick(() => {
          // 为按钮绑定点击事件。

          console.info('Succeeded in clicking the ‘Next’ button');
          // 在控制台打印日志，表示按钮点击成功。

          // 跳转到第二页。
          router.pushUrl({ url: 'pages/Page1' })
            // 调用 router.pushUrl 方法，跳转到 'pages/Page1' 页面。

            .then(() => {
              // 跳转成功后的回调函数。

              console.info('Succeeded in jumping to the second page.');
              // 在控制台打印日志，表示跳转成功。
            })
              // 结束 then 方法的回调函数。

            .catch((err: BusinessError) => {
              // 跳转失败后的回调函数。

              console.error('failed to jump to the second page. code is ${err.code}, message is ${err.message}');
              // 在控制台打印错误日志，包含错误代码和错误信息。
            });
          // 结束 catch 方法的回调函数。
        });
        // 结束 onClick 事件处理函数。
      }
      // 结束 Column 组件。

      .width('100%')
      // 设置列布局容器的宽度为父容器的 100%。
    }
    // 结束 Row 组件。

    .height('100%')
    // 设置行布局容器的高度为父容器的 100%。
  }
  // 结束 build 方法。
}
// 结束 Index 组件的定义。
```

## 2. 页面二 second

```javascript{.line-numbers}

import { router } from '@kit.ArkUI'; 
// 导入 ArkUI 模块中的 router 对象，用于页面路由和导航。

@Entry 
// 使用 @Entry 装饰器，表示当前组件是应用的入口页面。

@Component 
// 使用 @Component 装饰器，表示当前是一个自定义组件。

struct Page1 { 
  // 定义名为 Page1 的结构体（组件）。

  @State message: string = 'hi babe'; 
  // 使用 @State 装饰器定义一个响应式状态变量 message，初始值为 'hi babe'。

  build() { 
    // 定义 build 方法，用于描述组件的 UI 结构。

    Row() { 
      // 创建一个行布局容器。

      Column() { 
        // 创建一个列布局容器。

        Text(this.message) 
          // 创建一个文本组件，显示 this.message 的内容。

          .fontSize(50) 
          // 设置文本字体大小为 50。

          .fontWeight(FontWeight.Bold); 
          // 设置文本字体粗细为粗体。

        ////添加按钮，以响应用户点击
        Button() { 
          // 创建一个按钮组件。

          Text('Back') 
            // 在按钮内部创建一个文本组件，显示 'Back'。

            .fontSize(30) 
            // 设置按钮文本字体大小为 30。

            .fontWeight(FontWeight.Bold); 
            // 设置按钮文本字体粗细为粗体。
        } 
        // Button 组件定义结束。

        .type(ButtonType.Capsule) 
        // 设置按钮类型为胶囊形状。

        .margin({ 
          // 设置按钮的外边距。

          top: 20 
          // 设置按钮顶部外边距为 20。
        }) 
        // margin 属性设置结束。

        .backgroundColor('#D4E5EF') 
        // 设置按钮背景颜色为 '#D4E5EF'。

        .width('40%') 
        // 设置按钮宽度为父容器宽度的 40%。

        .height('10%') 
        // 设置按钮高度为父容器高度的 10%。

        // 返回按钮绑定到 onclick 事件，点击时跳转到第一页。
        .onClick(() => { 
          // 为按钮绑定点击事件。

          console.info('Succeeded in clicking the ‘Back’ button'); 
          // 在控制台打印日志，表示按钮点击成功。

          try { 
            // 尝试执行以下代码块。

            // 返回第一页。
            router.back(); 
            // 调用 router.back 方法，返回上一页。

            console.info('Succeeded in returning to the first page.'); 
            // 在控制台打印日志，表示返回上一页成功。
          } catch (err) { 
            // 捕获并处理异常。

            console.error('failed to return to the first page. code is ${code}, message is ${message}'); 
            // 在控制台打印错误日志，包含错误代码和错误信息。
          } 
          // try-catch 代码块结束。
        }) 
        // onClick 事件绑定结束。
      } 
      // Column 组件定义结束。

      .width('100%') 
      // 设置列布局容器的宽度为父容器的 100%。
    } 
    // Row 组件定义结束。

    .height('100%') 
    // 设置行布局容器的高度为父容器的 100%。
  } 
  // build 方法定义结束。
} 
// Page1 结构体（组件）定义结束。
```
## 四、运行效果

**页面一**
![Index](Index.png)
**页面二**
![Page1](Page1.png)
## 实验一 实现页面的简单跳转

### 1. Index.ets

```typescript {.line-numbers}
// 导入ArkUI的路由模块
import { router } from '@kit.ArkUI';
// 导入基础服务错误处理模块
import { BusinessError } from '@kit.BasicServicesKit';

// @Entry 装饰器表示当前组件是应用入口组件
@Entry
// @Component 表示这是一个自定义组件
@Component

// 定义名为 Index 的结构体组件
struct Index {
  // @State 装饰器声明响应式变量message，用于维护组件状态
  @State message: string = 'First_Page';// 初始化页面标题为“First_Page”
  // build 方法用于描述UI布局
  build() {
    // Row 方法进行横向布局
    Row(){
      // Column 纵向布局
      Column(){
        // 文本组件显示message变量内容“First_Page”
        Text(this.message)
          // 设置字体大小为50
          .fontSize(50)
          // 对字体进行加粗
          .fontWeight(FontWeight.Bold)
        // 设置按钮组件
                Button() {//添加按钮，以响应用户点击
          Text('登录')//在按钮上显示Next
            .fontSize(30)//设置字号大小为30
            .fontWeight(FontWeight.Bold) //字体加粗
        }//button组件的右括号
        .type(ButtonType.Capsule) //按钮形状类型为胶囊型
        .margin({// 设置按钮的外边距
          top: 20//这里设置了顶部外边距为 20
        })//margin方法的右括号
        .backgroundColor('#0D9FFB') //设置颜色
        .width('40%') //宽度为40%
        .height('5%') //高度为5%
        .onClick(() => {//跳转按钮绑定onClick事件，点击时跳转到第二页
       console.info(`Succeeded in clicking the 'next' button.`)//向控制台输出这句话
          //跳转到第二页
          router.pushUrl({url:'pages/Second'}).then(()=>{//使用pushUrl 方法跳转到含有目标页面url的对象，跳转成功时的回调函数，在控制台输出信息表示成功跳转到第二页
            console.info(`Succeeded in jumping to the second page.`)//向控制台输出这句话
        }).catch((err: BusinessError) => { // 跳转失败时的回调函数，捕获错误信息
          console.error(`Failed to jump to the second page.Code is${err.code},message is ${err.message}`)//在控制台输出错误信息
        })//catch方法的右括号
      })//onClick方法的右括号
      }//Column组件的右括号
      .width('100%')//设置column组件的宽度是总宽度的100%
    }//row组件的右括号
    .height('100%')//设置row组件的高度是总宽度的100%
  }//build方法的右括号
}//struct的右括号
```
### 2.Second.ets
```typescript {.line-numbers}
// 导入ArkUI的路由模块
import { router } from '@kit.ArkUI';
// 导入基础服务错误处理模块
import { BusinessError } from '@kit.BasicServicesKit';

// @Entry 装饰器表示当前组件是应用入口组件
@Entry
  // @Component 表示这是一个自定义组件
@Component
  // 定义名为 Second 的结构体组件
struct Second {
  // @State 装饰器声明响应式变量message，用于维护组件状态
  @State message: string = 'Hi there';// 初始化页面标题为“Hi there”
  // build 方法用于描述UI布局
  build() {//调用build方法来创建和布局界面元素
    Row(){//创建一个row组件，在水平方向上排列子组件
      Column(){//在垂直方向上排列子组件
        Text(this.message)//创建一个test组件，内容是message的值
        .fontSize(50)//将文本大小设置为50
        .fontWeight(FontWeight.Bold)//将字号加粗
        Button(){//添加按钮
          Text('Back')//在按钮上显示back
            .fontSize(30)//字号为30
            .fontWeight(FontWeight.Bold)//字号加粗
        }//button函数的右括号
        .type(ButtonType.Capsule)//按钮为胶囊型
        .margin({//margin函数设置外边距
          top:20//按钮外边距上边为20像素
        })//margin函数的右括号
        .backgroundColor('#0D9FFB')//设置颜色
        .width('40%')//宽度为40%
        .height('5%')//高度为5%
        .onClick(()=>{//返回按钮绑定onClick事件，点击按钮时返回第一页
                    console.info(`Succeeded in clicking the 'back' button.`)//向控制台输出这句话
          try{//此函数完成页面跳转，用于返回第一页
            router.back()//调用router.back()函数，返回上一页
            console.info(`Succeeded in returning to the first page.`)//向控制台输出这句话
          }catch(err){//如果页面跳转异常则会进入catch块
            let code =(err as BusinessError).code;//将捕获到的错误对象err强制转化为BusinessError类型，然后获取错误代码
            let message=(err as BusinessError).message;//将捕获到的错误对象err强制转化为BusinessError类型，然后获取错误消息
            console.error(`Failed to return to the first page.Code is ${code},message is ${message}`)//向控制台发出信息，信息包含错误代码和错误信息，表示返回上一页失败
          }//catch块的右括号
        })//onClick组件的右括号
      }//column函数的右括号
      .width('100%')//宽度设为父容器的100%
    }//row组件的右括号
    .height('100%')//长度设为父容器的100%
  }//build方法的右括号
}//struct的右括号
```
### 页面1预览
<img src="./页面一.png" >

#### 页面2预览
<img src="./页面二.png" >
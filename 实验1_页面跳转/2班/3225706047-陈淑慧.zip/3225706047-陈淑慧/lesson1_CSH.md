# 实验一：实现页面跳转功能
## 一、实验任务
- 实现一个简单的 HarmonyOS 应用，包含两个页面：
  
  - Index 页面：显示文本 "这是第一个页面" 和一个 "下一页" 按钮，点击按钮跳转到 Second 页面。
  
  - Second 页面：显示文本 "成功跳转到第二个页面" 和一个 "返回" 按钮，点击按钮返回到 Index 页面。


## 二、页面代码与注释
- Index.ets
```typescript {.line-numbers}
// 导入ArkUI框架中的路由模块，用于页面跳转功能
import { router } from '@kit.ArkUI';
// 导入BasicServicesKit中的BusinessError类型，用于捕获和处理路由跳转中的错误
import { BusinessError } from '@kit.BasicServicesKit';

// @Entry注解表示这是应用的入口组件，一个应用必须有一个入口
@Entry
// @Component注解表示这是一个自定义组件，定义了页面的结构和行为
@Component
// 定义Index结构体，这个页面的主组件
struct Index {
  // @State注解定义一个状态变量message，初始值为'这是第一个页面'，用于动态更新UI
  @State message: string = '这是第一个页面';
  // build方法定义组件的UI结构，是组件的核心渲染函数
  build() {
    // Row组件表示水平布局，作为页面的根布局容器
    Row() {
      // Column组件表示垂直布局，用于垂直排列子组件
      Column(){
        // Text组件显示文本内容，这里显示message状态变量的值
        Text(this.message)
          // 设置文本字体大小为40
          .fontSize(40)
          // 设置文本字体粗细为粗体
          .fontWeight(FontWeight.Bold)
          // 设置文本水平居中对齐
          .textAlign(TextAlign.Center)
        // Button组件定义一个按钮
        Button(){
          // Button内部的Text组件，显示按钮上的文字'下一页'
          Text('下一页')
            // 设置按钮文本字体大小为25
            .fontSize(25)
            // 设置按钮文本字体粗细为粗体
            .fontWeight(FontWeight.Bold)
        }// Button的结束括号，对应Button()的开始
        // 设置按钮类型为胶囊形状（Capsule）
        .type(ButtonType.Capsule)
        // 设置按钮的外边距，顶部距离为20
        .margin({
          top: 30 // 顶部外边距的具体值
        })// margin属性的结束括号
        // 设置按钮背景颜色为紫色（#d7aefb）
        .backgroundColor('#d7aefb')
        // 设置按钮宽度为父容器的40%
        .width('40%')
        // 设置按钮高度为父容器的8%
        .height('8%')

        // 定义按钮的点击事件处理函数
        .onClick(() => {
          // 在控制台输出信息，表示成功点击了"下一页"按钮
          console.info('Succeeded in clicking the "下一页" button.')
          // 调用router.pushUrl方法进行页面跳转，跳转到'pages/Second'页面
          router.pushUrl({url: 'pages/Second' })
            // then方法处理跳转成功后的回调
            .then(() => {
              // 在控制台输出信息，表示成功跳转到第二个页面
              console.info('Succeeded in jumping to the second page.')
            })// then回调函数的结束括号
            // catch方法捕获跳转失败时的错误
            .catch((err: BusinessError) => {
              // 在控制台输出错误信息，包括错误码和错误消息
              console.error('Failed to jump to the second page. Code is${err.code}, message is $(err.message}')
            })// catch回调函数的结束括号
        })// onClick事件处理函数的结束括号
      }// Column组件的结束括号
      // 设置Column宽度为父容器的100%，占满Row的宽度
      .width('100%')
    }// Row组件的结束括号
    // 设置Row高度为父容器的100%，占满整个屏幕高度
    .height('100%')
  }// build方法的结束括号，对应build()的开始
}// Index结构体的结束括号，对应struct Index的开始
```
- Second.ets
```typescript {.line-numbers}
// 导入ArkUI框架中的路由模块，用于页面导航功能
import { router } from '@kit.ArkUI';
// 导入BasicServicesKit中的BusinessError类型，用于处理路由操作的错误
import { BusinessError } from '@kit.BasicServicesKit';
// @Entry注解表示这是应用的入口组件，一个应用必须有一个入口
@Entry
  // @Component注解表示这是一个自定义组件，定义了这页面的结构和行为
@Component
  // 定义Second结构体，这是这个页面的主组件
struct Second {
  // @State注解定义一个状态变量message，初始值为'成功跳转到第二个页面'，用于动态更新UI
  @State message: string = '成功跳转到第二个页面';

  // build方法定义组件的UI结构，是组件的核心渲染函数
  build() {
    // Row组件表示水平布局，作为页面的根布局容器
    Row(){
      // Column组件表示垂直布局，用于垂直排列子组件
      Column() {
        // Text组件用于显示文本内容，这里显示message状态变量的值
        Text(this.message)
          // 设置文本字体大小为40
          .fontSize(40)
            // 设置文本字体粗细为粗体
          .fontWeight(FontWeight.Bold)
          // 设置文本水平居中对齐
          .textAlign(TextAlign.Center)
        // Button组件定义一个按钮
        Button() {
          // Button内部的Text组件，显示按钮上的文字'返回'
          Text('返回')
            // 设置按钮文本字体大小为25
            .fontSize(25)
              // 设置按钮文本字体粗细为粗体
            .fontWeight(FontWeight.Bold)
        }// Button的结束括号，对应Button()的开始
        // 设置按钮类型为胶囊形状（Capsule）
        .type(ButtonType.Capsule)
        // 设置按钮的外边距，顶部距离为20
        .margin({
          top: 30 // 顶部外边距的具体值
        })// margin属性的结束括号
        // 设置按钮背景颜色为紫色（#d7aefb）
        .backgroundColor('#d7aefb')
        // 设置按钮宽度为父容器的40%
        .width('40%')
        // 设置按钮高度为父容器的8%
        .height('8%')
        // 定义按钮的点击事件处理函数
        .onClick(() => {
          // 在控制台输出信息，表示成功点击了"返回"按钮
          console.info('Succeeded in clicking the "Back" button.')
          // 使用try-catch块处理页面返回操作
          try{
            // 调用router.back()方法返回上一个页面（即Index页面）
            router.back()
            // 在控制台输出信息，表示成功返回到第一个页面
            console.info('Succeeded in returning to the first page.')
            // try块的结束括号
          }catch(err){
            // 将错误对象转换为BusinessError类型，获取错误码
            let code = (err as BusinessError).code;
            // 获取错误消息
            let message = (err as BusinessError).message;
            // 在控制台输出错误信息，包括错误码和错误消息
            console.error('Failed in return to the first page. Code is ${code}, message is $(message}')  
          }// catch块的结束括号
        })// onClick事件处理函数的结束括号
      }// Column组件的结束括号，对应Column()的开始
      // 设置Column宽度为父容器的100%，占满Row的宽度
      .width('100%')
    }// Row组件的结束括号，对应Row()的开始
    // 设置Row高度为父容器的100%，占满整个屏幕高度
    .height('100%')
  }// build方法的结束括号，对应build()的开始
}// Second结构体的结束括号，对应struct Second的开始
```
## 三、结果展示
- 第一个页面
<img src="第一个页面.png" width="400" height="450" alt="alt text">
<img src="第二个页面.png" width="400" height="450" alt="alt text">

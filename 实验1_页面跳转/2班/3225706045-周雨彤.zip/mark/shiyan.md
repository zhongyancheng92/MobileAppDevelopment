## 实验一
#### 一、代码部分
##### 1.第一页
```typescript{.line-numbers}
//从ArkUI工具包中导入路由模块
import { router } from '@kit.ArkUI';
//从基础服务工具包中导入错误类
import { BusinessError } from '@kit.BasicServicesKit';
//使用@Entry装饰器定义页面组件
@Entry
//使用@Component装饰器定义页面组件
@Component
//使用struct定义index结构体
struct Index {
  //使用@state装饰器定义一个响应式状态变量messgae，设置初始值为“Hello World”
  @State message: string = 'Hello World';
  //使用build方法构建组件的UI
  build() {
    //使用Row组件创建一个水平布局容器
    Row(){
      //使用colum组件创建一个垂直布局容器
      Column(){
        //使用text组件显示message状态变量的值
        Text(this.message)
          //设置字体大小为50
          .fontSize(50)
          //设置字体加粗
          .fontWeight(FontWeight.Bold)
        //添加按钮
        Button(){
          //按钮内显示文本“next”
          Text('Next')
            //设置字体大小为30
            .fontSize(30)
            //设置字体加粗
            .fontWeight(FontWeight.Bold)
        //与button方法匹配
        }
        //设置按钮为胶囊形
        .type(ButtonType.Capsule)
        //设置按钮距
        .margin({
          //设置上边距为20
          top:20 })
        //设置按钮的背景颜色为蓝色
        .backgroundColor('#0D9FFB')
        //设置按钮宽度为父容器的40%
        .width('40%')
        //设置按钮高度为父容器的5%
        .height('5%')
        //绑定onclick事件
        .onClick(() => {
          //在控制台输出点击成功的信息
          console.info('Succeeded in clicking the ‘Next’ button.')
          //跳转第二页面
          router.pushUrl({ url: 'pages/Second' }).then(() => {
            //跳转成功后在控制态输出成功信息
            console.info('Succeeded in jumping to the second page.')})
            //设置err是BusinessError类型
            .catch((err: BusinessError) => {
              //跳转失败后在控制态输出失败信息和错误代码信息
              console.info(`Failed to jump to the second page.Code is ${err.code},message is ${err.message}`)          })
        //与.onClick方法匹配
        })
        //Colum组件结束
      }
      //设置column组件的宽度为父容器的100%
      .width('100%')
    //row组件结束
    }
    //设置row组件的高度为父容器的100%
    .height('100%')
  //build方法结束
  }
//类定义结束
}
```
##### 2.第二页
```typescript{.line-numbers}
//从ArkUI工具包中导入路由模块
import { router } from '@kit.ArkUI';
//从基础服务工具包中导入错误类
import { BusinessError } from '@kit.BasicServicesKit';
//使用@Entry装饰器定义页面组件
@Entry
  //使用@Component装饰器定义页面组件
@Component
  //使用struct定义index结构体
struct Second {
  //使用@state装饰器定义一个响应式状态变量messgae，设置初始值为“Hi there”
  @State message: string = 'Hi there';
  //使用build方法构建组件的UI
  build() {
    //使用Row组件创建一个水平布局容器
    Row(){
      //使用colum组件创建一个垂直布局容器
      Column(){
        //使用text组件显示message状态变量的值
        Text(this.message)
          //设置字体大小为50
          .fontSize(50)
            //设置字体加粗
          .fontWeight(FontWeight.Bold)
        //添加按钮
        Button(){
          //按钮内显示文本“next”
          Text('Back')
            //设置字体大小为30
            .fontSize(30)
              //设置字体加粗
            .fontWeight(FontWeight.Bold)
        //与button方法匹配
        }
        //设置按钮为胶囊形
        .type(ButtonType.Capsule)
        //设置按钮距
        .margin({
          //设置上边距为20
          top:20 })
        //设置按钮的背景颜色为蓝色
        .backgroundColor('#0D9FFB')
        //设置按钮宽度为父容器的40%
        .width('40%')
        //设置按钮高度为父容器的5%
        .height('5%')
        //返回按钮绑定
        .onClick(() => {
          //在控制台输出返回成功的信息
          console.info('Succeeded in clicking the ‘Back’ button.')
          //try语句块
          try{
            //返回第一页，此函数完成页面跳转
            router.back()
            // 如果页面返回成功，则在控制台输出成功信息
            console.info('Succeeded in returning to the first page.')
          // 如果在尝试页面返回时捕获到错误，则进入此catch块
          }catch(err){
            // 获取错误码
            let code = (err as BusinessError).code;
            // 获取错误信息
            let message = (err as BusinessError).message;
            // 在控制台输出失败信息和错误详情
            console.info(`Failed to return to the first page. Code is ${code}, message is ${message}`)
          //与catch方法匹配
          }
        //与.onClick方法匹配
        })
      //Colum组件结束
      }
      //设置column组件的宽度为父容器的100%
      .width('100%')
    //row组件结束
    }
    //设置row组件的高度为父容器的100%
    .height('100%')
  //build方法结束
  }
//类定义结束
}
```
#### 二、演示图片
##### 1.页面一
![1](first.png)
##### 2.页面二
![2](second.png)
# 实验三报告

> 学号：3225706052
> 
> 姓名：潘乐萱
> 
> 指导老师：张凯斌
> 
> 实验日期：2025-03-25

## 一、实验目的

- 复习软件工程的基本概念和方法论；
  - 软件生命周期与开发方法论；
    - 结构化分析与设计（SAD）
    - 面向对象分析与设计（OOAD）
- 掌握OOAD与UML图的对应关系；

  - 注意：UML图只是OOAD中的一部分（代码相关的部分），并不是OOAD的全部。例如：
    - 需求分析除了UML图外，还有文档说明；
    - 总体设计除了UML图外，还有UI设计、数据库设计等；
    - 详细设计除了UML图外，还有算法实现（流程图、N-S图、伪代码）、UI的具体实现、数据库的具体实现等；
- 完成教科书中关系数据库实例的UML建模练习；

## 二、实验内容

- 阅读教科书的第9章“数据管理”的第9.4节“关系数据库的开发”；
- 根据理论课所讲内容和软件工程的相关概念，完成教科书上关系数据库实例的UML建模练习；

## 三、实验要求

- 需求分析：完成用例图和用例规约；
- 总体设计：完成类图（静态视图）和活动图（动态视图）；
- 详细设计：完成详细类图和包图；
- 撰写并提交实验报告；


## 四、实验步骤

### 1. 需求分析

#### 1.1 用例图

![alt text](用例图_new.png)

#### 1.2 用例规约

  

| 字段 | 内容 |
| ---- | ------ |
| 用例名 | 用户增加/删除/修改/查询账单信息 | 
| 执行者 | 具有财务权限的用户 | 
| 前置条件 | 用户登录成功，账单模板已加载 | 
| 触发事件 | 用户提交包含信息的账单增加/删除/修改/查询表单 | 
| 主成功场景 | 用户提交需要增加/删除/修改/查询的信息时验证必填字段，无误显示“添加/删除/修改/查询finished”信息 | 
| 扩展场景 | 无 | 
| 最小保证 | 系统运行失败，将其写入日志文件 | 
| 后置条件 | 更新用户账单计数，触发通知工作流 | 
| 优先级 | 高 | 
| 频度 | 每天 | 
| 输入 | id号(number)、账单类型(number)、文本(str)、数量(number)| 
| 输出 | 无 | 
| 异常 | 输入信息格式错误  | 
| 附加信息 | 无 | 

### 2. 总体设计

#### 2.1 类图（静态视图）

![alt text](类图.png)

#### 2.2 活动图（动态视图）

![alt text](活动图_new.png)

### 3. 详细设计

#### 3.1 详细类图

![alt text](详细类图.png)

#### 3.2 包图

![alt text](包图.png)
### 4. 编码（实验四的内容，提交实验三报告时需删除此部分）

#### 4.1 代码实现
工程目录:
![alt text](工程目录-1.png)


index.ets
```typescript {.line-numbers}
// 导入AccountData接口，用于定义账户数据类型
import {AccountData} from '../common/database/table/AccountInterface';
import {AccountTable} from '../common/database/table/AccountInterface';
// 导入AccountUsers类，用于操作账户用户数据库
import AccountUsers from '../common/database/AccountUsers';
import { relationalStore } from '@kit.ArkData';
// 使用@Entry装饰器标记页面入口组件
@Entry
  // 使用@Component装饰器定义组件
@Component
  // 定义名为Index的结构体组件
struct Index {
  // 使用@State装饰器声明响应式状态变量message，初始值为'Hello World'
  @State message: string = 'Hello World';

  // 初始化AccountUsers实例，传入数据库初始化成功的回调函数
  private accountUsers = new AccountUsers(() => {
    console.info("Database initialized successfully"); // 数据库初始化成功时在控制台打印信息
  });

  // 定义组件构建方法
  build() {
    // 创建Row布局容器，设置高度为100%
    Row(){
      // 创建Column布局容器，设置宽度为100%
      Column(){
        // 创建Text组件显示message状态，设置字体大小和粗细
        Text(this.message).fontSize(50).fontWeight(FontWeight.Bold)

        // 增加按钮
        Button(('增加'),{ type:ButtonType.Capsule}) // 设置按钮类型为胶囊样式
          .width(140).fontSize(40).fontWeight(FontWeight.Medium).margin({top:20,bottom:20}) // 设置按钮样式
          .onClick(()=>{ // 点击事件处理
            // 定义要插入的新账户数据（示例数据）
            let newAccount:AccountData={id:0,accountType:0,typeText:'apple',amount:0};
            // 调用insertData方法插入数据，传入成功回调
            this.accountUsers.insertData(newAccount,()=>{
              console.info("insert succeed") // 插入成功时在控制台打印信息
            })
          })

        // 查询按钮
        Button(('查询'),{ type:ButtonType.Capsule})
          .width(140).fontSize(40).fontWeight(FontWeight.Medium).margin({top:20,bottom:20})
          .onClick(()=>{
            // 调用query方法查询数据，参数0可能是查询条件或表名
            this.accountUsers.query(0,(result:AccountData[])=>{
              this.message = JSON.stringify(result); // 将查询结果转为JSON字符串并更新message状态
              console.info("insert succeed") // 这里应该是查询成功的提示，但文本写成了insert（可能是笔误）
            },true) // 最后一个参数可能是是否启用异步等配置
          })

        // 修改按钮
        Button(('修改'),{ type:ButtonType.Capsule})
          .width(140).fontSize(40).fontWeight(FontWeight.Medium).margin({top:20,bottom:20})
          .onClick(()=>{
            // 定义要更新的账户数据（示例数据）
            let newAccount:AccountData={id:1,accountType:1,typeText:'banana',amount:1};
            // 调用updateData方法更新数据，传入成功回调
            this.accountUsers.updateData(newAccount,()=>{
              console.info("insert succeed") // 更新成功提示（同样存在文本问题）
            })
          })

        // 删除按钮
        Button(('删除'),{ type:ButtonType.Capsule})
          .width(140).fontSize(40).fontWeight(FontWeight.Medium).margin({top:20,bottom:20})
          .onClick(()=>{
            // 定义要删除的账户数据（示例数据）
            let newAccount:AccountData={id:2,accountType:1,typeText:'banana',amount:1};
            // 调用deleteData方法删除数据，传入成功回调
            this.accountUsers.deleteData(newAccount,()=>{
              console.info("insert succeed") // 删除成功提示（文本问题）
            })
          })
      }.width('100%') // 设置Column容器宽度为100%
    }.height('100%') // 设置Row容器高度为100%
  }
}
```
CommonConstants.ets：
```typescript {.line-numbers}
// 导入ArkData关系型存储模块中的Store配置相关功能
import { relationalStore } from '@kit.ArkData'
// 从本地路径导入AccountTable表结构接口定义
import { AccountTable } from '../database/table/AccountInterface'

// 导出默认类CommonConstants（通用常量类）
export default class CommonConstants {
  // 数据库配置常量（静态只读属性，全大写命名规范）
  static readonly STONE_CONFIG: relationalStore.StoreConfig = {
    // 配置项1：数据库文件名称（SQLite默认会生成.db文件）
    name: 'database.db',
    // 配置项2：设置安全等级为S1（需参考ArkData文档确认具体安全策略）
    securityLevel: relationalStore.SecurityLevel.S1
  }

  // 账户表结构常量（静态只读属性，使用AccountTable接口约束结构）
  static readonly ACCOUNT_TABLE: AccountTable = {
    // 表名称（SQLite表名区分大小写）
    tableName: 'accountTable',
    // 建表SQL语句（使用IF NOT EXISTS避免重复创建）
    sqlCreate: 'CREATE TABLE IF NOT EXISTS accountTable(' +
      'id INTEGER PRIMARY KEY AUTOINCREMENT,' +  // 自增主键
      'accountType INTEGER,' +                  // 账户类型数字标识
      'typeText TEXT,' +                        // 账户类型文本描述
      'amount INTEGER)',                        // 账户金额数值
    // 字段列表（与SQL语句中的列顺序保持一致）
    columns: ['id', 'accountType', 'typeText', 'amount']
  }
}
```
AccountInterface.ets:
```typescript {.line-numbers}
export interface AccountData{
  //interface接口，声明表中有的东西，后续不再变动，不要进行赋初值。
  // 但有时不知道后续是否进行改动，所以使用class，对Table类的定义（一个Table项）,要进行赋初值
  id:number,// 字段1：账户唯一标识符（数字类型，由数据库自增生成）
  accountType:number,// 字段2：账户类型数字编码
  typeText:string,// 字段3：账户类型文本描述
  amount:number// 字段4：账户金额数值
}//初始化暂时赋值对属性来说不可能有意义的值-1
//即在SQL的表中有字段id、accountType、typeText、amount
export interface AccountTable{
  tableName:string,// 属性1：数据库表名称
  sqlCreate:string,// 属性2：建表SQL语句
  columns:Array<string>// 属性3：字段列表
}
```
RdbUtil.ets:
```typescript {.line-numbers}
/ 导入ArkData关系型数据库模块
import { relationalStore } from '@kit.ArkData';
// 导入通用常量配置模块
import CommonConstants from "../constants/CommonConstants";

// 定义数据库工具类（单例模式推荐？当前为普通类）
export default class RdbUtil {
  // 数据库连接实例（RdbStore类型或null，初始化为null）
  rdbStore: relationalStore.RdbStore | null = null;
  // 目标表名称（字符串类型，初始化为空字符串）
  tableName: string = '';
  // 建表SQL语句（字符串类型，初始化为空字符串）
  sqlCreateTable: string = '';
  // 字段列表（字符串数组类型，初始化为空数组）
  columns: Array<string> = [];

  // 构造函数（创建类实例时自动执行）
  constructor(
    tableName: string,         // 注入表名称
    sqlCreateTable: string,    // 注入建表语句
    columns: Array<string>     // 注入字段列表
  ) {
    // 初始化实例属性（参数赋值给类属性）
    this.tableName = tableName;
    this.sqlCreateTable = sqlCreateTable;
    this.columns = columns;
  }

  // 获取数据库连接实例方法（带回调通知机制）
  getRdbStore(callback: Function = () => {}) {
    // 回调有效性校验（三保险检查）
    if (!callback || typeof callback === 'undefined' || callback === undefined) {
      console.info('getRdbStore() has no callback.');
      return;
    }

    // 快速返回已存在的连接实例
    if (this.rdbStore != null) {
      console.info('The rdbStore exists.');
      callback(); // 直接执行回调
      return;
    }

    // 获取当前上下文（需要具体实现getContext方法）
    let context: Context = getContext(this) as Context;

    // 异步获取数据库连接实例
    relationalStore.getRdbStore(
      context,
      CommonConstants.STONE_CONFIG, // 使用预定义的数据库配置
      (err, rdb) => {               // 异步回调函数
        if (err) {
          console.error(`getRdbStore() failed, err: ${err}`);
          return;
        }

        // 连接成功后的初始化操作
        this.rdbStore = rdb;                   // 保存连接实例
        this.rdbStore.executeSql(this.sqlCreateTable); // 执行建表语句
        console.info("getRdbStore() finished");
        callback(); // 执行用户回调
      }
    );
  }
}
```
RdbFunctions.ets;
```typescript {.line-numbers}
// 导入ArkData关系型数据库模块
import { relationalStore } from '@kit.ArkData';
// 导入通用常量配置模块
import CommonConstants from "../constants/CommonConstants";
// 导入数据库工具基类
import RdbUtil from './RdbUtil'

// 定义数据库功能扩展类（继承自RdbUtil）
export default class RdbFunctions extends RdbUtil {
  // 数据插入方法
  insertData(
    data: relationalStore.ValuesBucket,  // 要插入的数据对象（键值对集合）
    callback: Function = () => {}        // 操作完成后的回调函数
  ) {
    let resFlag: boolean = false;        // 操作结果标志（初始为失败状态）
    const valueBucket = data;            // 数据预处理（直接赋值，可在此处添加数据校验逻辑）

    // 检查数据库连接是否存在
    if (this.rdbStore) {
      // 执行插入操作（异步）
      this.rdbStore.insert(
        this.tableName,                  // 目标表名（继承自父类）
        valueBucket,                     // 插入数据
        (err, ret) => {                 // 异步回调
          if (err) {                    // 错误处理
            console.error('Rdb', `insertData() failed, err: ${err}`);
            callback(resFlag);          // 返回失败状态
            return;
          }
          console.info(`insertData() finished: ${ret}`); // 成功日志
          callback(!resFlag);           // 返回成功状态（取反）
        }
      );
    }
  }

  // 数据删除方法
  deleteData(
    predicates: relationalStore.RdbPredicates, // 删除条件（查询条件对象）
    callback: Function = () => {}             // 操作完成后的回调函数
  ) {
    let resFlag: boolean = false;             // 操作结果标志

    if (this.rdbStore) {
      // 执行删除操作（异步）
      this.rdbStore.delete(
        predicates,                     // 删除条件
        (err, ret) => {                // 异步回调
          if (err) {
            console.error('Rdb', `deleteData() failed, err: ${err}`);
            callback(resFlag);
            return;
          }
          console.info(`deleteData() finished: ${ret}`);
          callback(!resFlag);
        }
      );
    }
  }

  // 数据更新方法（注意方法名疑似拼写错误，应为updateData）
  updateDate(
    predicates: relationalStore.RdbPredicates, // 更新条件
    data: relationalStore.ValuesBucket,        // 更新数据
    callback: Function = () => {}             // 操作完成后的回调函数
  ) {
    let resFlag: boolean = false;             // 操作结果标志
    const valueBucket = data;                 // 数据预处理

    if (this.rdbStore) {
      // 执行更新操作（异步）
      this.rdbStore.update(
        valueBucket,                    // 更新数据
        predicates,                     // 更新条件
        (err, ret) => {                // 异步回调
          if (err) {
            console.error('Rdb', `updateData() failed, err: ${err}`);
            callback(resFlag);
            return;
          }
          console.info(`updateData() finished: ${ret}`);
          callback(!resFlag);
        }
      );
    }
  }

  // 数据查询方法
  query(
    predicates: relationalStore.RdbPredicates, // 查询条件
    callback: Function = () => {}             // 查询完成后的回调函数
  ) {
    if (this.rdbStore) {
      // 执行查询操作（异步）
      this.rdbStore.query(
        predicates,                     // 查询条件
        (err, ret) => {                // 异步回调
          if (err) {
            console.error('Rdb', `query() failed: ${err}`);
            return;
          }
          console.info('Rdb', `query() finished: ${ret}`);
          callback(ret);                // 返回查询结果
        }
      );
    }
  }
}
```
AccountUser.ets:
```typescript {.line-numbers}
// 导入关系型数据库存储模块
import { relationalStore } from '@kit.ArkData';
// 导入自定义的数据库工具类
import RdbUtil from './RdbUtil';
// 导入封装好的数据库操作函数类
import RdbFunctions from './RdbFunctions';
// 导入账户数据接口定义
import { AccountData } from './table/AccountInterface';
// 导入账户表结构接口定义
import { AccountTable } from './table/AccountInterface';
// 导入公共常量定义（包含数据库表名、创建语句等）
import CommonConstants from '../constants/CommonConstants'

// 声明AccountUsers类，用于处理账户用户相关数据库操作
export default class AccountUsers {
  // 实例化RdbFunctions类，传入表名、建表语句和列定义
  private accountUsers = new RdbFunctions(
    CommonConstants.ACCOUNT_TABLE.tableName,
    CommonConstants.ACCOUNT_TABLE.sqlCreate,
    CommonConstants.ACCOUNT_TABLE.columns
  );

  // 构造函数，接受回调函数作为参数（默认空函数）
  constructor(callback: Function = () => {}) {
    // 调用getRdbStore方法初始化数据库连接，传入回调
    this.accountUsers.getRdbStore(callback);
  }

  // 获取数据库存储实例的方法（代理到RdbFunctions）
  getRdbStore(callback: Function = () => {}) {
    this.accountUsers.getRdbStore(callback);
  }

  // 插入数据方法
  insertData(account: AccountData, callback: Function) {
    // 生成符合数据库要求的值对象
    const valueBucket = generateBucket(account);
    // 调用RdbFunctions的插入方法，传入值对象和回调
    this.accountUsers.insertData(valueBucket, callback);
  }

  // 删除数据方法
  deleteData(account: AccountData, callback: Function) {
    // 创建查询条件对象，指定表名
    let predicates = new relationalStore.RdbPredicates(
      CommonConstants.ACCOUNT_TABLE.tableName
    );
    // 添加精确匹配条件：id字段等于传入账户的id
    predicates.equalTo('id', account.id);
    // 调用RdbFunctions的删除方法，传入条件和回调
    this.accountUsers.deleteData(predicates, callback);
  }

  // 更新数据方法
  updateData(account: AccountData, callback: Function) {
    // 生成要更新的值对象
    const valueBucket = generateBucket(account);
    // 创建查询条件对象
    let predicates = new relationalStore.RdbPredicates(
      CommonConstants.ACCOUNT_TABLE.tableName
    );
    // 添加精确匹配条件：id字段等于传入账户的id
    predicates.equalTo('id', account.id);
    // 调用RdbFunctions的更新方法，传入条件、值对象和回调
    this.accountUsers.updateDate(predicates, valueBucket, callback);
  }

  // 查询数据方法
  query(amount: number, callback: Function, isAll: boolean = true) {
    // 创建查询条件对象
    let predicates = new relationalStore.RdbPredicates(
      CommonConstants.ACCOUNT_TABLE.tableName
    );
    // 如果不是查询全部，添加金额匹配条件
    if (!isAll) {
      predicates.equalTo('amount', amount);
    }

    // 执行查询操作，传入条件和结果处理回调
    this.accountUsers.query(predicates, (resultSet: relationalStore.ResultSet) => {
      // 获取结果集行数
      let count = resultSet.rowCount;

      // 处理空结果或异常类型情况
      if (count === 0 || typeof count === 'string') {
        console.log('Query no result!');
        callback(); // 执行空回调
      } else {
        // 将结果集指针移动到第一行
        resultSet.goToFirstRow();
        const result: AccountData[] = [];
        // 遍历所有结果行
        for (let i = 0; i < count; i++) {
          // 创建临时账户数据对象
          let tmp: AccountData = { id: 0, accountType: 0, typeText: '', amount: 0 };
          // 从结果集中提取各字段值
          tmp.id = resultSet.getDouble(resultSet.getColumnIndex('id'));
          tmp.accountType = resultSet.getDouble(resultSet.getColumnIndex('accountType'));
          tmp.typeText = resultSet.getString(resultSet.getColumnIndex('typeText'));
          tmp.amount = resultSet.getDouble(resultSet.getColumnIndex('amount'));

          // 将临时对象加入结果数组
          result[i] = tmp;
          // 移动到下一行
          resultSet.goToNextRow();
        }
        // 执行回调并返回结果数组
        callback(result);
      }
    });
  }
}

// 生成数据库值对象的辅助函数
function generateBucket(account: AccountData) {
  // 创建空值对象（类型符合数据库要求）
  let obj: relationalStore.ValuesBucket = {};
  // 从账户对象提取字段值
  obj.accountType = account.accountType;
  obj.typeText = account.typeText;
  obj.amount = account.amount;
  // 返回构建好的值对象
  return obj;
}
```
#### 4.2 结果验证
进入主页面:
![alt text](主页面.png)
点击查询显示结果为空:
![](第一次点击查询结果为空.png)
点击增加后查询显示结果:
![alt text](点击增加后点击查询显示结果.png)
再次点击增加后查询显示结果;
![alt text](再次点击增加后点击查询显示结果.png)
点击删除后查询结果，第二条记录被删除:
![alt text](点击删除后查询结果.png)
点击修改后查询显示结果:
![alt text](点击修改后查询结果.png)


